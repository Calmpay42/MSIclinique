'use strict';
/* Crée un certificat auto-signé pour le HTTPS sur le réseau local (valable 10 ans).
   Chaque poste devra accepter le certificat une première fois dans son navigateur. */
const fs = require('fs');
const path = require('path');
const os = require('os');
const selfsigned = require('selfsigned');
const { lireConfig } = require('../serveur/config');

const conf = lireConfig();
const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4').map(i => i.address);
const noms = [os.hostname(), 'localhost'];
/* Noms sans accents : la bibliothèque de certificats n'encode pas correctement les caractères accentués. */
const pems = selfsigned.generate([{ name: 'commonName', value: 'MSI Gestion' }, { name: 'organizationName', value: 'Maison de Sante Innov Care' }], {
  days: 3650, keySize: 2048, algorithm: 'sha256',
  extensions: [{ name: 'subjectAltName', altNames: [...noms.map(n => ({ type: 2, value: n })), ...ips.map(ip => ({ type: 7, ip }))] }]
});
const dossier = path.join(conf.dossier_donnees, 'certificats');
fs.mkdirSync(dossier, { recursive: true });
fs.writeFileSync(path.join(dossier, 'cle.pem'), pems.private, { mode: 0o600 });
fs.writeFileSync(path.join(dossier, 'cert.pem'), pems.cert);
console.log(`Certificat créé dans ${dossier} pour : ${[...noms, ...ips].join(', ')}`);
console.log('Redémarrez le serveur : il passera automatiquement en HTTPS.');
