'use strict';
/* Point d'entrée Vercel (édition en ligne, base Turso) : le serveur de MSI Gestion, inchangé, derrière une fonction Vercel.
   Variables du projet Vercel :
   - TURSO_DATABASE_URL et TURSO_AUTH_TOKEN : fournies par l'intégration Turso ;
   - MSI_MDP_ADMIN_INITIAL : mot de passe provisoire de l'administrateur, choisi par la clinique (10 caractères au moins),
     utilisé une seule fois au premier démarrage et à changer à la première connexion ;
   - MSI_FORMATION=1 (facultatif) : base de formation, avec données fictives. */
process.env.TZ = process.env.TZ || 'Africa/Abidjan';
process.env.MSI_EN_LIGNE = '1';
if (process.env.MSI_JAMAIS) require('@libsql/client'); // inclut le client Turso dans la fonction (analyse des dépendances de Vercel)

const URL_BASE = process.env.TURSO_DATABASE_URL || process.env.LIBSQL_URL || process.env.MSI_BASE_URL;
let app = null, derniereErreur = null;

function premierDemarrage(db) {
  const init = require('../serveur/donnees-initiales');
  if (db.prepare('SELECT COUNT(*) AS n FROM utilisateurs').get().n) return;
  const formation = process.env.MSI_FORMATION === '1';
  const comptes = db.transaction(() => {
    if (db.prepare('SELECT COUNT(*) AS n FROM utilisateurs').get().n) return null; // une autre instance l'a déjà fait
    init.referentiels(db, { formation });
    const c = init.comptes(db, { formation });
    if (formation) init.donneesFormation(db);
    return c;
  })();
  if (!comptes) return;
  const choisi = String(process.env.MSI_MDP_ADMIN_INITIAL || '');
  if (!formation && choisi.length >= 10) {
    const A = require('../serveur/auth');
    db.prepare("UPDATE utilisateurs SET hash = ?, changer_mdp = 1 WHERE login = 'admin'").run(A.hacher(choisi));
    console.log('MSI Gestion : base de production créée. Connexion : admin, avec le mot de passe provisoire choisi dans les réglages du projet (à changer à la première connexion).');
  } else {
    console.log(`MSI Gestion : base ${formation ? 'de FORMATION' : 'de production'} créée. Comptes (mots de passe à changer à la première connexion) :`);
    for (const c of comptes) console.log(`  ${c.login} ${c.mdp} ${c.roles}`);
  }
}

function demarrer() {
  if (app) return app;
  if (!URL_BASE) throw new Error('Base de données non configurée : ajoutez la base Turso au projet Vercel (variable TURSO_DATABASE_URL).');
  const { ouvrir } = require('../serveur/db');
  const db = ouvrir(URL_BASE);
  premierDemarrage(db);
  require('../serveur/donnees-initiales').completerReferentiels(db);
  app = require('../serveur/app').creerApp(db, { enLigne: true });
  derniereErreur = null;
  return app;
}

module.exports = (req, res) => {
  let a;
  try { a = demarrer(); } catch (e) {
    derniereErreur = e; app = null;
    console.error('MSI Gestion : démarrage impossible :', e.message);
    res.statusCode = 503;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Retry-After', '10');
    return res.end('MSI Gestion démarre ou la base de données est momentanément injoignable. Réessayez dans quelques secondes.\n' + e.message);
  }
  return a(req, res);
};
