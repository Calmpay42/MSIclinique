'use strict';
/* Tableau de bord personnel du médecin (v1.9) : patients reçus (jour, mois), documents et examens demandés, résultats,
   alertes infirmières, patients hospitalisés, rendez-vous. Chaque médecin ne voit que sa propre activité. */
const R = require('./regles');
const { jourLocal, bornesJour, ajouterJours } = require('./outils');
const LIBELLES = { ordonnance: 'Ordonnances', examens: 'Demandes d’examens', certificat: 'Certificats', compte_rendu: 'Comptes rendus', cr: 'Comptes rendus',
  orientation: 'Lettres d’orientation', rdv: 'Rendez-vous', conseils: 'Fiches conseils' };

function tableauMedecin(db, u) {
  const jour = jourLocal(), mois = jour.slice(0, 7), [debJ, finJ] = bornesJour(jour), debM = bornesJour(`${mois}-01`)[0];
  const [y, m] = mois.split('-').map(Number), prec = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`, debP = bornesJour(`${prec}-01`)[0];
  const compte = (a, b) => db.prepare('SELECT COUNT(*) AS consultations, COUNT(DISTINCT patient_id) AS patients FROM consultations WHERE medecin_id = ? AND cree_le >= ? AND cree_le < ?').get(u.id, a, b);
  const serie = Array.from({ length: 30 }, (_, i) => {
    const j = ajouterJours(jour, i - 29), [a, b] = bornesJour(j);
    return { jour: j, n: db.prepare('SELECT COUNT(*) n FROM consultations WHERE medecin_id = ? AND cree_le >= ? AND cree_le < ?').get(u.id, a, b).n };
  });
  const parType = {}, examens = {};
  for (const d of db.prepare('SELECT type, donnees FROM documents WHERE medecin_id = ? AND cree_le >= ? AND cree_le < ?').all(u.id, debM, finJ)) {
    parType[d.type] = (parType[d.type] || 0) + 1;
    if (d.type === 'examens') for (const it of (JSON.parse(d.donnees || '{}').items || [])) { const l = String((it && it.l) || it || '').trim(); if (l) examens[l] = (examens[l] || 0) + 1; }
  }
  const passagesMois = 'SELECT passage_id FROM consultations WHERE medecin_id = ? AND cree_le >= ?';
  const resultats = db.prepare(`SELECT donnees FROM resultats WHERE statut = 'valide' AND valide_le >= ? AND passage_id IN (${passagesMois})`).all(debM, u.id, debM);
  const enAttente = db.prepare(`SELECT COUNT(*) n FROM bons b JOIN actes a ON a.code = b.code AND b.nature = 'acte' WHERE a.famille = 'Laboratoire' AND b.annule = 0
    AND (b.paye = 1 OR b.gratuit = 1 OR b.urgent = 1) AND b.passage_id IN (${passagesMois}) AND NOT EXISTS (SELECT 1 FROM resultats r WHERE r.bon_id = b.id AND r.statut = 'valide')`).get(u.id, debM).n;
  const alertes = db.prepare(`SELECT c.alertes, c.maj_le, c.patient_id, s.nom AS par, EXISTS (SELECT 1 FROM consultations k WHERE k.passage_id = c.passage_id) AS recu
    FROM constantes c LEFT JOIN utilisateurs s ON s.id = c.saisi_par WHERE c.medecin_id = ? AND c.prioritaire = 1 AND c.maj_le >= ? ORDER BY c.maj_le DESC`).all(u.id, debJ)
    .map(c => ({ source: 'infirmerie', patient: R.nomPatient(R.patient(db, c.patient_id)), alertes: JSON.parse(c.alertes || '[]'), le: c.maj_le, par: c.par, recu: !!c.recu }));
  const alertesHosp = db.prepare(`SELECT s.alertes, s.realise_le, h.patient_id, x.nom AS par FROM soins_hospitalisation s JOIN hospitalisations h ON h.id = s.hospitalisation_id
    LEFT JOIN utilisateurs x ON x.id = s.realise_par WHERE h.medecin_id = ? AND h.statut = 'en_cours' AND s.type = 'constantes' AND s.alertes IS NOT NULL AND s.alertes != '[]'
    AND s.realise_le >= ? ORDER BY s.realise_le DESC LIMIT 10`).all(u.id, bornesJour(ajouterJours(jour, -1))[0])
    .map(s => ({ source: 'hospitalisation', patient: R.nomPatient(R.patient(db, s.patient_id)), alertes: JSON.parse(s.alertes), le: s.realise_le, par: s.par, recu: false }));
  return {
    jour, mois, mois_precedent: prec,
    aujourdhui: compte(debJ, finJ), mois_courant: compte(debM, finJ), precedent: compte(debP, debM),
    en_cours: db.prepare('SELECT COUNT(*) n FROM consultations WHERE medecin_id = ? AND valide_le IS NULL AND cree_le >= ?').get(u.id, debJ).n,
    serie,
    documents: Object.entries(parType).map(([type, n]) => ({ type, libelle: LIBELLES[type] || type, n })).sort((a, b) => b.n - a.n),
    examens: { demandes: parType.examens || 0, top: Object.entries(examens).map(([l, n]) => ({ l, n })).sort((a, b) => b.n - a.n).slice(0, 8) },
    resultats: { recus: resultats.length, anormaux: resultats.filter(r => JSON.parse(r.donnees || '[]').some(l => l.drapeau)).length, en_attente: enAttente },
    alertes: [...alertes, ...alertesHosp].sort((a, b) => b.le.localeCompare(a.le)),
    hospitalises: db.prepare("SELECT COUNT(*) n FROM hospitalisations WHERE medecin_id = ? AND statut = 'en_cours'").get(u.id).n,
    rdv: db.prepare(`SELECT r.date, r.heure, r.motif, p.nom, p.prenoms FROM rdv r JOIN patients p ON p.id = r.patient_id WHERE r.medecin_id = ? AND r.statut = 'prevu'
      AND r.date >= ? AND r.date <= ? ORDER BY r.date, r.heure LIMIT 10`).all(u.id, jour, ajouterJours(jour, 7))
  };
}
module.exports = { tableauMedecin };
