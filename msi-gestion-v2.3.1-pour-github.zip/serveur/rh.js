'use strict';
/* Ressources humaines (v1.8) : registre du personnel, planning des gardes et des consultations, paie mensuelle
   (préparée par les RH ou le RAF, validée par la direction, payée par le RAF), avances sur salaire.
   Rien ne s'efface : un employé s'archive, un créneau ou un bulletin s'annule, avec trace au journal.
   Taux de cotisation paramétrables : valeurs indicatives, à faire confirmer par l'expert-comptable. */
const R = require('./regles');
const { maintenant, jourLocal, ajouterJours, pad, err, texte, entier } = require('./outils');
const { peut } = require('./auth');

const FONCTIONS = ['Médecin', 'Infirmier', 'Sage-femme', 'Aide-soignant', 'Laborantin', 'Pharmacien', 'Caissier', 'Agent d’accueil', 'Comptable', 'Agent d’entretien', 'Sécurité', 'Chauffeur', 'Direction', 'Autre'];
const CONTRATS = ['CDI', 'CDD', 'Vacataire', 'Stage'];
const MODES_PAIEMENT = ['Virement', 'Espèces', 'Mobile money', 'Chèque'];
const TYPES_CRENEAU = { garde: 'Garde', consultation: 'Consultation', permanence: 'Permanence', astreinte: 'Astreinte', conge: 'Congé', absence: 'Absence' };
const FONCTION_DU_ROLE = { medecin: 'Médecin', infirmier: 'Infirmier', laboratoire: 'Laborantin', pharmacie: 'Pharmacien', pharmacien: 'Pharmacien', caisse: 'Caissier', accueil: 'Agent d’accueil', facturiste: 'Comptable', raf: 'Comptable', direction: 'Direction' };
const SALARIAUX = ['salaire_base', 'taux_garde', 'taux_vacation'];
const fr = j => String(j || '').slice(0, 10).split('-').reverse().join('/');
const fcfa = n => `${String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} FCFA`;
const jourValide = (v, label) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v || ''))) throw err(400, `${label} : date attendue.`); return String(v); };
const heureValide = (v, label) => { if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(String(v || ''))) throw err(400, `${label} : heure attendue, par exemple 18:00.`); return String(v); };
const periodeValide = v => { if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(v || ''))) throw err(400, 'Période attendue au format AAAA-MM.'); return String(v); };
const bornesMois = p => { const [y, m] = p.split('-').map(Number); return [`${p}-01`, `${p}-${pad(new Date(Date.UTC(y, m, 0)).getUTCDate(), 2)}`]; };
const lundiDe = j => { const d = new Date(j + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7); return d.toISOString().slice(0, 10); };
const nomEmploye = e => `${e.nom}${e.prenoms ? ' ' + e.prenoms : ''}`;

/* ---------- Personnel ---------- */
function lireEmploye(d) {
  const fonction = FONCTIONS.includes(d.fonction) ? d.fonction : null, contrat = CONTRATS.includes(d.contrat) ? d.contrat : null;
  if (!fonction) throw err(400, 'Choisissez la fonction.');
  if (!contrat) throw err(400, 'Choisissez le type de contrat.');
  const embauche_le = jourValide(d.embauche_le, 'Date d’embauche'), fin_contrat = d.fin_contrat ? jourValide(d.fin_contrat, 'Fin de contrat') : null;
  if (contrat === 'CDD' && !fin_contrat) throw err(400, 'CDD : indiquez la date de fin de contrat.');
  if (fin_contrat && fin_contrat < embauche_le) throw err(400, 'La fin de contrat précède la date d’embauche.');
  return {
    nom: texte(d.nom, { label: 'Nom', max: 80, requis: true }), prenoms: texte(d.prenoms, { label: 'Prénoms', max: 120 }) || null,
    sexe: ['F', 'M'].includes(d.sexe) ? d.sexe : null, telephone: R.formaterTelephone(texte(d.telephone, { label: 'Téléphone', max: 30 })) || null,
    fonction, service: texte(d.service, { label: 'Service', max: 80 }) || null, contrat, embauche_le, fin_contrat,
    salaire_base: entier(d.salaire_base || 0, { label: 'Salaire de base', min: 0, max: 50000000 }),
    taux_garde: entier(d.taux_garde || 0, { label: 'Prime par garde', min: 0, max: 5000000 }),
    taux_vacation: entier(d.taux_vacation || 0, { label: 'Montant par vacation', min: 0, max: 5000000 }),
    numero_cnps: texte(d.numero_cnps, { label: 'N° CNPS', max: 30 }) || null,
    mode_paiement: MODES_PAIEMENT.includes(d.mode_paiement) ? d.mode_paiement : 'Virement',
    utilisateur_id: d.utilisateur_id ? Number(d.utilisateur_id) : null
  };
}
function sauverEmploye(db, u, id, d) {
  const v = lireEmploye(d);
  if (v.utilisateur_id) {
    if (!db.prepare('SELECT 1 FROM utilisateurs WHERE id = ?').get(v.utilisateur_id)) throw err(400, 'Compte introuvable.');
    const lie = db.prepare('SELECT matricule FROM employes WHERE utilisateur_id = ? AND actif = 1 AND id IS NOT ?').get(v.utilisateur_id, id || null);
    if (lie) throw err(409, `Ce compte est déjà lié à l’employé ${lie.matricule}.`);
  }
  const cols = Object.keys(v);
  return db.transaction(() => {
    if (id) {
      const avant = db.prepare('SELECT * FROM employes WHERE id = ?').get(id);
      if (!avant) throw err(404, 'Employé introuvable.');
      const diff = cols.filter(c => String(avant[c] == null ? '' : avant[c]) !== String(v[c] == null ? '' : v[c]));
      db.prepare(`UPDATE employes SET ${cols.map(c => `${c} = @${c}`).join(', ')} WHERE id = @id`).run({ ...v, id });
      R.journal(db, u, 'Ressources humaines', 'Employé modifié', `${avant.matricule} ${nomEmploye(v)} : ${diff.join(', ') || 'aucun changement'}`,
        { avant: Object.fromEntries(diff.map(c => [c, avant[c]])), apres: Object.fromEntries(diff.map(c => [c, v[c]])), niveau: diff.some(c => SALARIAUX.includes(c)) ? 'alerte' : null });
      return { id };
    }
    const matricule = `EMP-${pad(R.suivant(db, 'employe'), 4)}`;
    const nid = db.prepare(`INSERT INTO employes(matricule, ${cols.join(', ')}, cree_le) VALUES (@matricule, ${cols.map(c => '@' + c).join(', ')}, @cree_le)`)
      .run({ ...v, matricule, cree_le: maintenant() }).lastInsertRowid;
    R.journal(db, u, 'Ressources humaines', 'Employé ajouté', `${matricule} ${nomEmploye(v)} : ${v.fonction}, ${v.contrat}`);
    return { id: nid, matricule };
  })();
}
function archiverEmploye(db, u, id, d) {
  const e = db.prepare('SELECT * FROM employes WHERE id = ?').get(id);
  if (!e) throw err(404, 'Employé introuvable.');
  if (!e.actif) throw err(409, 'Employé déjà archivé.');
  const sortie = jourValide(d.sortie_le || jourLocal(), 'Date de sortie'), motif = texte(d.motif, { label: 'Motif de sortie', max: 200, requis: true });
  db.prepare('UPDATE employes SET actif = 0, sortie_le = ?, motif_sortie = ? WHERE id = ?').run(sortie, motif, id);
  R.journal(db, u, 'Ressources humaines', 'Employé archivé', `${e.matricule} ${nomEmploye(e)} : sortie le ${fr(sortie)}, ${motif}`);
  return { ok: true };
}
const comptesLibres = db => db.prepare(`SELECT id, nom, roles FROM utilisateurs WHERE actif = 1
  AND id NOT IN (SELECT utilisateur_id FROM employes WHERE utilisateur_id IS NOT NULL AND actif = 1) ORDER BY nom`).all();
function reprendreComptes(db, u) {
  const libres = comptesLibres(db).filter(c => !String(c.roles).split(',').every(r => r === 'admin'));
  return db.transaction(() => {
    for (const c of libres) {
      const role = String(c.roles).split(',').find(r => FONCTION_DU_ROLE[r]);
      db.prepare('INSERT INTO employes(matricule, nom, fonction, contrat, embauche_le, mode_paiement, utilisateur_id, cree_le) VALUES (?,?,?,?,?,?,?,?)')
        .run(`EMP-${pad(R.suivant(db, 'employe'), 4)}`, c.nom, role ? FONCTION_DU_ROLE[role] : 'Autre', 'CDI', jourLocal(), 'Virement', c.id, maintenant());
    }
    if (libres.length) R.journal(db, u, 'Ressources humaines', 'Reprise des comptes', `${libres.length} employé${libres.length > 1 ? 's' : ''} créé${libres.length > 1 ? 's' : ''} depuis les comptes : ${libres.map(c => c.nom).join(', ')}`);
    return { crees: libres.length };
  })();
}

/* ---------- Planning ---------- */
const minutes = h => { const [a, b] = h.split(':').map(Number); return a * 60 + b; };
function intervalle(c) {
  const base = Math.round(new Date(c.jour + 'T00:00:00Z').getTime() / 864e5) * 1440, a = base + minutes(c.debut);
  let b = base + minutes(c.fin);
  if (b <= a) b += 1440; /* franchit minuit (garde 18 h–08 h) ; début = fin : 24 heures */
  return [a, b];
}
function conflit(db, employeId, c) {
  const [a, b] = intervalle(c);
  return db.prepare('SELECT * FROM planning WHERE employe_id = ? AND annule_le IS NULL AND jour BETWEEN ? AND ?').all(employeId, ajouterJours(c.jour, -1), ajouterJours(c.jour, 1))
    .find(x => { const [xa, xb] = intervalle(x); return a < xb && xa < b; }) || null;
}
function ajouterCreneau(db, u, d) {
  const e = db.prepare('SELECT * FROM employes WHERE id = ? AND actif = 1').get(Number(d.employe_id));
  if (!e) throw err(400, 'Choisissez un employé actif.');
  if (!TYPES_CRENEAU[d.type]) throw err(400, 'Type de créneau inconnu.');
  const c = { jour: jourValide(d.jour, 'Date'), debut: heureValide(d.debut, 'Début'), fin: heureValide(d.fin, 'Fin') };
  const x = conflit(db, e.id, c);
  if (x) throw err(409, `Chevauchement avec ${TYPES_CRENEAU[x.type].toLowerCase()} du ${fr(x.jour)} (${x.debut}–${x.fin}).`);
  const id = db.prepare('INSERT INTO planning(employe_id, jour, type, debut, fin, observation, cree_par, cree_le) VALUES (?,?,?,?,?,?,?,?)')
    .run(e.id, c.jour, d.type, c.debut, c.fin, texte(d.observation, { label: 'Observation', max: 200 }) || null, u.id, maintenant()).lastInsertRowid;
  R.journal(db, u, 'Ressources humaines', 'Planning', `${e.matricule} ${nomEmploye(e)} : ${TYPES_CRENEAU[d.type].toLowerCase()} le ${fr(c.jour)}, de ${c.debut} à ${c.fin}`);
  return { id };
}
function annulerCreneau(db, u, id) {
  const c = db.prepare('SELECT p.*, e.matricule, e.nom, e.prenoms FROM planning p JOIN employes e ON e.id = p.employe_id WHERE p.id = ?').get(id);
  if (!c) throw err(404, 'Créneau introuvable.');
  if (c.annule_le) throw err(409, 'Créneau déjà annulé.');
  db.prepare('UPDATE planning SET annule_le = ?, annule_par = ? WHERE id = ?').run(maintenant(), u.id, id);
  R.journal(db, u, 'Ressources humaines', 'Planning annulé', `${c.matricule} ${nomEmploye(c)} : ${TYPES_CRENEAU[c.type].toLowerCase()} du ${fr(c.jour)}, ${c.debut}–${c.fin}`);
  return { ok: true };
}
function recopierSemaine(db, u, d) {
  const lundi = lundiDe(jourValide(d.lundi, 'Semaine'));
  const source = db.prepare(`SELECT p.* FROM planning p JOIN employes e ON e.id = p.employe_id WHERE p.annule_le IS NULL AND e.actif = 1 AND p.jour BETWEEN ? AND ? ORDER BY p.jour, p.debut`)
    .all(ajouterJours(lundi, -7), ajouterJours(lundi, -1));
  return db.transaction(() => {
    let copies = 0, ignores = 0;
    for (const s of source) {
      const c = { jour: ajouterJours(s.jour, 7), debut: s.debut, fin: s.fin };
      if (conflit(db, s.employe_id, c)) { ignores++; continue; }
      db.prepare('INSERT INTO planning(employe_id, jour, type, debut, fin, observation, cree_par, cree_le) VALUES (?,?,?,?,?,?,?,?)').run(s.employe_id, c.jour, s.type, c.debut, c.fin, s.observation, u.id, maintenant());
      copies++;
    }
    R.journal(db, u, 'Ressources humaines', 'Planning recopié', `Semaine du ${fr(lundi)} : ${copies} créneau${copies > 1 ? 'x' : ''} recopié${copies > 1 ? 's' : ''}${ignores ? `, ${ignores} ignoré${ignores > 1 ? 's' : ''} (déjà occupé)` : ''}`);
    return { copies, ignores };
  })();
}
const planning = (db, debut, fin) => db.prepare(`SELECT p.*, e.matricule, e.nom, e.prenoms, e.fonction FROM planning p JOIN employes e ON e.id = p.employe_id
  WHERE p.annule_le IS NULL AND p.jour BETWEEN ? AND ? ORDER BY p.jour, p.debut`).all(debut, fin);
function monPlanning(db, u) {
  const e = db.prepare('SELECT id FROM employes WHERE utilisateur_id = ? AND actif = 1').get(u.id);
  if (!e) return { lie: false, creneaux: [] };
  return { lie: true, creneaux: db.prepare('SELECT jour, type, debut, fin, observation FROM planning WHERE employe_id = ? AND annule_le IS NULL AND jour BETWEEN ? AND ? ORDER BY jour, debut')
    .all(e.id, jourLocal(), ajouterJours(jourLocal(), 30)) };
}

/* ---------- Paie ---------- */
function paramsPaie(db) { const p = R.params(db); return { taux_cnps: p.rh_taux_cnps, plafond_cnps: p.rh_plafond_cnps, cmu: p.rh_cmu, cnps_employeur: p.rh_cnps_employeur || '' }; }
function lignesAuto(db, e, periode) {
  const [debut, fin] = bornesMois(periode), P = paramsPaie(db), L = [];
  const n = t => db.prepare('SELECT COUNT(*) n FROM planning WHERE employe_id = ? AND type = ? AND annule_le IS NULL AND jour BETWEEN ? AND ?').get(e.id, t, debut, fin).n;
  if (e.salaire_base) L.push({ type: 'gain', code: 'BASE', libelle: 'Salaire de base', montant: e.salaire_base });
  const g = n('garde'), v = n('consultation');
  if (g && e.taux_garde) L.push({ type: 'gain', code: 'GARDES', libelle: `Primes de garde (${g} × ${fcfa(e.taux_garde)})`, montant: g * e.taux_garde });
  if (v && e.taux_vacation) L.push({ type: 'gain', code: 'VACATIONS', libelle: `Vacations de consultation (${v} × ${fcfa(e.taux_vacation)})`, montant: v * e.taux_vacation });
  const brut = L.reduce((s, x) => s + x.montant, 0);
  /* Cotisations salariales des salariés (CDI, CDD) ; vacataires et stagiaires n'en ont pas. */
  if (['CDI', 'CDD'].includes(e.contrat) && brut) {
    if (P.taux_cnps) L.push({ type: 'retenue', code: 'CNPS', libelle: `Cotisation retraite CNPS (${String(P.taux_cnps).replace('.', ',')} %)`, montant: Math.round((P.plafond_cnps ? Math.min(brut, P.plafond_cnps) : brut) * P.taux_cnps / 100) });
    if (P.cmu) L.push({ type: 'retenue', code: 'CMU', libelle: 'Couverture maladie universelle (part salariale)', montant: P.cmu });
  }
  return L;
}
function totaux(lignes) {
  const brut = lignes.filter(l => l.type === 'gain').reduce((s, l) => s + l.montant, 0), retenues = lignes.filter(l => l.type === 'retenue').reduce((s, l) => s + l.montant, 0);
  return { brut, retenues, net: brut - retenues };
}
function preparerPaie(db, u, d) {
  const periode = periodeValide(d.periode), [, fin] = bornesMois(periode);
  const employes = db.prepare(`SELECT * FROM employes WHERE actif = 1 AND embauche_le <= ? AND id NOT IN (SELECT employe_id FROM paies WHERE periode = ? AND statut <> 'annule') ORDER BY nom`).all(fin, periode)
    .filter(e => !d.employe_id || e.id === Number(d.employe_id));
  const prepares = [], erreurs = [];
  for (const e of employes) {
    try {
      db.transaction(() => {
        const avances = db.prepare('SELECT * FROM avances_salaire WHERE employe_id = ? AND paie_id IS NULL AND accorde_le <= ? ORDER BY id').all(e.id, fin + 'T23:59:59');
        const lignes = [...lignesAuto(db, e, periode), ...avances.map(a => ({ type: 'retenue', code: 'AVANCE', libelle: `Avance sur salaire du ${fr(a.accorde_le)}`, montant: a.montant, avance_id: a.id }))];
        const t = totaux(lignes);
        if (!t.brut) throw err(409, 'aucun gain (salaire de base, gardes ou vacations) pour ce mois');
        if (t.net < 0) throw err(409, `retenues (${fcfa(t.retenues)}) supérieures au brut (${fcfa(t.brut)})`);
        const numero = `BP-${periode.replace('-', '')}-${pad(R.suivant(db, 'paie:' + periode), 3)}`;
        const id = db.prepare('INSERT INTO paies(numero, employe_id, periode, lignes, brut, retenues, net, prepare_par, prepare_le) VALUES (?,?,?,?,?,?,?,?,?)')
          .run(numero, e.id, periode, JSON.stringify(lignes), t.brut, t.retenues, t.net, u.id, maintenant()).lastInsertRowid;
        for (const a of avances) db.prepare('UPDATE avances_salaire SET paie_id = ? WHERE id = ?').run(id, a.id);
        prepares.push({ id, numero, employe: nomEmploye(e), net: t.net });
      })();
    } catch (x) { if (!(x instanceof Error) || !x.status) throw x; erreurs.push({ matricule: e.matricule, employe: nomEmploye(e), message: x.message }); }
  }
  if (prepares.length) R.journal(db, u, 'Ressources humaines', 'Paie préparée', `${periode} : ${prepares.length} bulletin${prepares.length > 1 ? 's' : ''}, net total ${fcfa(prepares.reduce((s, p) => s + p.net, 0))}`);
  return { prepares, erreurs };
}
const lirePaie = (db, id) => { const p = db.prepare('SELECT * FROM paies WHERE id = ?').get(id); if (!p) throw err(404, 'Bulletin introuvable.'); return p; };
/* Lignes manuelles (prime, indemnité, ITS saisi par le comptable…) : modifiables tant que le bulletin n'est pas validé. */
/* Correction (reprise 1.8) : la cotisation retraite porte sur tous les gains du bulletin, primes saisies après la préparation comprises,
   sauf les lignes marquées « hors cotisations » (indemnité de transport, par exemple) ; elle est recalculée à chaque modification. */
function recalculerCnps(db, p, lignes) {
  const e = db.prepare('SELECT contrat FROM employes WHERE id = ?').get(p.employe_id), P = paramsPaie(db);
  if (!e || !['CDI', 'CDD'].includes(e.contrat) || !Number(P.taux_cnps)) return lignes;
  const assiette = lignes.filter(l => l.type === 'gain' && !l.non_soumis).reduce((s, l) => s + l.montant, 0);
  const montant = Math.round((Number(P.plafond_cnps) ? Math.min(assiette, Number(P.plafond_cnps)) : assiette) * Number(P.taux_cnps) / 100);
  const ligne = { type: 'retenue', code: 'CNPS', libelle: `Cotisation retraite CNPS (${String(P.taux_cnps).replace('.', ',')} %)`, montant };
  return lignes.some(l => l.code === 'CNPS') ? lignes.map(l => (l.code === 'CNPS' ? ligne : l)) : [...lignes, ligne];
}
function lignesManuelles(db, u, id, d) {
  const p = lirePaie(db, id);
  if (p.statut !== 'prepare') throw err(409, 'Bulletin validé : il ne se modifie plus.');
  const manuelles = !Array.isArray(d.lignes) ? null : d.lignes.map((l, i) => {
    if (!['gain', 'retenue'].includes(l.type)) throw err(400, `Ligne ${i + 1} : choisissez gain ou retenue.`);
    return { type: l.type, code: 'MANUEL', non_soumis: l.type === 'gain' && !!l.non_soumis, libelle: texte(l.libelle, { label: `Libellé de la ligne ${i + 1}`, max: 120, requis: true }), montant: entier(l.montant, { label: `Montant de la ligne ${i + 1}`, min: 1, max: 50000000 }) };
  });
  /* Garde-fou ITS (reprise 1.8) : l'impôt a son champ propre ; zéro est accepté s'il est saisi explicitement. */
  const its = d.its === undefined || d.its === null || d.its === '' ? undefined : entier(d.its, { label: 'ITS', min: 0, max: 50000000 });
  let lignes = JSON.parse(p.lignes);
  if (manuelles) lignes = [...lignes.filter(l => l.code !== 'MANUEL'), ...manuelles];
  if (its !== undefined) lignes = [...lignes.filter(l => l.code !== 'ITS'), { type: 'retenue', code: 'ITS', libelle: 'Impôt sur traitements et salaires (ITS)', montant: its }];
  lignes = recalculerCnps(db, p, lignes);
  const t = totaux(lignes);
  if (t.net < 0) throw err(409, `Les retenues (${fcfa(t.retenues)}) dépassent le brut (${fcfa(t.brut)}).`);
  db.prepare('UPDATE paies SET lignes = ?, brut = ?, retenues = ?, net = ? WHERE id = ?').run(JSON.stringify(lignes), t.brut, t.retenues, t.net, id);
  const nm = lignes.filter(l => l.code === 'MANUEL').length;
  R.journal(db, u, 'Ressources humaines', 'Bulletin modifié', `${p.numero} : ${nm} ligne${nm > 1 ? 's' : ''} manuelle${nm > 1 ? 's' : ''}${its !== undefined ? `, ITS ${fcfa(its)}` : ''}, net ${fcfa(t.net)}`);
  return { ...t };
}
function validerPaie(db, u, d) {
  const ids = d.id ? [Number(d.id)] : db.prepare("SELECT id FROM paies WHERE periode = ? AND statut = 'prepare'").all(periodeValide(d.periode)).map(x => x.id);
  if (!ids.length) throw err(409, 'Aucun bulletin à valider.');
  /* Garde-fou : un salarié (CDI, CDD) ne peut pas être payé sans ITS saisi explicitement (zéro compris). */
  const sansIts = ids.map(id => db.prepare('SELECT p.*, e.nom, e.prenoms, e.contrat FROM paies p JOIN employes e ON e.id = p.employe_id WHERE p.id = ?').get(id))
    .filter(p => p && p.statut === 'prepare' && ['CDI', 'CDD'].includes(p.contrat) && !JSON.parse(p.lignes).some(l => l.code === 'ITS'));
  if (sansIts.length) throw err(409, `ITS non saisi pour ${sansIts.map(p => nomEmploye(p)).join(', ')} : saisissez l’impôt calculé par le comptable (zéro si le salaire n’est pas imposable), puis validez.`);
  return db.transaction(() => {
    for (const id of ids) { const p = lirePaie(db, id); if (p.statut !== 'prepare') throw err(409, `${p.numero} n’est pas à valider.`); db.prepare("UPDATE paies SET statut = 'valide', valide_par = ?, valide_le = ? WHERE id = ?").run(u.id, maintenant(), id); }
    R.journal(db, u, 'Ressources humaines', 'Paie validée', `${ids.length} bulletin${ids.length > 1 ? 's' : ''} validé${ids.length > 1 ? 's' : ''}`);
    return { valides: ids.length };
  })();
}
function payerPaie(db, u, id, d) {
  const p = lirePaie(db, id);
  if (p.statut !== 'valide') throw err(409, p.statut === 'prepare' ? 'Bulletin non validé par la direction.' : 'Bulletin déjà payé ou annulé.');
  if (!MODES_PAIEMENT.includes(d.mode)) throw err(400, 'Choisissez le mode de paiement.');
  db.prepare("UPDATE paies SET statut = 'paye', paye_par = ?, paye_le = ?, mode_paiement = ?, reference = ? WHERE id = ?").run(u.id, maintenant(), d.mode, texte(d.reference, { label: 'Référence', max: 60 }) || null, id);
  R.journal(db, u, 'Ressources humaines', 'Salaire payé', `${p.numero} : ${fcfa(p.net)} par ${d.mode.toLowerCase()}`);
  return { ok: true };
}
function annulerPaie(db, u, id, d) {
  const p = lirePaie(db, id);
  if (!['prepare', 'valide'].includes(p.statut)) throw err(409, 'Un bulletin payé ou déjà annulé ne s’annule plus.');
  if (p.statut === 'valide' && !peut(u, 'paie_valider') && !peut(u, 'supprimer')) throw err(403, 'Seul l’administrateur annule un bulletin validé.');
  const motif = texte(d.motif, { label: 'Motif d’annulation', max: 200, requis: true });
  return db.transaction(() => {
    db.prepare("UPDATE paies SET statut = 'annule', annule_le = ?, motif_annulation = ? WHERE id = ?").run(maintenant(), motif, id);
    db.prepare('UPDATE avances_salaire SET paie_id = NULL WHERE paie_id = ?').run(id);
    R.journal(db, u, 'Ressources humaines', 'Bulletin annulé', `${p.numero} : ${motif}`, { niveau: 'alerte' });
    return { ok: true };
  })();
}
function accorderAvance(db, u, d) {
  const e = db.prepare('SELECT * FROM employes WHERE id = ? AND actif = 1').get(Number(d.employe_id));
  if (!e) throw err(400, 'Choisissez un employé actif.');
  const montant = entier(d.montant, { label: 'Montant de l’avance', min: 1, max: Math.max(e.salaire_base, 1000000) });
  const id = db.prepare('INSERT INTO avances_salaire(employe_id, montant, motif, accorde_le, accorde_par) VALUES (?,?,?,?,?)')
    .run(e.id, montant, texte(d.motif, { label: 'Motif', max: 200 }) || null, maintenant(), u.id).lastInsertRowid;
  R.journal(db, u, 'Ressources humaines', 'Avance sur salaire', `${e.matricule} ${nomEmploye(e)} : ${fcfa(montant)}, déduite de la prochaine paie`);
  return { id };
}
function sauverParametresPaie(db, u, d) {
  const taux = Number(String(d.taux_cnps == null ? '' : d.taux_cnps).replace(',', '.'));
  if (!isFinite(taux) || taux < 0 || taux > 30) throw err(400, 'Taux CNPS : pourcentage entre 0 et 30.');
  const v = { rh_taux_cnps: String(taux), rh_plafond_cnps: String(entier(d.plafond_cnps, { label: 'Plafond CNPS', min: 0, max: 100000000 })),
    rh_cmu: String(entier(d.cmu, { label: 'CMU', min: 0, max: 100000 })), rh_cnps_employeur: texte(d.cnps_employeur, { label: 'N° employeur CNPS', max: 30 }) || '' };
  const avant = paramsPaie(db);
  for (const [k, x] of Object.entries(v)) db.prepare('INSERT INTO parametres(cle, valeur) VALUES (?, ?) ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur').run(k, x);
  R.journal(db, u, 'Ressources humaines', 'Paramètres de paie', `CNPS ${v.rh_taux_cnps} %, plafond ${v.rh_plafond_cnps}, CMU ${v.rh_cmu}`, { avant, apres: v, niveau: 'alerte' });
  return { ok: true };
}

/* ---------- État de l'écran ---------- */
function etat(db, u, q = {}) {
  const lundi = lundiDe(/^\d{4}-\d{2}-\d{2}$/.test(q.lundi || '') ? q.lundi : jourLocal()), periode = /^\d{4}-(0[1-9]|1[0-2])$/.test(q.periode || '') ? q.periode : jourLocal().slice(0, 7);
  const salaires = peut(u, 'paie_preparer') || peut(u, 'paie_valider') || peut(u, 'paie_payer');
  const maintenantMin = (() => { const d = new Date(); return Math.round(new Date(jourLocal() + 'T00:00:00Z').getTime() / 864e5) * 1440 + d.getHours() * 60 + d.getMinutes(); })();
  return {
    lundi, periode, voir_salaires: salaires, constantes: { FONCTIONS, CONTRATS, MODES_PAIEMENT, TYPES_CRENEAU },
    employes: db.prepare('SELECT e.*, c.nom AS compte FROM employes e LEFT JOIN utilisateurs c ON c.id = e.utilisateur_id ORDER BY e.actif DESC, e.nom, e.prenoms').all()
      .map(e => (salaires ? e : { ...e, salaire_base: null, taux_garde: null, taux_vacation: null })),
    comptes_libres: comptesLibres(db).map(c => ({ id: c.id, nom: c.nom, roles: c.roles })),
    planning: planning(db, lundi, ajouterJours(lundi, 6)),
    en_poste: planning(db, ajouterJours(jourLocal(), -1), jourLocal()).filter(c => { const [a, b] = intervalle(c); return a <= maintenantMin && maintenantMin < b && !['conge', 'absence'].includes(c.type); }),
    paies: salaires ? db.prepare('SELECT p.*, e.matricule, e.nom, e.prenoms, e.fonction, e.contrat, e.numero_cnps, e.embauche_le FROM paies p JOIN employes e ON e.id = p.employe_id WHERE p.periode = ? ORDER BY p.statut = \'annule\', e.nom').all(periode)
      .map(p => ({ ...p, lignes: JSON.parse(p.lignes) })) : [],
    avances: salaires ? db.prepare('SELECT a.*, e.matricule, e.nom, e.prenoms FROM avances_salaire a JOIN employes e ON e.id = a.employe_id WHERE a.paie_id IS NULL ORDER BY a.id').all() : [],
    parametres: salaires ? paramsPaie(db) : null
  };
}

module.exports = { FONCTIONS, CONTRATS, MODES_PAIEMENT, TYPES_CRENEAU, sauverEmploye, archiverEmploye, reprendreComptes, ajouterCreneau, annulerCreneau, recopierSemaine,
  monPlanning, preparerPaie, lignesManuelles, validerPaie, payerPaie, annulerPaie, accorderAvance, sauverParametresPaie, etat, intervalle, lundiDe };
