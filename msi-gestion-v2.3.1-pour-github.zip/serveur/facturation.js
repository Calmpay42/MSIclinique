'use strict';
/* Avances et dépôts des patients (CAI-10) et factures récapitulatives (CAI-07). */
const { pad, maintenant, jourDe, fmt, err, texte, entier } = require('./outils');
const R = require('./regles');
const C = require('./caisse');

const numero = (db, prefixe) => { const a = new Date().getFullYear(); return `${prefixe}-${a}-${pad(R.suivant(db, `avance:${prefixe}:${a}`), 5)}`; };
const insererMouvement = (db, m) => db.prepare(`INSERT INTO avances(numero, patient_id, type, montant, mode, reference, session_id, recu_id, demande_id, motif, cree_le, cree_par, verse_le)
  VALUES (@numero, @patient_id, @type, @montant, @mode, @reference, @session_id, @recu_id, @demande_id, @motif, @cree_le, @cree_par, @verse_le)`).run({
  reference: null, session_id: null, recu_id: null, demande_id: null, motif: null, verse_le: null, cree_le: maintenant(), ...m }).lastInsertRowid;

function deposer(db, u, d) {
  const s = C.sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Ouvrez votre caisse avant de recevoir une avance.');
  const p = R.patient(db, Number(d.patient_id));
  if (!p || p.fusionne_dans) throw err(404, 'Patient introuvable.');
  const montant = entier(d.montant, { label: 'Montant de l’avance', min: 500, max: 50000000 });
  const mode = String(d.mode || '');
  if (!R.MODES.includes(mode) || mode === R.AVANCE) throw err(400, 'Mode de paiement inconnu.');
  const reference = mode === 'Espèces' ? null : texte(d.reference, { label: 'Référence', max: 60, requis: true });
  if (reference && db.prepare('SELECT 1 FROM paiements WHERE mode = ? AND reference = ? COLLATE NOCASE UNION SELECT 1 FROM avances WHERE mode = ? AND reference = ? COLLATE NOCASE').get(mode, reference, mode, reference)) {
    throw err(409, `Référence ${reference} déjà utilisée.`);
  }
  const motif = texte(d.motif, { label: 'Objet de l’avance', max: 160, requis: true });
  return db.transaction(() => {
    const num = numero(db, 'DEP');
    const id = insererMouvement(db, { numero: num, patient_id: p.id, type: 'depot', montant, mode, reference, session_id: s.id, motif, cree_par: u.id });
    R.journal(db, u, 'Caisse', 'Avance reçue', `${num} : ${fmt(montant)} (${mode}) de ${R.nomPatient(p)}, objet : ${motif}`);
    return { id, numero: num, solde: R.soldeAvance(db, p.id) };
  })();
}
/* Restitution automatique d'une avance utilisée sur un reçu ensuite annulé (aucun mouvement d'espèces). */
function restituer(db, u, patientId, montant, recuId, motif) {
  insererMouvement(db, { numero: numero(db, 'DEP'), patient_id: patientId, type: 'depot', montant, mode: R.AVANCE, recu_id: recuId, motif, cree_par: u.id });
}
/* Le remboursement du solde passe par la direction, puis est versé par une caisse ouverte. */
function demanderRemboursement(db, u, d) {
  const p = R.patient(db, Number(d.patient_id));
  if (!p) throw err(404, 'Patient introuvable.');
  const solde = R.soldeAvance(db, p.id);
  const montant = entier(d.montant, { label: 'Montant à rembourser', min: 1, max: 50000000 });
  if (montant > solde) throw err(409, `Solde d’avance insuffisant : ${fmt(solde)}.`);
  const motif = texte(d.motif, { label: 'Motif du remboursement', max: 300, requis: true });
  const deja = db.prepare("SELECT donnees FROM demandes WHERE type = 'remboursement_avance' AND statut = 'en_attente'").all().some(x => JSON.parse(x.donnees).patient_id === p.id);
  if (deja) throw err(409, 'Un remboursement est déjà en attente pour ce patient.');
  db.transaction(() => {
    db.prepare('INSERT INTO demandes(type, donnees, motif, demandeur_id, cree_le) VALUES (?,?,?,?,?)')
      .run('remboursement_avance', JSON.stringify({ patient_id: p.id, patient: R.nomPatient(p), montant }), motif, u.id, maintenant());
    R.journal(db, u, 'Caisse', 'Demande de remboursement d’avance', `${fmt(montant)} pour ${R.nomPatient(p)}, motif : ${motif}`, { niveau: 'alerte' });
  })();
}
function appliquerRemboursement(db, u, dem, x) {
  if (x.montant > R.soldeAvance(db, x.patient_id)) throw err(409, 'Le solde d’avance a changé : remboursement impossible.');
  insererMouvement(db, { numero: numero(db, 'RMB'), patient_id: x.patient_id, type: 'remboursement', montant: x.montant, mode: 'Espèces', demande_id: dem.id, motif: dem.motif, cree_par: u.id });
}
function verser(db, u, id) {
  const s = C.sessionOuverte(db, u.id);
  if (!s) throw err(409, 'Ouvrez votre caisse pour verser le remboursement.');
  const m = db.prepare("SELECT * FROM avances WHERE id = ? AND type = 'remboursement' AND session_id IS NULL").get(id);
  if (!m) throw err(409, 'Aucun remboursement à verser.');
  db.transaction(() => {
    db.prepare('UPDATE avances SET session_id = ?, verse_le = ? WHERE id = ?').run(s.id, maintenant(), m.id);
    R.journal(db, u, 'Caisse', 'Remboursement d’avance versé', `${m.numero} : ${fmt(m.montant)} à ${R.nomPatient(R.patient(db, m.patient_id))}`);
  })();
}
const mouvements = (db, pid) => ({ solde: R.soldeAvance(db, pid), mouvements: db.prepare('SELECT * FROM avances WHERE patient_id = ? ORDER BY id DESC LIMIT 100').all(pid) });
const aVerser = db => db.prepare("SELECT a.*, p.nom, p.prenoms, p.ipp FROM avances a JOIN patients p ON p.id = a.patient_id WHERE a.type = 'remboursement' AND a.session_id IS NULL ORDER BY a.id").all();

/* Facture récapitulative d'un passage : numérotée, figée, avec la répartition patient et assureur. */
function creerFacture(db, u, d) {
  const v = R.passage(db, Number(d.passage_id));
  if (!v || !v.patient_id) throw err(404, 'Passage introuvable.');
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0 ORDER BY id').all(v.id);
  if (!bons.length) throw err(409, 'Aucun acte à facturer sur ce passage.');
  const p = R.patient(db, v.patient_id), pm = R.params(db);
  const nomAss = id => (id ? (db.prepare('SELECT nom FROM assureurs WHERE id = ?').get(id) || {}).nom : null);
  const lignes = bons.map(b => {
    const m = R.montants(b), r = b.recu_id ? db.prepare('SELECT numero FROM recus WHERE id = ?').get(b.recu_id) : null;
    return { date: jourDe(b.cree_le), code: b.code, libelle: b.libelle, quantite: b.quantite, prix: b.prix, ...m, taux: b.taux, assureur: nomAss(b.assureur_id), paye: !!b.paye, recu: r ? r.numero : null };
  });
  const somme = k => lignes.reduce((s, l) => s + l[k], 0);
  const totaux = { total: somme('total'), part_assureur: somme('pa'), remise: somme('remise'), part_patient: somme('net'),
    regle: lignes.filter(l => l.paye).reduce((s, l) => s + l.net, 0), reste: lignes.filter(l => !l.paye).reduce((s, l) => s + l.net, 0) };
  const donnees = {
    patient: { nom: R.nomPatient(p), ipp: p.ipp, naissance: p.naissance, num_assure: p.num_assure }, passage: v.numero, date_passage: jourDe(v.cree_le), accord: v.accord,
    lignes, totaux, etablissement: { raison: pm.raison, forme: pm.forme, adresse: pm.adresse, rccm: pm.rccm, ncc: pm.ncc, telephone: pm.telephone }, formation: !!pm.formation
  };
  const destinataire = texte(d.destinataire, { label: 'Destinataire', max: 160 }) || R.nomPatient(p);
  return db.transaction(() => {
    const a = new Date().getFullYear(), num = `FAC-${a}-${pad(R.suivant(db, 'facture:' + a), 5)}`;
    const id = db.prepare('INSERT INTO factures(numero, patient_id, passage_id, destinataire, donnees, total, cree_le, cree_par) VALUES (?,?,?,?,?,?,?,?)')
      .run(num, p.id, v.id, destinataire, JSON.stringify(donnees), totaux.total, maintenant(), u.id).lastInsertRowid;
    R.journal(db, u, 'Caisse', 'Facture récapitulative', `${num} pour ${R.nomPatient(p)}, passage ${v.numero} : ${fmt(totaux.total)}`);
    return { id, numero: num };
  })();
}
function lireFacture(db, id) {
  const f = db.prepare('SELECT * FROM factures WHERE id = ?').get(id);
  if (!f) throw err(404, 'Facture introuvable.');
  return { ...f, donnees: JSON.parse(f.donnees) };
}

module.exports = { deposer, restituer, demanderRemboursement, appliquerRemboursement, verser, mouvements, aVerser, creerFacture, lireFacture };
