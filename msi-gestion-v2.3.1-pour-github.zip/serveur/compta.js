'use strict';
/* Espace comptable (v2.1). Les écritures sont générées automatiquement, selon le plan SYSCOHADA révisé, à partir des opérations
   déjà enregistrées : reçus et annulations, avances des patients, sorties et écarts de caisse, règlements et rejets des assureurs,
   achats de la pharmacie, paie. Rien n'est ressaisi ; une écriture d'un mois passé ne change pas, car les opérations ne s'effacent pas.
   Les libellés ne portent aucun nom de patient (IPP et numéros de pièce seulement). Le plan de correspondance est réglable. */
const R = require('./regles');
const { err, texte, date: lireDate, joursEntre, bornesPeriode, maintenant } = require('./outils');

const COMPTES = {
  '401': 'Fournisseurs, dettes en compte', '4111': 'Clients, assureurs (tiers payant)', '4191': 'Clients, avances reçues des patients',
  '4198': 'Clients, avoirs à rembourser', '421': 'Personnel, avances et acomptes', '422': 'Personnel, rémunérations dues', '423': 'Personnel, oppositions et retenues',
  '4313': 'CNPS, retraite (part salariale)', '433': 'Autres organismes sociaux (CMU)', '4472': 'État, impôts sur salaires (ITS)',
  '5131': 'Chèques à encaisser', '5211': 'Banque', '5520': 'Monnaie électronique', '5521': 'Orange Money', '5522': 'MTN MoMo', '5523': 'Moov Money', '5524': 'Wave', '5711': 'Caisse',
  '601': 'Achats de marchandises (médicaments)', '605': 'Autres achats', '618': 'Autres frais de transport', '624': 'Entretien, réparations et maintenance',
  '638': 'Autres charges externes', '648': 'Autres impôts et taxes', '651': 'Pertes sur créances clients', '658': 'Charges diverses',
  '6611': 'Appointements, salaires et commissions', '668': 'Autres charges sociales',
  '701': 'Ventes de marchandises (pharmacie)', '7061': 'Prestations : consultations', '7062': 'Prestations : laboratoire', '7063': 'Prestations : imagerie',
  '7064': 'Prestations : hospitalisation', '7065': 'Prestations : soins et autres actes', '709': 'Rabais, remises et ristournes accordés', '758': 'Produits divers'
};
const PLAN_DEFAUT = {
  services: { Consultation: '7061', Laboratoire: '7062', Imagerie: '7063', Hospitalisation: '7064', _autres: '7065', _produits: '701' },
  tresorerie: { 'Espèces': '5711', 'Orange Money': '5521', 'MTN MoMo': '5522', 'Moov Money': '5523', 'Wave': '5524', 'Mobile money': '5520', 'Carte bancaire': '5211', 'Chèque': '5131', 'Virement': '5211', [R.AVANCE]: '4191' },
  depenses: { 60: '605', 61: '618', 62: '624', 63: '638', 64: '648', 65: '658', 66: '668' },
  tiers: { assureurs: '4111', avances: '4191', avoirs: '4198', fournisseurs: '401' },
  divers: { remises: '709', achats: '601', rejets: '651', manquants: '658', excedents: '758', avances_salaire: '5711' },
  paie: { brut: '6611', CNPS: '4313', CMU: '433', ITS: '4472', AVANCE: '421', autres: '423', net: '422' },
  libelles: {}
};
const JOURNAUX = { VE: 'Ventes (recettes)', TR: 'Trésorerie', AC: 'Achats', PA: 'Paie', OD: 'Opérations diverses' };
const SECTIONS = ['services', 'tresorerie', 'depenses', 'tiers', 'divers', 'paie'];

function plan(db) {
  const lu = db.prepare("SELECT valeur FROM meta WHERE cle = 'compta_plan'").get();
  const p = lu ? JSON.parse(lu.valeur) : {}, P = {};
  for (const s of [...SECTIONS, 'libelles']) P[s] = { ...PLAN_DEFAUT[s], ...(p[s] || {}) };
  return { plan: P, comptes: { ...COMPTES, ...P.libelles }, journaux: JOURNAUX, familles: db.prepare('SELECT DISTINCT famille FROM actes ORDER BY famille').all().map(x => x.famille) };
}
function sauverPlan(db, u, d) {
  const actuel = plan(db).plan, nouveau = {}, changes = [];
  for (const s of SECTIONS) {
    nouveau[s] = { ...actuel[s] };
    for (const [k, v] of Object.entries((d && d[s]) || {})) {
      const c = String(v || '').trim();
      if (!/^\d{2,8}$/.test(c)) throw err(400, `Compte invalide pour « ${k} » : de 2 à 8 chiffres.`);
      if (nouveau[s][k] !== c) changes.push(`${k} : ${nouveau[s][k] || '—'} → ${c}`);
      nouveau[s][k] = c;
    }
  }
  nouveau.libelles = { ...actuel.libelles };
  for (const [c, l] of Object.entries((d && d.libelles) || {})) {
    if (!/^\d{2,8}$/.test(c)) throw err(400, `Numéro de compte invalide : ${c}.`);
    const t = texte(l, { label: `Libellé du compte ${c}`, max: 80 });
    if (t) { nouveau.libelles[c] = t; changes.push(`libellé ${c} : ${t}`); } else delete nouveau.libelles[c];
  }
  db.prepare("INSERT INTO meta(cle, valeur) VALUES ('compta_plan', ?) ON CONFLICT(cle) DO UPDATE SET valeur = excluded.valeur").run(JSON.stringify(nouveau));
  R.journal(db, u, 'Comptabilité', 'Plan de correspondance modifié', changes.join(' ; ') || 'aucun changement');
  return plan(db);
}

function lirePeriode(q) {
  const du = lireDate(q.du, { label: 'Début de période' }), au = lireDate(q.au, { label: 'Fin de période' });
  if (au < du || joursEntre(du, au) > 366) throw err(400, 'Période invalide (un an au maximum).');
  return { du, au };
}

function ecritures(db, du, au) {
  const [debut, fin] = bornesPeriode(du, au), P = plan(db).plan, E = [];
  const ecr = (date, journal, piece, libelle, lignes) => { const l = lignes.filter(x => x.debit || x.credit); if (l.length) E.push({ date, journal, piece: String(piece), libelle, lignes: l }); };
  const D = (compte, montant, tiers) => ({ compte, debit: montant || 0, credit: 0, tiers: tiers || null });
  const C = (compte, montant, tiers) => ({ compte, debit: 0, credit: montant || 0, tiers: tiers || null });
  const treso = mode => P.tresorerie[mode] || P.tresorerie['Espèces'];
  const ipp = id => (id && (db.prepare('SELECT ipp FROM patients WHERE id = ?').get(id) || {}).ipp) || null;
  const familles = new Map(db.prepare('SELECT code, famille FROM actes').all().map(a => [String(a.code).toLowerCase(), a.famille]));
  const assureurs = new Map(db.prepare('SELECT id, nom FROM assureurs').all().map(a => [a.id, a.nom]));
  const compteBon = b => b.nature === 'produit' ? P.services._produits : (P.services[familles.get(String(b.code).toLowerCase())] || P.services._autres);
  const vente = r => {
    const produits = new Map(), pa = new Map(); let remise = 0, net = 0;
    for (const b of db.prepare('SELECT * FROM bons WHERE recu_id = ?').all(r.id)) {
      const m = R.montants(b), c = compteBon(b);
      produits.set(c, (produits.get(c) || 0) + m.total);
      if (m.pa) pa.set(b.assureur_id, (pa.get(b.assureur_id) || 0) + m.pa);
      remise += m.remise; net += m.net;
    }
    return { produits, pa, remise, net };
  };
  /* 1. Ventes : produits par service ; trésorerie par mode ; part assureur en créance ; remise. */
  for (const r of db.prepare('SELECT * FROM recus WHERE cree_le >= ? AND cree_le < ? ORDER BY cree_le, id').all(debut, fin)) {
    const x = vente(r), tiers = ipp(r.patient_id);
    ecr(r.cree_le, 'VE', r.numero, `Recette ${r.numero}`, [
      ...db.prepare('SELECT mode, SUM(montant) AS m FROM paiements WHERE recu_id = ? GROUP BY mode ORDER BY mode').all(r.id).map(p => D(treso(p.mode), p.m, p.mode === R.AVANCE ? tiers : null)),
      ...[...x.pa].map(([a, m]) => D(P.tiers.assureurs, m, assureurs.get(a))),
      D(P.divers.remises, x.remise),
      ...[...x.produits].map(([c, m]) => C(c, m))
    ]);
  }
  /* 2. Annulations (contre-passation, part patient en avoir à rembourser), puis remboursements en espèces. */
  for (const r of db.prepare('SELECT * FROM recus WHERE annule = 1 AND annule_le >= ? AND annule_le < ? ORDER BY annule_le').all(debut, fin)) {
    const x = vente(r);
    ecr(r.annule_le, 'VE', r.avoir || `${r.numero}-AN`, `Annulation du reçu ${r.numero}`, [
      ...[...x.produits].map(([c, m]) => D(c, m)), C(P.divers.remises, x.remise),
      ...[...x.pa].map(([a, m]) => C(P.tiers.assureurs, m, assureurs.get(a))), C(P.tiers.avoirs, x.net, ipp(r.patient_id))
    ]);
  }
  for (const r of db.prepare("SELECT r.*, (SELECT COALESCE(SUM(p.montant), 0) FROM paiements p WHERE p.recu_id = r.id AND p.mode = 'Espèces') AS especes FROM recus r WHERE r.rembourse_le >= ? AND r.rembourse_le < ?").all(debut, fin))
    if (r.especes) ecr(r.rembourse_le, 'TR', `${r.avoir || r.numero}-RB`, `Remboursement du reçu ${r.numero}`, [D(P.tiers.avoirs, r.especes, ipp(r.patient_id)), C(treso('Espèces'), r.especes)]);
  /* 3. Avances des patients : dépôts et remboursements (leur utilisation figure dans les recettes). */
  for (const a of db.prepare("SELECT * FROM avances WHERE type IN ('depot', 'remboursement') AND cree_le >= ? AND cree_le < ? ORDER BY cree_le").all(debut, fin)) {
    const t = treso(a.mode || 'Espèces'), tiers = ipp(a.patient_id);
    if (a.type === 'depot') ecr(a.cree_le, 'TR', a.numero, `Avance reçue ${a.numero}`, [D(t, a.montant), C(P.tiers.avances, a.montant, tiers)]);
    else ecr(a.cree_le, 'TR', a.numero, `Avance remboursée ${a.numero}`, [D(P.tiers.avances, a.montant, tiers), C(t, a.montant)]);
  }
  /* 4. Sorties de caisse (catégorie SYSCOHADA) et écarts constatés à la clôture. */
  for (const d of db.prepare('SELECT * FROM depenses WHERE cree_le >= ? AND cree_le < ? ORDER BY cree_le').all(debut, fin))
    ecr(d.cree_le, 'TR', `DEP-${String(d.id).padStart(5, '0')}`, `${d.libelle} (justificatif ${d.justificatif})`, [D(P.depenses[d.categorie] || P.divers.manquants, d.montant), C(treso('Espèces'), d.montant)]);
  for (const s of db.prepare('SELECT * FROM caisse_sessions WHERE fermee_le >= ? AND fermee_le < ? AND ecart IS NOT NULL AND ecart != 0').all(debut, fin)) {
    const piece = `CLO-${String(s.id).padStart(5, '0')}`;
    if (s.ecart < 0) ecr(s.fermee_le, 'TR', piece, `Manquant de caisse, ${s.vacation}`, [D(P.divers.manquants, -s.ecart), C(treso('Espèces'), -s.ecart)]);
    else ecr(s.fermee_le, 'TR', piece, `Excédent de caisse, ${s.vacation}`, [D(treso('Espèces'), s.ecart), C(P.divers.excedents, s.ecart)]);
  }
  /* 5. Assureurs : règlements reçus ; rejets passés en perte (datés du dernier règlement du bordereau). */
  for (const g of db.prepare('SELECT g.*, b.numero AS bordereau, b.assureur_id FROM reglements_assureurs g JOIN bordereaux b ON b.id = g.bordereau_id WHERE g.date >= ? AND g.date <= ? ORDER BY g.date, g.id').all(du, au))
    ecr(g.date, 'TR', g.reference, `Règlement ${assureurs.get(g.assureur_id)}, bordereau ${g.bordereau}`, [D(treso(g.mode), g.montant), C(P.tiers.assureurs, g.montant, assureurs.get(g.assureur_id))]);
  for (const b of db.prepare(`SELECT b.numero, b.assureur_id, COALESCE((SELECT MAX(g.date) FROM reglements_assureurs g WHERE g.bordereau_id = b.id), substr(b.cree_le, 1, 10)) AS jour,
      (SELECT COALESCE(SUM(l.montant), 0) FROM bordereau_lignes l WHERE l.bordereau_id = b.id AND l.rejete = 1 AND l.annule = 0) AS rejete FROM bordereaux b WHERE b.annule = 0`).all())
    if (b.rejete && b.jour >= du && b.jour <= au) ecr(b.jour, 'OD', `${b.numero}-REJ`, `Rejets ${assureurs.get(b.assureur_id)}, bordereau ${b.numero}`, [D(P.divers.rejets, b.rejete), C(P.tiers.assureurs, b.rejete, assureurs.get(b.assureur_id))]);
  /* 6. Achats de la pharmacie : réceptions au prix d'achat. */
  let sansPrix = 0;
  for (const m of db.prepare("SELECT m.id, m.quantite, m.cree_le, l.numero, l.prix_achat, l.fournisseur, p.nom FROM mouvements m JOIN lots l ON l.id = m.lot_id JOIN produits p ON p.id = m.produit_id WHERE m.type = 'reception' AND m.cree_le >= ? AND m.cree_le < ? ORDER BY m.cree_le").all(debut, fin)) {
    if (!m.prix_achat) { sansPrix++; continue; }
    const t = m.quantite * m.prix_achat;
    ecr(m.cree_le, 'AC', `REC-${String(m.id).padStart(5, '0')}`, `${m.nom}, lot ${m.numero} : ${m.quantite} × ${m.prix_achat}`, [D(P.divers.achats, t), C(P.tiers.fournisseurs, t, m.fournisseur || 'Fournisseur non précisé')]);
  }
  /* 7. Paie : charge et dettes à la validation du bulletin, puis paiement ; avances sur salaire. */
  for (const p of db.prepare("SELECT p.*, e.matricule FROM paies p JOIN employes e ON e.id = p.employe_id WHERE p.statut IN ('valide', 'paye') AND p.valide_le >= ? AND p.valide_le < ? ORDER BY p.valide_le").all(debut, fin)) {
    const ret = {};
    for (const l of JSON.parse(p.lignes).filter(x => x.type === 'retenue' && x.montant)) { const c = P.paie[l.code] || P.paie.autres; ret[c] = (ret[c] || 0) + l.montant; }
    ecr(p.valide_le, 'PA', p.numero, `Salaire ${p.periode}, ${p.matricule}`, [D(P.paie.brut, p.brut, p.matricule), ...Object.entries(ret).map(([c, m]) => C(c, m, c === P.paie.AVANCE ? p.matricule : null)), C(P.paie.net, p.net, p.matricule)]);
  }
  for (const p of db.prepare("SELECT p.*, e.matricule FROM paies p JOIN employes e ON e.id = p.employe_id WHERE p.statut = 'paye' AND p.paye_le >= ? AND p.paye_le < ?").all(debut, fin))
    ecr(p.paye_le, 'TR', p.reference || `${p.numero}-PAI`, `Paiement du salaire ${p.periode}, ${p.matricule}`, [D(P.paie.net, p.net, p.matricule), C(treso(p.mode_paiement || 'Virement'), p.net)]);
  for (const a of db.prepare('SELECT a.*, e.matricule FROM avances_salaire a JOIN employes e ON e.id = a.employe_id WHERE a.accorde_le >= ? AND a.accorde_le < ?').all(debut, fin))
    ecr(a.accorde_le, 'TR', `AVS-${String(a.id).padStart(5, '0')}`, `Avance sur salaire, ${a.matricule}`, [D(P.paie.AVANCE, a.montant, a.matricule), C(P.divers.avances_salaire, a.montant)]);
  E.sort((a, b) => a.date.localeCompare(b.date) || a.journal.localeCompare(b.journal) || a.piece.localeCompare(b.piece));
  return { ecritures: E, sansPrix };
}

function journal(db, q) {
  const { du, au } = lirePeriode(q), { comptes } = plan(db), { ecritures: tout, sansPrix } = ecritures(db, du, au);
  const liste = q.journal && JOURNAUX[q.journal] ? tout.filter(e => e.journal === q.journal) : tout;
  for (const e of liste) for (const l of e.lignes) l.libelle_compte = comptes[l.compte] || '';
  const somme = k => liste.reduce((s, e) => s + e.lignes.reduce((t, l) => t + l[k], 0), 0);
  const desequilibrees = tout.filter(e => e.lignes.reduce((s, l) => s + l.debit - l.credit, 0) !== 0).map(e => e.piece);
  return { du, au, journaux: JOURNAUX, ecritures: liste, totaux: { debit: somme('debit'), credit: somme('credit') },
    controles: { equilibre: !desequilibrees.length, desequilibrees, receptions_sans_prix: sansPrix } };
}
function balance(db, q) {
  const { du, au } = lirePeriode(q), { comptes } = plan(db), parCompte = new Map();
  for (const e of ecritures(db, du, au).ecritures) for (const l of e.lignes) {
    const x = parCompte.get(l.compte) || { compte: l.compte, libelle: comptes[l.compte] || '', debit: 0, credit: 0 };
    x.debit += l.debit; x.credit += l.credit; parCompte.set(l.compte, x);
  }
  const lignes = [...parCompte.values()].sort((a, b) => a.compte.localeCompare(b.compte))
    .map(x => ({ ...x, solde_debiteur: Math.max(x.debit - x.credit, 0), solde_crediteur: Math.max(x.credit - x.debit, 0) }));
  const classe = n => lignes.filter(x => x.compte.startsWith(n));
  const produits = classe('7').reduce((s, x) => s + x.credit - x.debit, 0), charges = classe('6').reduce((s, x) => s + x.debit - x.credit, 0);
  return { du, au, comptes: lignes, totaux: { debit: lignes.reduce((s, x) => s + x.debit, 0), credit: lignes.reduce((s, x) => s + x.credit, 0) },
    produits, charges, resultat: produits - charges, tresorerie: classe('5').reduce((s, x) => s + x.debit - x.credit, 0),
    creances_assureurs: lignes.filter(x => x.compte === plan(db).plan.tiers.assureurs).reduce((s, x) => s + x.debit - x.credit, 0) };
}
/* Export pour le logiciel du comptable : une ligne par mouvement, séparateur « ; », montants entiers en FCFA. */
function csv(db, q) {
  const j = journal(db, q), champ = v => { const t = String(v == null ? '' : v); return /[;"\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t; };
  const lignes = ['Date;Journal;Pièce;Compte;Libellé du compte;Tiers;Libellé;Débit;Crédit'];
  for (const e of j.ecritures) for (const l of e.lignes)
    lignes.push([e.date.slice(0, 10), e.journal, e.piece, l.compte, l.libelle_compte, l.tiers || '', e.libelle, l.debit || '', l.credit || ''].map(champ).join(';'));
  return { nom: `msi-ecritures-${j.du}-${j.au}.csv`, contenu: '\ufeff' + lignes.join('\r\n') + '\r\n' };
}
module.exports = { COMPTES, PLAN_DEFAUT, JOURNAUX, plan, sauverPlan, ecritures, journal, balance, csv };
