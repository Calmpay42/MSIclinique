'use strict';
/* Pont synchrone vers une base libSQL ou Turso (édition Vercel).
   Le serveur de MSI Gestion parle à SQLite de façon synchrone (interface better-sqlite3). Ce pont conserve cette interface :
   chaque requête est confiée à un fil d'exécution secondaire qui interroge la base, en ligne ou locale, avec le client officiel
   @libsql/client, pendant que le fil principal attend sa réponse (Atomics.wait). Le code métier reste inchangé. */
const { Worker, MessageChannel, receiveMessageOnPort } = require('worker_threads');
const path = require('path');

class ErreurBase extends Error {
  constructor(message, code) { super(message); this.name = 'SqliteError'; this.code = code; }
}
const DELAI_MS = Number(process.env.MSI_PONT_DELAI_MS || 60000);

class Database {
  constructor(cible, options = {}) {
    const texte = String(cible);
    const url = /^(libsql|https?|wss?|file):/.test(texte) ? texte : 'file:' + path.resolve(texte);
    this.name = texte; this.open = true; this.inTransaction = false; this.memory = false; this.readonly = false;
    this._profondeur = 0;
    this._signal = new Int32Array(new SharedArrayBuffer(4));
    const { port1, port2 } = new MessageChannel();
    this._port = port1;
    this._fil = new Worker(path.join(__dirname, 'pont-libsql-fil.js'), {
      workerData: { url, authToken: options.authToken || process.env.TURSO_AUTH_TOKEN || undefined, signal: this._signal, port: port2 },
      transferList: [port2]
    });
    this._fil.unref();
    this._appel({ op: 'ouvrir' });
  }
  _appel(message) {
    Atomics.store(this._signal, 0, 0);
    this._fil.postMessage(message);
    if (Atomics.wait(this._signal, 0, 0, DELAI_MS) === 'timed-out') throw new ErreurBase('La base de données ne répond pas (délai dépassé).', 'MSI_DELAI');
    const r = receiveMessageOnPort(this._port);
    if (!r) throw new ErreurBase('Pont de base de données : réponse absente.', 'MSI_PONT');
    if (r.message.erreur) throw new ErreurBase(r.message.erreur.message, r.message.erreur.code);
    return r.message.resultat;
  }
  prepare(sql) { return new Instruction(this, sql); }
  exec(sql) { this._appel({ op: 'exec', sql }); return this; }
  pragma(texte, options = {}) {
    const lignes = this._appel({ op: 'pragma', texte }) || [];
    return options.simple ? (lignes[0] ? Object.values(lignes[0])[0] : undefined) : lignes;
  }
  transaction(fn) {
    const db = this;
    const enveloppe = function (...args) {
      const niveau = db._profondeur, nom = 'msi_p' + niveau;
      db._appel({ op: niveau === 0 ? 'debut' : 'point', nom });
      db._profondeur++; db.inTransaction = true;
      let resultat;
      try {
        resultat = fn.apply(this, args);
      } catch (e) {
        db._profondeur--;
        try { db._appel({ op: niveau === 0 ? 'annuler' : 'revenir', nom }); } catch (_) { /* l'erreur d'origine prime */ }
        if (niveau === 0) db.inTransaction = false;
        throw e;
      }
      db._profondeur--;
      db._appel({ op: niveau === 0 ? 'valider' : 'liberer', nom });
      if (niveau === 0) db.inTransaction = false;
      return resultat;
    };
    enveloppe.deferred = enveloppe.immediate = enveloppe.exclusive = enveloppe;
    return enveloppe;
  }
  // Copie complète de la base dans un fichier SQLite (même usage que better-sqlite3 : la sauvegarde chiffre ensuite ce fichier).
  backup(destination) {
    return new Promise((ok, echec) => {
      try { this._appel({ op: 'copie', dest: path.resolve(String(destination)) }); ok({ totalPages: 0, remainingPages: 0 }); } catch (e) { echec(e); }
    });
  }
  close() {
    if (this.open) { try { this._appel({ op: 'fermer' }); } catch (_) { /* fermeture au mieux */ } this._fil.terminate(); this.open = false; }
    return this;
  }
}

class Instruction {
  constructor(db, sql) { this.database = db; this.source = sql; this.reader = /^\s*(select|with|pragma|values)\b/i.test(sql) || /\breturning\b/i.test(sql); }
  _args(p) {
    if (p.length === 1 && p[0] && typeof p[0] === 'object' && !Array.isArray(p[0]) && !(p[0] instanceof Uint8Array)) return p[0];
    const plats = p.length === 1 && Array.isArray(p[0]) ? p[0] : p;
    return plats.map(v => (typeof v === 'boolean' ? (v ? 1 : 0) : v));
  }
  get(...p) { const r = this.database._appel({ op: 'get', sql: this.source, args: this._args(p) }); return r === null ? undefined : apres(r); }
  all(...p) { return this.database._appel({ op: 'all', sql: this.source, args: this._args(p) }).map(apres); }
  run(...p) { return this.database._appel({ op: 'run', sql: this.source, args: this._args(p) }); }
}
// Les blocs binaires reviennent en Uint8Array : on rend des Buffer, comme better-sqlite3.
function apres(ligne) {
  if (!ligne) return ligne;
  for (const k of Object.keys(ligne)) if (ligne[k] instanceof Uint8Array) ligne[k] = Buffer.from(ligne[k]);
  return ligne;
}

module.exports = Database;
module.exports.SqliteError = ErreurBase;
