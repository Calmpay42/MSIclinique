'use strict';
/* Démarrage du serveur MSI : npm start (production) ou npm start -- --formation (base de formation). */
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');
const { lireConfig } = require('./config');

const conf = lireConfig();
process.env.TZ = conf.fuseau || 'Africa/Abidjan';

const { ouvrir } = require('./db');
const { creerApp } = require('./app');
const { creerSauvegardeur } = require('./sauvegarde');

if (!fs.existsSync(conf.fichier)) {
  console.error(`\nBase introuvable : ${conf.fichier}\nLancez d’abord : npm run ${conf.formation ? 'formation' : 'initialiser'}\n`);
  process.exit(1);
}
const db = ouvrir(conf.fichier);
require('./donnees-initiales').completerReferentiels(db);
const sauvegardeur = creerSauvegardeur(db, { ...conf.sauvegarde, dossier_donnees: conf.dossier_donnees });
const app = creerApp(db, { sauvegardeur, enLigne: !!conf.en_ligne });

const dossierCert = path.join(conf.dossier_donnees, 'certificats');
const fCle = path.join(dossierCert, 'cle.pem'), fCert = path.join(dossierCert, 'cert.pem');
const tls = fs.existsSync(fCle) && fs.existsSync(fCert);
const serveur = tls ? https.createServer({ key: fs.readFileSync(fCle), cert: fs.readFileSync(fCert) }, app) : http.createServer(app);

serveur.listen(conf.port, conf.hote || '0.0.0.0', () => {
  const proto = tls ? 'https' : 'http';
  const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
  console.log(`\nMSI Gestion ${require('../package.json').version}${conf.formation ? '  (BASE DE FORMATION)' : ''}`);
  console.log(`Base : ${conf.fichier}`);
  console.log(`Sur ce poste : ${proto}://localhost:${conf.port}`);
  if (conf.en_ligne) console.log('Mode EN LIGNE : accès par le relais HTTPS (nom de domaine de la clinique) ; connexions non chiffrées refusées.');
  else for (const ip of ips) console.log(`Depuis les autres postes : ${proto}://${ip}:${conf.port}`);
  console.log(`Sauvegardes : ${conf.sauvegarde.dossier}${conf.sauvegarde.dossier_cloud ? ' + ' + conf.sauvegarde.dossier_cloud : ' (aucune copie cloud configurée)'}\n`);
});
sauvegardeur.demarrer();

function arret() {
  sauvegardeur.arreter();
  serveur.close();
  try { db.close(); } catch (e) { /* déjà fermée */ }
  process.exit(0);
}
process.on('SIGINT', arret);
process.on('SIGTERM', arret);
