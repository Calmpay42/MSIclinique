'use strict';
/* Fil d'exécution secondaire du pont libSQL : il interroge la base avec le client officiel @libsql/client
   et répond au fil principal (voir pont-libsql.js). Une seule requête à la fois : le fil principal attend chaque réponse. */
const { workerData, parentPort } = require('worker_threads');
const { createClient } = require('@libsql/client');
const { url, authToken, signal, port } = workerData;
const LOCAL = url.startsWith('file:');
let client = null, tx = null;

const enObjets = r => r.rows.map(rang => {
  const o = {};
  r.columns.forEach((c, i) => {
    let v = rang[i];
    if (v instanceof ArrayBuffer) v = new Uint8Array(v);
    else if (typeof v === 'bigint') v = Number(v);
    o[c] = v;
  });
  return o;
});
// Une connexion locale neuve n'a pas les réglages de la précédente : on les rétablit (contraintes de clés étrangères).
async function regler() { if (LOCAL) { await client.execute('PRAGMA foreign_keys = ON'); await client.execute('PRAGMA busy_timeout = 5000'); } }
// Les messages d'erreur de libSQL portent un préfixe technique : on rend le message SQLite d'origine, comme better-sqlite3.
function nettoyer(e) {
  let m = String((e && e.message) || e);
  m = m.replace(/^[A-Z_]+: /, '').replace(/^SQLite error: /, '').replace(/^SQLite input error: /, '');
  return m;
}
/* Copie de la base dans un fichier SQLite. Base locale : copie intégrale (VACUUM INTO). Base en ligne : reconstruction table
   par table (tables, puis données, puis compteurs, index, vues et déclencheurs, pour qu'aucun déclencheur ne joue pendant la copie). */
async function copier(dest) {
  const fs = require('fs');
  for (const f of [dest, dest + '-wal', dest + '-shm']) { try { fs.unlinkSync(f); } catch (_) { /* absent */ } }
  if (LOCAL && !process.env.MSI_PONT_COPIE_LOGIQUE) { await client.execute({ sql: 'VACUUM INTO ?', args: [dest] }); return; }
  const q = n => '"' + String(n).replace(/"/g, '""') + '"';
  const dst = createClient({ url: 'file:' + dest });
  try {
    const objets = enObjets(await client.execute("SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite\\_%' ESCAPE '\\' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'view' THEN 2 ELSE 3 END, rowid"));
    const tables = objets.filter(o => o.type === 'table');
    for (const t of tables) await dst.execute(t.sql);
    for (const t of tables) {
      for (let decalage = 0; ; decalage += 500) {
        const r = await client.execute(`SELECT * FROM ${q(t.name)} LIMIT 500 OFFSET ${decalage}`);
        if (!r.rows.length) break;
        const cols = r.columns.map(q).join(', '), marques = r.columns.map(() => '?').join(', ');
        await dst.batch(r.rows.map(rang => ({ sql: `INSERT INTO ${q(t.name)} (${cols}) VALUES (${marques})`,
          args: r.columns.map((_, i) => (rang[i] instanceof ArrayBuffer ? new Uint8Array(rang[i]) : rang[i])) })), 'write');
        if (r.rows.length < 500) break;
      }
    }
    if ((await client.execute("SELECT 1 FROM sqlite_master WHERE name = 'sqlite_sequence'")).rows.length) {
      const seq = enObjets(await client.execute('SELECT name, seq FROM sqlite_sequence'));
      if (seq.length) await dst.batch([{ sql: 'DELETE FROM sqlite_sequence', args: [] }, ...seq.map(s => ({ sql: 'INSERT INTO sqlite_sequence(name, seq) VALUES (?, ?)', args: [s.name, s.seq] }))], 'write');
    }
    for (const o of objets.filter(o => o.type !== 'table')) await dst.execute(o.sql);
    const uv = enObjets(await client.execute('PRAGMA user_version'))[0];
    if (uv) await dst.execute(`PRAGMA user_version = ${Number(Object.values(uv)[0]) || 0}`);
  } finally { dst.close(); }
}
async function traiter(m) {
  const cible = tx || client;
  switch (m.op) {
    case 'ouvrir': client = createClient({ url, authToken, intMode: 'number' }); await regler(); return null;
    case 'exec': await cible.executeMultiple(m.sql); return null;
    case 'pragma': {
      const p = m.texte.trim().toLowerCase();
      if (!LOCAL && /^(journal_mode|synchronous|busy_timeout)\b/.test(p)) return [];
      return enObjets(await cible.execute('PRAGMA ' + m.texte));
    }
    case 'get': { const l = enObjets(await cible.execute({ sql: m.sql, args: m.args })); return l.length ? l[0] : null; }
    case 'all': return enObjets(await cible.execute({ sql: m.sql, args: m.args }));
    case 'run': {
      const r = await cible.execute({ sql: m.sql, args: m.args });
      return { changes: r.rowsAffected, lastInsertRowid: r.lastInsertRowid === undefined ? 0 : Number(r.lastInsertRowid) };
    }
    case 'debut': tx = await client.transaction('write'); return null;
    case 'valider': try { await tx.commit(); } finally { tx = null; await regler(); } return null;
    case 'annuler': try { await tx.rollback(); } finally { try { tx.close(); } catch (_) { /* déjà fermée */ } tx = null; await regler(); } return null;
    case 'point': await tx.execute(`SAVEPOINT ${m.nom}`); return null;
    case 'liberer': await tx.execute(`RELEASE ${m.nom}`); return null;
    case 'revenir': await tx.execute(`ROLLBACK TO ${m.nom}`); await tx.execute(`RELEASE ${m.nom}`); return null;
    case 'copie': await copier(m.dest); return null;
    case 'fermer': client.close(); return null;
    default: throw new Error('Opération inconnue : ' + m.op);
  }
}
parentPort.on('message', async m => {
  let reponse;
  try { reponse = { resultat: await traiter(m) }; }
  catch (e) { reponse = { erreur: { message: nettoyer(e), code: (e && (e.code || e.rawCode)) || 'SQLITE_ERROR' } }; }
  port.postMessage(reponse);
  Atomics.store(signal, 0, 1);
  Atomics.notify(signal, 0);
});
