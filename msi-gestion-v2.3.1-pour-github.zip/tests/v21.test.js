'use strict';
/* Recette de la version 2.1 : espace comptable (écritures SYSCOHADA générées depuis les opérations), profil Comptable. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');
const R = require('../serveur/regles');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, pharma, raf, dir1, rh, compt, A1;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, headers: r.headers, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
const jour = new Date().toISOString().slice(0, 10), q = `du=${jour}&au=${jour}`;
const journal = async () => (await compt.get('/api/compta/journal?' + q)).data;
const mouv = (e, c) => e.lignes.filter(l => l.compte === c).reduce((s, l) => ({ debit: s.debit + l.debit, credit: s.credit + l.credit }), { debit: 0, credit: 0 });
let n = 0;
async function patient(extra) {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'compta' + n, prenoms: 'awa', sexe: 'F', naissance: '1985-04-12', telephone: `07 44 00 00 ${String(n).padStart(2, '0')}`, ...extra });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  return p.data.id;
}
async function passagePaye(pid, mode, extra) {
  const v = await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: consultationMG(), ...extra });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0').all(v.data.id);
  const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode, montant: bons.reduce((s, b) => s + R.montants(b).net, 0), reference: mode === 'Espèces' ? undefined : 'REF-' + n }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return db.prepare('SELECT r.* FROM recus r JOIN bons b ON b.recu_id = r.id WHERE b.passage_id = ?').get(v.data.id);
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v21-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('pharma', 'pharmacie'); compte('raf', 'raf'); compte('dir1', 'direction'); compte('rh', 'rh'); compte('compt', 'comptable');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, pharma, raf, dir1, rh, compt] = await Promise.all(['accueil', 'caisse', 'pharma', 'raf', 'dir1', 'rh', 'compt'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
  A1 = db.prepare('SELECT id, nom FROM assureurs WHERE actif = 1 ORDER BY id LIMIT 1').get();
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Recettes : produit par service, trésorerie par mode, part assureur en créance, aucun nom de patient', async () => {
  const r1 = await passagePaye(await patient(), 'Espèces');
  const r2 = await passagePaye(await patient({ assureur_id: A1.id, num_assure: 'CPT-1', taux: 80, validite: '2030-12-31' }), 'Orange Money', { accord: 'ACC-CPT-1' });
  const j = await journal();
  const e1 = j.ecritures.find(e => e.piece === r1.numero);
  assert.equal(e1.journal, 'VE');
  assert.deepEqual([mouv(e1, '7061').credit, mouv(e1, '5711').debit], [10000, 10000]);
  const e2 = j.ecritures.find(e => e.piece === r2.numero);
  assert.equal(mouv(e2, '7061').credit, 10000);
  const creance = e2.lignes.find(l => l.compte === '4111');
  assert.deepEqual([creance.debit, creance.tiers], [8000, A1.nom]);
  assert.equal(mouv(e2, '5521').debit, 2000, 'Orange Money');
  assert.equal(j.controles.equilibre, true);
  assert.equal(j.totaux.debit, j.totaux.credit);
  assert.ok(!/COMPTA\d/i.test(JSON.stringify(j.ecritures)), 'aucun nom de patient dans les écritures');
});

test('Trésorerie et achats : avance par Wave, sortie de caisse, réception de médicaments au prix d’achat', async () => {
  const pid = await patient(), ipp = db.prepare('SELECT ipp FROM patients WHERE id = ?').get(pid).ipp;
  assert.equal((await caisse.post('/api/avances', { patient_id: pid, montant: 30000, mode: 'Wave', reference: 'WAV-CPT-1', motif: 'Caution' })).status, 200);
  assert.equal((await caisse.post('/api/caisse/sortie', { categorie: '62', libelle: 'Réparation du climatiseur', montant: 5000, justificatif: 'FAC-CLIM-1' })).status, 200);
  const prod = db.prepare("SELECT id FROM produits WHERE code = 'AMOX500'").get().id;
  assert.equal((await pharma.post('/api/stock/reception', { produit_id: prod, numero: 'AMX-CPT', peremption: '2030-06-30', quantite: 50, prix_achat: 600, fournisseur: 'Laborex' })).status, 200);
  const j = await journal();
  const av = j.ecritures.find(e => e.libelle.startsWith('Avance reçue'));
  assert.deepEqual([mouv(av, '5524').debit, mouv(av, '4191').credit, av.lignes.find(l => l.compte === '4191').tiers], [30000, 30000, ipp]);
  const dep = j.ecritures.find(e => /Réparation du climatiseur/.test(e.libelle));
  assert.deepEqual([mouv(dep, '624').debit, mouv(dep, '5711').credit], [5000, 5000]);
  const ach = j.ecritures.find(e => /AMX-CPT/.test(e.libelle));
  assert.equal(ach.journal, 'AC');
  assert.deepEqual([mouv(ach, '601').debit, mouv(ach, '401').credit, ach.lignes.find(l => l.compte === '401').tiers], [30000, 30000, 'Laborex']);
});

test('Assureurs : règlement en banque, rejet passé en perte', async () => {
  await passagePaye(await patient({ assureur_id: A1.id, num_assure: 'CPT-2', taux: 80, validite: '2030-12-31' }), 'Espèces', { accord: 'ACC-CPT-2' });
  const b = await raf.post('/api/bordereaux', { assureur_id: A1.id, du: jour, au: jour });
  assert.equal(b.status, 200, JSON.stringify(b.data));
  const lignes = db.prepare('SELECT id, montant FROM bordereau_lignes WHERE bordereau_id = ? ORDER BY id').all(b.data.id);
  assert.ok(lignes.length >= 2);
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/reglements`, { date: jour, mode: 'Virement', reference: 'VIR-CPT-1', montant: lignes[0].montant })).status, 200);
  assert.equal((await raf.post(`/api/bordereaux/${b.data.id}/rejets`, { lignes: [{ id: lignes[1].id, motif: 'Accord expiré' }] })).status, 200);
  const j = await journal();
  const reg = j.ecritures.find(e => e.piece === 'VIR-CPT-1');
  assert.deepEqual([mouv(reg, '5211').debit, mouv(reg, '4111').credit], [lignes[0].montant, lignes[0].montant]);
  const rej = j.ecritures.find(e => e.piece === `${b.data.numero}-REJ`);
  assert.deepEqual([rej.journal, mouv(rej, '651').debit, mouv(rej, '4111').credit], ['OD', lignes[1].montant, lignes[1].montant]);
});

test('Paie : charge et dettes sociales à la validation, paiement en banque', async () => {
  const e = await rh.post('/api/rh/employes', { nom: 'COMPTA', prenoms: 'Salarié', sexe: 'M', fonction: 'Aide-soignant', contrat: 'CDI', embauche_le: '2025-01-06', salaire_base: 200000 });
  assert.equal(e.status, 200, JSON.stringify(e.data));
  const bp = (await rh.post('/api/rh/paies/preparation', { periode: jour.slice(0, 7), employe_id: e.data.id })).data.prepares[0];
  assert.equal((await raf.put(`/api/rh/paies/${bp.id}/lignes`, { its: 10000 })).status, 200);
  assert.equal((await dir1.post('/api/rh/paies/validation', { id: bp.id })).status, 200);
  assert.equal((await raf.post(`/api/rh/paies/${bp.id}/paiement`, { mode: 'Virement', reference: 'VIR-SAL-CPT' })).status, 200);
  const p = db.prepare('SELECT * FROM paies WHERE id = ?').get(bp.id), j = await journal();
  const sal = j.ecritures.find(x => x.piece === p.numero);
  assert.equal(sal.journal, 'PA');
  assert.deepEqual([mouv(sal, '6611').debit, mouv(sal, '4313').credit, mouv(sal, '433').credit, mouv(sal, '4472').credit, mouv(sal, '422').credit], [200000, 12600, 500, 10000, p.net]);
  const pai = j.ecritures.find(x => x.piece === 'VIR-SAL-CPT');
  assert.deepEqual([mouv(pai, '422').debit, mouv(pai, '5211').credit], [p.net, p.net]);
  assert.equal(j.controles.equilibre, true, JSON.stringify(j.controles));
});

test('Balance, plan de correspondance réglable par le comptable, export CSV et droits', async () => {
  const b = (await compt.get('/api/compta/balance?' + q)).data;
  assert.equal(b.totaux.debit, b.totaux.credit);
  assert.ok(b.comptes.some(x => x.compte === '7061' && x.libelle === 'Prestations : consultations'), 'compte 7061 dans la balance : ' + JSON.stringify(b.comptes.map(x => x.compte)));
  assert.equal(b.resultat, b.produits - b.charges);
  assert.equal((await caisse.get('/api/compta/journal?' + q)).status, 403, 'la caisse ne voit pas la comptabilité');
  assert.equal((await raf.get('/api/compta/journal?' + q)).status, 200, 'le RAF consulte');
  assert.equal((await raf.put('/api/compta/plan', { services: { Consultation: '70611' } })).status, 403, 'le RAF ne règle pas le plan');
  assert.equal((await compt.put('/api/compta/plan', { services: { Consultation: '7x' } })).status, 400);
  assert.equal((await compt.put('/api/compta/plan', { services: { Consultation: '70611' }, libelles: { '70611': 'Consultations de médecine générale' } })).status, 200);
  const j = await journal();
  assert.ok(j.ecritures.some(e => e.lignes.some(l => l.compte === '70611' && l.libelle_compte === 'Consultations de médecine générale')), 'nouveau compte 70611 utilisé');
  assert.ok(!j.ecritures.some(e => e.lignes.some(l => l.compte === '7061')), 'consultations sur le nouveau compte');
  const x = await compt.get('/api/compta/export?' + q);
  assert.equal(x.status, 200);
  assert.match(x.headers.get('content-disposition'), new RegExp(`msi-ecritures-${jour}-${jour}\\.csv`));
  assert.ok(require('../serveur/compta').csv(db, { du: jour, au: jour }).contenu.startsWith('\ufeff'), 'marque d’encodage UTF-8 (accents dans Excel)');
  assert.ok(x.data.replace(/^\ufeff/, '').startsWith('Date;Journal;Pièce;Compte;Libellé du compte;Tiers;Libellé;Débit;Crédit'), 'en-tête du CSV : ' + x.data.slice(0, 80));
  assert.match(x.data, /;70611;Consultations de médecine générale;/);
  assert.equal((await caisse.get('/api/compta/export?' + q)).status, 403);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Plan de correspondance modifié'").get(), 'modification du plan tracée au journal');
});
