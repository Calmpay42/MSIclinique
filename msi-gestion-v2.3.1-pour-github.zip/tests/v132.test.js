'use strict';
/* Recette de la version 1.3.2 : corrections issues du parcours médecin → pharmacie. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, ophta, pharma, consultation;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null);
const ordonnance = lignes => ophta.post('/api/documents', { type: 'ordonnance', consultation_id: consultation, donnees: { lignes } });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v132-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('ophta', 'medecin', 'Ophtalmologie'); compte('pharma', 'pharmacie');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, ophta, pharma] = await Promise.all(['accueil', 'caisse', 'ophta', 'pharma'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
  const pid = db.prepare("SELECT id FROM patients WHERE nom = 'DIABATÉ'").get().id;
  const acte = db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Ophtalmologie'").get().id;
  const v = (await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: acte })).data;
  const bons = db.prepare('SELECT id, prix FROM bons WHERE passage_id = ?').all(v.id);
  const p = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode: 'Espèces', montant: bons.reduce((s, b) => s + b.prix, 0) }] });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const c = await ophta.post('/api/consultations', { passage_id: v.id });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  consultation = c.data.id;
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Ordonnance : posologie et durée obligatoires pour chaque médicament, message qui nomme la ligne', async () => {
  let r = await ordonnance([{ medicament: 'Amoxicilline 500 mg' }]);
  assert.equal(r.status, 400);
  assert.match(r.data.erreur, /Posologie \(Amoxicilline 500 mg\)/);
  r = await ordonnance([{ medicament: 'Timolol 0,5 %', posologie: '1 goutte matin et soir', duree: '3 mois' }, { medicament: 'Paracétamol 1 g', posologie: '1 comprimé 3 fois par jour' }]);
  assert.equal(r.status, 400);
  assert.match(r.data.erreur, /Durée \(Paracétamol 1 g\)/);
  r = await ordonnance([{ medicament: 'Paracétamol 1 g', posologie: '1 comprimé 3 fois par jour', duree: '5 jours' }]);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const pres = (await pharma.get('/api/prescriptions?passage_id=' + db.prepare('SELECT passage_id FROM consultations WHERE id = ?').get(consultation).passage_id)).data;
  const ligne = pres.flatMap(o => o.lignes).find(l => l.medicament === 'Paracétamol 1 g');
  assert.deepEqual(ligne, { medicament: 'Paracétamol 1 g', posologie: '1 comprimé 3 fois par jour', duree: '5 jours' }, 'la pharmacie reçoit la durée pour calculer la quantité');
});

test('Réception de marchandise sans produit choisi : message explicite', async () => {
  const r = await pharma.post('/api/stock/reception', { produit_id: '', lot: 'L-1', quantite: 10 });
  assert.equal(r.status, 400);
  assert.equal(r.data.erreur, 'Choisissez le produit reçu.');
});

test('Ordonnance : un même médicament ne figure qu’une fois (majuscules et accents ignorés)', async () => {
  const r = await ordonnance([
    { medicament: 'Paracétamol 1 g', posologie: '1 comprimé 3 fois par jour', duree: '5 jours' },
    { medicament: 'paracetamol 1 G', posologie: '1 comprimé le soir', duree: '5 jours' }]);
  assert.equal(r.status, 400);
  assert.match(r.data.erreur, /figure deux fois/);
});
