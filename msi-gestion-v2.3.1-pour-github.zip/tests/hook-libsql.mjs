/* Recette de l'édition Vercel : les scénarios du serveur tournent à travers le pont libSQL (client officiel @libsql/client,
   en mode fichier local), à la place de better-sqlite3. */
import Module from 'module';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const PONT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../serveur/pont-libsql.js');
const origine = Module._resolveFilename;
let n = 0;
Module._resolveFilename = function (demande, parent, ...reste) {
  if (demande === 'better-sqlite3' && !/pont-libsql/.test((parent && parent.filename) || '')) { n++; return PONT; }
  return origine.call(this, demande, parent, ...reste);
};
process.on('exit', () => fs.appendFileSync(path.join(process.env.TMPDIR || '/tmp', 'hook-libsql.log'), `pont-libsql=${n > 0}\n`));
