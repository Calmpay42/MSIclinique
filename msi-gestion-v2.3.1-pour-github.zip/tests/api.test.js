'use strict';
/* Recette automatique des règles de gestion et des verrous anti-fuite, sur un vrai serveur HTTP.
   Lancement : npm test */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Database = require('better-sqlite3');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');
const R = require('../serveur/regles');
const { creerSauvegardeur, dechiffrer, cle } = require('../serveur/sauvegarde');

const MDP = 'motdepasse123';
let db, srv, base, dir;

function client() {
  let cookie = '';
  const req = async (methode, url, corps, entetes = {}) => {
    const r = await fetch(base + url, {
      method: methode,
      headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}), ...entetes },
      body: corps === undefined ? undefined : JSON.stringify(corps)
    });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    const data = (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text();
    return { status: r.status, data };
  };
  return {
    get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}), brut: req,
    async login(login, mdp = MDP) { const r = await req('POST', '/api/connexion', { login, mdp }); assert.equal(r.status, 200, JSON.stringify(r.data)); return this; }
  };
}
const compte = (login, roles) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le) VALUES (?,?,?,?,0,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString());
const patientId = nom => db.prepare('SELECT id FROM patients WHERE nom = ?').get(nom).id;
const acteId = code => db.prepare('SELECT id FROM actes WHERE code = ?').get(code).id;
const produitId = code => db.prepare('SELECT id FROM produits WHERE code = ?').get(code).id;
const bonsDe = pid => db.prepare('SELECT * FROM bons WHERE passage_id = ? ORDER BY id').all(pid);
const net = b => R.montants(b).net;

let accueil, caisse, caisse2, pharma, dir1, dir2, admin, raf, mixte;

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-test-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('caisse2', 'caisse'); compte('pharma', 'pharmacie');
  compte('dir1', 'direction'); compte('dir2', 'direction'); compte('admin', 'admin'); compte('raf', 'raf'); compte('mixte', 'caisse,direction');
  const sauvegardeur = creerSauvegardeur(db, { dossier: path.join(dir, 'sauvegardes'), dossier_cloud: path.join(dir, 'cloud'), intervalle_min: 15, dossier_donnees: dir });
  srv = await new Promise(r => { const s = creerApp(db, { sauvegardeur }).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, caisse2, pharma, dir1, dir2, admin, raf, mixte] = await Promise.all(
    ['accueil', 'caisse', 'caisse2', 'pharma', 'dir1', 'dir2', 'admin', 'raf', 'mixte'].map(l => client().login(l)));
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Sécurité : session obligatoire, en-tête anti-CSRF, blocage après 5 échecs', async () => {
  const anonyme = client();
  assert.equal((await anonyme.get('/api/etat')).status, 401);
  assert.equal((await caisse.brut('POST', '/api/caisse/ouverture', { fonds: 0 }, { 'X-MSI': '0' })).status, 403);
  compte('cible', 'accueil');
  for (let i = 0; i < 5; i++) assert.equal((await anonyme.post('/api/connexion', { login: 'cible', mdp: 'faux' })).status, 401);
  assert.equal((await anonyme.post('/api/connexion', { login: 'cible', mdp: MDP })).status, 429);
});

test('Moindre privilège : chaque profil reste dans sa mission', async () => {
  assert.equal((await accueil.post('/api/caisse/ouverture', { fonds: 0 })).status, 403);
  assert.equal((await pharma.post('/api/passages', { patient_id: 1, type: 'soins' })).status, 403);
  assert.equal((await caisse.post('/api/utilisateurs', { login: 'x', nom: 'X', roles: 'accueil' })).status, 403);
  assert.equal((await accueil.get('/api/exports/journal-caisse?du=2026-01-01&au=2026-01-31')).status, 403);
  assert.equal((await caisse.post('/api/demandes/1/decision', { accepte: true })).status, 403);
  const r = await admin.post('/api/utilisateurs', { login: 'cumul', nom: 'Cumul', roles: ['caisse', 'pharmacie'] });
  assert.equal(r.status, 400, 'un même compte ne peut pas encaisser et délivrer');
});

test('Accueil : doublon probable signalé, création forcée tracée, recherche multicritère', async () => {
  const d = { nom: 'Kouassi', prenoms: 'Aya Marie-Josée', sexe: 'F', naissance: '1991-04-12', telephone: '0708123456' };
  const r1 = await accueil.post('/api/patients', d);
  assert.equal(r1.status, 409);
  assert.equal(r1.data.doublon.ipp, 'P-000001');
  const r2 = await accueil.post('/api/patients', { ...d, forcer: true });
  assert.equal(r2.status, 200);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE niveau = 'alerte' AND detail LIKE '%doublon%'").get());
  assert.equal((await accueil.get('/api/patients?q=0777654321')).data[0].nom, 'DIABATÉ');
  assert.equal((await accueil.get('/api/patients?q=08/06/1978')).data[0].nom, 'DIABATÉ');
  assert.equal((await accueil.get('/api/patients?q=guessan')).data[0].ipp, 'P-000005');
  assert.equal((await dir1.post(`/api/patients/${r2.data.id}/fusion`, { vers_id: 1 })).status, 403, 'seul l’administrateur fusionne');
  const f = await admin.post(`/api/patients/${r2.data.id}/fusion`, { vers_id: 1 });
  assert.equal(f.status, 200);
  assert.equal((await accueil.get('/api/patients?q=kouassi')).data.length, 1, 'le doublon fusionné sort des recherches');
});

test('Couverture : part assureur seulement avec droits valides et accord (RG-ASS-1, RG-ACC-3)', async () => {
  const k = await accueil.post('/api/passages', { patient_id: patientId('KOUASSI'), type: 'consultation', acte_id: acteId('CS-CAR') });
  assert.equal(k.status, 200);
  assert.equal(k.data.sans_accord, true);
  assert.equal(net(bonsDe(k.data.id)[0]), 25000, 'sans accord : facturé comme non assuré');
  assert.equal((await caisse.post(`/api/passages/${k.data.id}/accord`, { accord: 'ASC-2026-1001' })).status, 200);
  assert.equal(net(bonsDe(k.data.id)[0]), 5000, 'accord ajouté : part patient de 20 %');
  const t = await accueil.post('/api/passages', { patient_id: patientId('TRAORÉ'), type: 'consultation', acte_id: acteId('CS-MG'), accord: 'MDG-1' });
  assert.equal(net(bonsDe(t.data.id)[0]), 10000, 'droits expirés : aucune part assureur');
  assert.equal((await caisse.post(`/api/passages/${t.data.id}/accord`, { accord: 'MDG-2' })).status, 409);
});

test('Contrôle gratuit dans le délai, payant au-delà (CAI-12)', async () => {
  const g = await accueil.post('/api/passages', { patient_id: patientId('DIABATÉ'), type: 'controle', acte_id: acteId('CS-MG') });
  assert.equal(g.data.gratuit, true);
  const b = bonsDe(g.data.id)[0];
  assert.equal(b.prix, 0); assert.equal(b.paye, 1);
  const h = await accueil.post('/api/passages', { patient_id: patientId('DIABATÉ'), type: 'controle', acte_id: acteId('CS-CAR') });
  assert.equal(h.data.gratuit, false);
  assert.equal(bonsDe(h.data.id)[0].prix, 25000);
});

let recuKouassi;
test('Caisse : paiements contrôlés, référence obligatoire et unique, numérotation continue', async () => {
  const vk = db.prepare("SELECT id FROM passages WHERE patient_id = ? AND type = 'consultation' ORDER BY id DESC").get(patientId('KOUASSI')).id;
  const bon = bonsDe(vk)[0];
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [] })).status, 409, 'caisse fermée');
  assert.equal((await caisse.post('/api/caisse/ouverture', { fonds: 20000 })).status, 200);
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: 4000 }] })).status, 400, 'somme ≠ net');
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Wave', montant: 5000 }] })).status, 400, 'référence manquante');
  const ok = await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: 2000, remis: 5000 }, { mode: 'Orange Money', montant: 3000, reference: 'OM-889' }] });
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  assert.match(ok.data.numero, /^R-\d{4}-000001$/);
  recuKouassi = ok.data.id;
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: 5000 }] })).status, 409, 'bon déjà payé');
  const vt = db.prepare("SELECT id FROM passages WHERE patient_id = ? ORDER BY id DESC").get(patientId('TRAORÉ')).id;
  const bt = bonsDe(vt)[0];
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bt.id], paiements: [{ mode: 'Orange Money', montant: 10000, reference: 'om-889' }] })).status, 409, 'référence réutilisée');
  const r2 = await caisse.post('/api/caisse/encaissement', { bon_ids: [bt.id], remise: 5, paiements: [{ mode: 'Espèces', montant: 9500 }] });
  assert.equal(r2.status, 200, JSON.stringify(r2.data));
  assert.match(r2.data.numero, /-000002$/);
  const recu = await caisse.get(`/api/recus/${recuKouassi}`);
  assert.equal(recu.data.part_assureur, 20000);
  assert.ok(recu.data.qr_svg.startsWith('<svg'));
  assert.equal((await dir1.get('/api/verification-recu?numero=' + recu.data.numero)).data.authentique, true);
});

test('Remise au-delà du plafond : validation par un autre agent de la direction (CAI-08)', async () => {
  const v = await accueil.post('/api/passages', { patient_id: patientId('KONAN'), type: 'consultation', acte_id: acteId('CS-MG') });
  const b = bonsDe(v.data.id)[0];
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [b.id], remise: 30, paiements: [{ mode: 'Espèces', montant: 7000 }] })).status, 403);
  assert.equal((await caisse.post('/api/caisse/remise', { bon_ids: [b.id], pct: 30, motif: '' })).status, 400, 'motif obligatoire');
  assert.equal((await mixte.post('/api/caisse/remise', { bon_ids: [b.id], pct: 30, motif: 'Indigent, avis social' })).status, 200);
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [b.id], paiements: [{ mode: 'Espèces', montant: 10000 }] })).status, 409, 'bon bloqué en attente');
  const dem = db.prepare("SELECT id FROM demandes WHERE type = 'remise' AND statut = 'en_attente'").get();
  assert.equal((await mixte.post(`/api/demandes/${dem.id}/decision`, { accepte: true })).status, 403, 'on ne valide pas sa propre demande');
  assert.equal((await dir1.post(`/api/demandes/${dem.id}/decision`, { accepte: true })).status, 200);
  assert.equal(net(db.prepare('SELECT * FROM bons WHERE id = ?').get(b.id)), 7000);
});

test('Pharmacie : règle d’or, séparation des fonctions, FEFO, lots périmés bloqués (RG-PHA-1 à 3)', async () => {
  const vk = db.prepare("SELECT id FROM passages WHERE patient_id = ? AND type = 'consultation' ORDER BY id DESC").get(patientId('KOUASSI')).id;
  const o = await pharma.post('/api/ordonnances', { passage_id: vk, lignes: [{ produit_id: produitId('AMOX500'), quantite: 20 }] });
  assert.equal(o.status, 200, JSON.stringify(o.data));
  const bon = db.prepare('SELECT * FROM bons WHERE ordonnance_id = ?').get(o.data.id);
  assert.equal(bon.prix, 3500, 'tarif assurances majeures (ASCOMA)');
  const bloque = await pharma.post(`/api/ordonnances/${o.data.id}/delivrance`);
  assert.equal(bloque.status, 409);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE niveau = 'blocage'").get(), 'tentative journalisée');
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: net(bon) }] })).status, 200);
  const d = await pharma.post(`/api/ordonnances/${o.data.id}/delivrance`);
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.deepEqual(d.data.sorties.map(s => [s.lot, s.quantite]), [['AMX-2602', 18], ['AMX-2610', 2]], 'FEFO, lot périmé AMX-2501 ignoré');
  assert.equal(db.prepare("SELECT quantite FROM lots WHERE numero = 'AMX-2501'").get().quantite, 12, 'lot périmé intact');
  assert.equal((await pharma.post('/api/ordonnances', { comptoir: true, lignes: [{ produit_id: produitId('SAL100'), quantite: 100 }] })).status, 409, 'stock insuffisant');
  assert.equal((await pharma.post('/api/ordonnances', { comptoir: true, lignes: [{ produit_id: produitId('DIAZ5'), quantite: 1 }] })).status, 400, 'psychotrope sans prescripteur');
  // Défense en profondeur : même un compte cumulant les deux profils ne délivre pas ce qu'il a encaissé
  compte('cumul', 'caisse,pharmacie');
  const cumul = await client().login('cumul');
  await cumul.post('/api/caisse/ouverture', { fonds: 0 });
  const o2 = await cumul.post('/api/ordonnances', { comptoir: true, lignes: [{ produit_id: produitId('PARA500'), quantite: 2 }] });
  const b2 = db.prepare('SELECT * FROM bons WHERE ordonnance_id = ?').get(o2.data.id);
  assert.equal((await cumul.post('/api/caisse/encaissement', { bon_ids: [b2.id], paiements: [{ mode: 'Espèces', montant: net(b2) }] })).status, 200);
  assert.equal((await cumul.post(`/api/ordonnances/${o2.data.id}/delivrance`)).status, 403);
  assert.equal((await pharma.post(`/api/ordonnances/${o2.data.id}/delivrance`)).status, 200);
});

test('Urgence : délivrance avant paiement tracée et suivie jusqu’à régularisation', async () => {
  const u = await accueil.post('/api/passages', { patient_id: patientId('N’GUESSAN'), type: 'urgence' });
  assert.equal(u.status, 200, JSON.stringify(u.data));
  const o = await pharma.post('/api/ordonnances', { passage_id: u.data.id, lignes: [{ produit_id: produitId('CEFT1G'), quantite: 1 }] });
  assert.equal((await pharma.post(`/api/ordonnances/${o.data.id}/delivrance`)).status, 200);
  const e = await dir1.get('/api/etat');
  assert.ok(e.data.indicateurs.urgences.n >= 2, 'consultation et produit d’urgence à régulariser');
  assert.equal(e.data.indicateurs.delivrances_sans_paiement, 0, 'aucune délivrance non payée hors urgence');
});

test('Stock : réception contrôlée, ajustement au-delà du seuil soumis à la direction (RG-PHA-4)', async () => {
  const pid = produitId('IBU400');
  assert.equal((await pharma.post('/api/stock/reception', { produit_id: pid, numero: 'IBU-OLD', peremption: '2020-01-01', quantite: 10, prix_achat: 800, fournisseur: 'Laborex' })).status, 409);
  assert.equal((await pharma.post('/api/stock/reception', { produit_id: pid, numero: 'IBU-2701', peremption: '2030-01-31', quantite: 100, prix_achat: 800, fournisseur: 'Laborex' })).status, 200);
  const lot = db.prepare("SELECT id FROM lots WHERE numero = 'IBU-2701'").get().id;
  assert.equal((await pharma.post('/api/stock/ajustement', { lot_id: lot, type: 'casse', quantite: 2, motif: 'Flacon brisé' })).data.en_attente, false);
  const grosse = await pharma.post('/api/stock/ajustement', { lot_id: lot, type: 'inventaire', quantite: -50, motif: 'Écart d’inventaire' });
  assert.equal(grosse.data.en_attente, true, '50 × 800 = 40 000 FCFA > seuil de 20 000');
  const dem = db.prepare("SELECT id FROM demandes WHERE type = 'ajustement'").get().id;
  assert.equal((await dir1.post(`/api/demandes/${dem}/decision`, { accepte: true })).status, 200);
  assert.equal(db.prepare('SELECT quantite FROM lots WHERE id = ?').get(lot).quantite, 48);
});

test('Annulation par avoir validé, remboursement et clôture avec écart (CAI-06, CAI-09, RG-CAI-3)', async () => {
  const recuProduits = db.prepare("SELECT recu_id FROM bons WHERE nature = 'produit' AND delivre = 1 AND recu_id IS NOT NULL").get().recu_id;
  assert.equal((await caisse.post(`/api/recus/${recuProduits}/annulation`, { motif: 'Erreur' })).status, 409, 'produits déjà délivrés');
  const r = db.prepare("SELECT * FROM recus WHERE numero LIKE '%-000002'").get();
  assert.equal((await caisse.post(`/api/recus/${r.id}/annulation`, { motif: '' })).status, 400);
  assert.equal((await caisse.post(`/api/recus/${r.id}/annulation`, { motif: 'Patient reparti sans consulter' })).status, 200);
  const dem = db.prepare("SELECT id FROM demandes WHERE type = 'annulation' AND statut = 'en_attente'").get().id;
  const e0 = (await caisse.get('/api/etat')).data.ma_session.especes.theorique;
  assert.equal((await dir2.post(`/api/demandes/${dem}/decision`, { accepte: true })).status, 403, 'l’annulation d’un reçu est décidée par l’administrateur');
  assert.equal((await admin.post(`/api/demandes/${dem}/decision`, { accepte: true })).status, 200);
  const apres = db.prepare('SELECT * FROM recus WHERE id = ?').get(r.id);
  assert.match(apres.avoir, /^AV-\d{4}-0001$/);
  assert.equal((await caisse.get('/api/etat')).data.ma_session.especes.theorique, e0 - 9500, 'remboursement sorti de la caisse encore ouverte');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM bons WHERE recu_id = ? AND annule = 0').get(r.id).n, 0);
  const sansJustif = await caisse.post('/api/caisse/cloture', { billetage: { b10000: 1 } });
  assert.equal(sansJustif.status, 400);
  const theorique = (await caisse.get('/api/etat')).data.ma_session.especes.theorique;
  const cl = await caisse.post('/api/caisse/cloture', { billetage: { b10000: 2, b5000: 1 }, justification: 'Erreur de rendu de monnaie' });
  assert.equal(cl.status, 200);
  assert.equal(cl.data.ecart, 25000 - theorique);
  assert.ok(db.prepare("SELECT 1 FROM demandes WHERE type = 'ecart' AND statut = 'en_attente'").get(), 'écart soumis à la direction');
  assert.throws(() => db.prepare('UPDATE caisse_sessions SET compte = 0 WHERE caissier_id = (SELECT id FROM utilisateurs WHERE login = ?)').run('caisse'), /clôturée/);
  assert.equal((await caisse.post('/api/caisse/sortie', { categorie: '61', libelle: 'Taxi', montant: 1000, justificatif: 'T1' })).status, 409, 'plus de caisse ouverte');
});

test('Traçabilité : suppression impossible, journal chaîné et vérifiable (verrous 6 et 7)', async () => {
  assert.throws(() => db.prepare('DELETE FROM recus').run(), /interdite/);
  assert.throws(() => db.prepare('DELETE FROM bons').run(), /interdite/);
  assert.throws(() => db.prepare('UPDATE recus SET net = 0').run(), /non modifiable/);
  assert.throws(() => db.prepare("UPDATE audit SET detail = 'effacé'").run(), /non modifiable/);
  assert.throws(() => db.prepare('DELETE FROM patients').run(), /interdite/);
  const v = await dir1.get('/api/audit/verification');
  assert.equal(v.data.ok, true);
  assert.ok(v.data.lignes > 20);
  const numeros = db.prepare('SELECT numero FROM recus ORDER BY id').all().map(r => Number(r.numero.slice(-6)));
  numeros.forEach((n, i) => assert.equal(n, i + 1, 'numérotation sans trou'));
});

test('Tarifs à valider : aucune facturation en production avant validation par la direction', async () => {
  R.ecrireParam(db, 'formation', 0);
  db.prepare("UPDATE actes SET a_valider = 1 WHERE code = 'CS-OPH'").run();
  const r = await accueil.post('/api/passages', { patient_id: patientId('KONAN'), type: 'consultation', acte_id: acteId('CS-OPH') });
  assert.equal(r.status, 409);
  const acte = db.prepare("SELECT * FROM actes WHERE code = 'CS-OPH'").get();
  assert.equal((await accueil.put(`/api/referentiels/actes/${acte.id}`, { ...acte, prix_non: 22000 })).status, 403);
  assert.equal((await raf.put(`/api/referentiels/actes/${acte.id}`, { ...acte, prix_non: 22000 })).status, 200);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Acte modifié' AND avant LIKE '%20000%' AND apres LIKE '%22000%'").get(), 'avant et après journalisés');
  assert.equal((await accueil.post('/api/passages', { patient_id: patientId('KONAN'), type: 'consultation', acte_id: acte.id })).status, 200);
  R.ecrireParam(db, 'formation', 1);
});

test('Comptes : mot de passe provisoire, changement obligatoire, désactivation', async () => {
  const c = await admin.post('/api/utilisateurs', { login: 'awa.k', nom: 'Awa K.', roles: ['accueil'] });
  assert.equal(c.status, 200);
  const awa = await client().login('awa.k', c.data.mdp);
  const e = await awa.get('/api/etat');
  assert.equal(e.status, 403); assert.equal(e.data.changer_mdp, true);
  assert.equal((await awa.post('/api/moi/mdp', { ancien: c.data.mdp, nouveau: 'court' })).status, 400);
  assert.equal((await awa.post('/api/moi/mdp', { ancien: c.data.mdp, nouveau: 'Accueil2026msi' })).status, 200);
  assert.equal((await awa.get('/api/etat')).status, 200);
  const id = db.prepare("SELECT id FROM utilisateurs WHERE login = 'awa.k'").get().id;
  assert.equal((await admin.put(`/api/utilisateurs/${id}`, { nom: 'Awa K.', roles: ['accueil'], actif: false })).status, 200);
  assert.equal((await awa.get('/api/etat')).status, 401, 'compte désactivé : session coupée');
});

test('Imports CSV : tout ou rien, stock initial par lot', async () => {
  const mauvais = 'code;nom;dci;forme;famille;seuil;prix_non;prix_maj;prix_aut;psychotrope\nNEW1;Produit A;;;;5;1000;1200;1100;non\nNEW2;;;;;5;abc;1;1;non\n';
  const r1 = await raf.post('/api/imports/produits', { csv: mauvais });
  assert.equal(r1.status, 400);
  assert.equal(r1.data.erreurs.length, 1);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM produits WHERE code = 'NEW1'").get().n, 0, 'rien importé');
  const bon = 'code;nom;dci;forme;famille;seuil;prix_non;prix_maj;prix_aut;psychotrope;lot;peremption;quantite;prix_achat;fournisseur\n' +
    'NEW1;Produit A;DCI A;Comprimé;Test;5;1000;1200;1100;non;L-1;2030-06-30;50;600;Laborex\n';
  const r2 = await raf.post('/api/imports/produits', { csv: bon });
  assert.equal(r2.status, 200, JSON.stringify(r2.data));
  assert.equal(r2.data.lots, 1);
});

test('Exports Excel et sauvegarde chiffrée restaurable', async () => {
  const j = new Date().toISOString().slice(0, 10);
  const csv = await dir1.get(`/api/exports/journal-caisse?du=${j}&au=${j}`);
  assert.equal(csv.status, 200);
  assert.ok(csv.data.includes('R-') && csv.data.includes('Annulé, avoir AV-'));
  const tp = await raf.get(`/api/exports/tiers-payants?du=${j}&au=${j}`);
  assert.ok(tp.data.includes('ASCOMA'));
  const s = await admin.post('/api/sauvegardes');
  assert.equal(s.status, 200, JSON.stringify(s.data));
  assert.equal(s.data.derniere.cloud, 'copiée');
  const f = path.join(dir, 'cloud', s.data.derniere.fichier);
  const restauree = path.join(dir, 'restauree.db');
  fs.writeFileSync(restauree, dechiffrer(fs.readFileSync(f), cle(dir)));
  const r = new Database(restauree, { readonly: true });
  assert.equal(r.pragma('integrity_check', { simple: true }), 'ok');
  assert.equal(r.prepare('SELECT COUNT(*) n FROM recus').get().n, db.prepare('SELECT COUNT(*) n FROM recus').get().n);
  r.close();
});
