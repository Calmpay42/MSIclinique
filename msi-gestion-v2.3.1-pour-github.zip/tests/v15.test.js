'use strict';
/* Recette de la version 1.5 : infirmerie (constantes et orientation), catalogue tenu par le gérant de la pharmacie,
   téléphone des médecins, rendez-vous pris à l'accueil, poids du patient sur les documents. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, infirmier, medA, medB, pharma, gerant, dir1, admin;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const idDe = login => db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(login).id;
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
let n = 0;
async function passagePaye({ payer = true } = {}) {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'infirmerie' + n, prenoms: 'awa', sexe: 'F', naissance: `2019-02-${String(n).padStart(2, '0')}`, telephone: `07 66 00 00 ${String(n).padStart(2, '0')}` });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const v = await accueil.post('/api/passages', { patient_id: p.data.id, type: 'consultation', acte_id: consultationMG() });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  if (payer) {
    const bons = db.prepare('SELECT id FROM bons WHERE passage_id = ? AND annule = 0').all(v.data.id).map(b => b.id);
    const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons, paiements: [{ mode: 'Espèces', montant: 10000 }] });
    assert.equal(r.status, 200, JSON.stringify(r.data));
  }
  return { patient_id: p.data.id, passage_id: v.data.id };
}
const constantes = (qui, passage_id, valeurs, medecin_id, observation) => qui.post('/api/constantes', { passage_id, valeurs, medecin_id, observation });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v15-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('infirmier', 'infirmier'); compte('meda', 'medecin', 'Médecine générale'); compte('medb', 'medecin', 'Médecine générale');
  compte('pharma', 'pharmacie'); compte('gerant', 'pharmacien'); compte('dir1', 'direction'); compte('admin', 'admin'); compte('ophta', 'medecin', 'Ophtalmologie');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, infirmier, medA, medB, pharma, gerant, dir1, admin] = await Promise.all(['accueil', 'caisse', 'infirmier', 'meda', 'medb', 'pharma', 'gerant', 'dir1', 'admin'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Infirmerie : constantes et orientation, reprises par le médecin choisi, poids sur l’ordonnance', async () => {
  const { passage_id } = await passagePaye();
  const file = (await infirmier.get('/api/etat')).data.file_infirmerie;
  assert.equal(file.find(x => x.passage_id === passage_id).statut, 'a_prendre');
  const r = await constantes(infirmier, passage_id, { ta: '120 / 80', temperature: '38,4', poids: '18', taille: '110', imc: '99', inconnue: '1' }, idDe('meda'), 'Fièvre depuis hier');
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.valeurs.imc, '14,9', 'IMC calculé, valeur envoyée ignorée');
  assert.equal(r.data.valeurs.ta, '120/80');
  assert.ok(!('inconnue' in r.data.valeurs));
  assert.equal((await infirmier.get('/api/etat')).data.file_infirmerie.find(x => x.passage_id === passage_id).statut, 'orientee');
  const fileA = (await medA.get('/api/etat')).data.file_medecin.find(x => x.passage_id === passage_id);
  assert.ok(fileA && fileA.orientation && fileA.orientation.par === 'INFIRMIER');
  const c = await medA.post('/api/consultations', { passage_id });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  const lu = (await medA.get('/api/consultations/' + c.data.id)).data;
  assert.equal(lu.donnees.poids, '18');
  assert.equal(lu.donnees.temperature, '38,4');
  assert.equal(lu.donnees._constantes.par, 'INFIRMIER');
  assert.equal(lu.donnees._constantes.observation, 'Fièvre depuis hier');
  const d = await medA.post('/api/documents', { type: 'ordonnance', consultation_id: c.data.id, donnees: { lignes: [{ medicament: 'Paracétamol 500 mg', posologie: '1/2 comprimé 3 fois par jour', duree: '3 jours' }] } });
  assert.equal(d.status, 200, JSON.stringify(d.data));
  assert.equal((await medA.get('/api/documents/' + d.data.id)).data.mesures.poids, '18');
});

test('Les constantes de l’infirmier ne sont pas remplacées par le formulaire du médecin', async () => {
  const { passage_id } = await passagePaye();
  assert.equal((await constantes(infirmier, passage_id, { ta: '130/85', pouls: '82' }, idDe('meda'))).status, 200);
  const c = (await medA.post('/api/consultations', { passage_id })).data;
  const r = await medA.put('/api/consultations/' + c.id, { donnees: { motif: 'Céphalées', ta: '200/120', pouls: '', _constantes: null } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const lu = (await medA.get('/api/consultations/' + c.id)).data.donnees;
  assert.equal(lu.ta, '130/85');
  assert.equal(lu.pouls, '82');
  assert.equal(lu.motif, 'Céphalées');
  assert.ok(lu._constantes && lu._constantes.par);
  assert.equal((await constantes(infirmier, passage_id, { ta: '110/70' }, idDe('meda'))).status, 409, 'plus de correction après le début de la consultation');
});

test('File du médecin : un patient orienté vers un confrère n’y apparaît pas', async () => {
  const { passage_id } = await passagePaye();
  assert.equal((await constantes(infirmier, passage_id, { temperature: '37' }, idDe('medb'))).status, 200);
  assert.ok(!(await medA.get('/api/etat')).data.file_medecin.some(x => x.passage_id === passage_id));
  assert.ok((await medB.get('/api/etat')).data.file_medecin.some(x => x.passage_id === passage_id));
  assert.equal((await constantes(infirmier, passage_id, { temperature: '37,2' }, idDe('meda'))).status, 200, 'réorientation avant la consultation');
  assert.ok((await medA.get('/api/etat')).data.file_medecin.some(x => x.passage_id === passage_id));
});

test('Infirmerie : bon non réglé, médecin d’une autre spécialité, profils non autorisés', async () => {
  const { passage_id } = await passagePaye({ payer: false });
  const r = await constantes(infirmier, passage_id, { ta: '120/80' }, idDe('meda'));
  assert.equal(r.status, 409);
  assert.match(r.data.erreur, /caisse/);
  const paye = await passagePaye();
  assert.equal((await constantes(infirmier, paye.passage_id, { ta: '12/8/3' }, idDe('meda'))).status, 400);
  assert.equal((await constantes(infirmier, paye.passage_id, {}, idDe('meda'))).status, 400);
  const autre = await constantes(infirmier, paye.passage_id, { ta: '120/80' }, idDe('ophta'));
  assert.equal(autre.status, 400);
  assert.match(autre.data.erreur, /ne consulte pas/);
  assert.equal((await constantes(infirmier, paye.passage_id, { ta: '120/80' }, idDe('accueil'))).status, 400);
  assert.equal((await constantes(accueil, paye.passage_id, { ta: '120/80' }, idDe('meda'))).status, 403);
  assert.equal((await constantes(medA, paye.passage_id, { ta: '120/80' }, idDe('meda'))).status, 403);
});

test('Catalogue : le gérant ajoute un médicament, le prix est validé par la direction', async () => {
  const fiche = { code: 'AMOXI1G', nom: 'Amoxicilline 1 g', dci: 'Amoxicilline', forme: 'Comprimé', famille: 'Antibiotique', seuil: 10, prix_non: 2500, prix_maj: 2200, prix_aut: 2000, psychotrope: 0, actif: 1 };
  assert.equal((await pharma.post('/api/catalogue/produits', fiche)).status, 403, 'un agent de pharmacie ne gère pas le catalogue');
  const r = await gerant.post('/api/catalogue/produits', fiche);
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.a_valider, true);
  const p = (await gerant.get('/api/etat')).data.produits.find(x => x.code === 'AMOXI1G');
  assert.ok(p && p.a_valider === 1);
  assert.equal((await gerant.post('/api/catalogue/produits', fiche)).status, 409, 'code déjà utilisé');
  assert.equal((await dir1.put('/api/referentiels/produits/' + r.data.id, fiche)).status, 200);
  assert.equal(db.prepare('SELECT a_valider FROM produits WHERE id = ?').get(r.data.id).a_valider, 0, 'prix validé par la direction');
  assert.equal((await gerant.put('/api/catalogue/produits/' + r.data.id, { ...fiche, seuil: 20 })).data.a_valider, false, 'seuil changé : prix toujours validé');
  assert.equal((await gerant.put('/api/catalogue/produits/' + r.data.id, { ...fiche, seuil: 20, prix_non: 2700 })).data.a_valider, true, 'prix changé : à revalider');
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Médicament ajouté' AND detail LIKE '%à valider%'").get());
});

test('Téléphone des médecins et rendez-vous pris à l’accueil', async () => {
  const r = await admin.post('/api/utilisateurs', { login: 'drkone', nom: 'Dr KONÉ Ali', roles: ['medecin'], specialites: ['Médecine générale'], telephone: '0707070707', mdp: 'Provisoire-2026' });
  assert.ok(r.status === 200, JSON.stringify(r.data));
  const med = (await accueil.get('/api/etat')).data.medecins.find(m => m.nom === 'Dr KONÉ Ali');
  assert.equal(med.telephone, '07 07 07 07 07');
  assert.deepEqual(med.specialites, ['Médecine générale']);
  assert.equal((await admin.get('/api/utilisateurs')).data.find(u => u.login === 'drkone').telephone, '07 07 07 07 07');
  const pid = (await passagePaye({ payer: false })).patient_id;
  const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const rv = await accueil.post('/api/rdv', { patient_id: pid, date: demain, heure: '09:30', medecin_id: med.id, specialite: 'Médecine générale', motif: 'Contrôle' });
  assert.equal(rv.status, 200, JSON.stringify(rv.data));
  const liste = (await accueil.get('/api/etat')).data.rdv;
  assert.ok(liste.some(x => x.patient_id === pid && x.medecin_id === med.id && x.heure === '09:30'));
});
