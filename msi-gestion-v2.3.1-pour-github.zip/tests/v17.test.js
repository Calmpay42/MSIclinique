'use strict';
/* Recette de la version 1.7 : hospitalisation (admission, chambres standard et VIP, infirmiers assignés, soins, transfert,
   sortie et facturation des journées), chambres dans le paramétrage, notifications du référent et de l'infirmier. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, infirmier, meda, dir1;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const idDe = login => db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(login).id;
const chambre = code => db.prepare('SELECT id FROM chambres WHERE code = ?').get(code).id;
const notifs = async qui => (await qui.get('/api/etat')).data.notifications;
const ilYa = (jours, heure) => { const d = new Date(); d.setUTCDate(d.getUTCDate() - jours); d.setUTCHours(heure, 0, 0, 0); return d.toISOString(); };
let n = 0;
async function patient() {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'sejour' + n, prenoms: 'adjoua', sexe: 'F', naissance: `1975-05-${String(n).padStart(2, '0')}`, telephone: `07 88 00 00 ${String(n).padStart(2, '0')}` });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  return p.data.id;
}
const admettre = async (qui, extra) => qui.post('/api/hospitalisations', { patient_id: await patient(), motif: 'Paludisme grave', medecin_id: idDe('meda'), ...extra });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v17-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('infirmier', 'infirmier'); compte('meda', 'medecin', 'Médecine générale'); compte('dir1', 'direction');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, infirmier, meda, dir1] = await Promise.all(['accueil', 'caisse', 'infirmier', 'meda', 'dir1'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 50000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Admission : séjour numéroté, passage de facturation, infirmier assigné, notifications ; refus contrôlés', async () => {
  const pid = await patient();
  const r = await accueil.post('/api/hospitalisations', { patient_id: pid, motif: 'Paludisme grave', medecin_id: idDe('meda'), chambre_id: chambre('103'), infirmiers: [idDe('infirmier')] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.match(r.data.numero, /^HOS-\d{4}-0001$/);
  const h = db.prepare('SELECT * FROM hospitalisations WHERE id = ?').get(r.data.id);
  assert.equal(db.prepare('SELECT type FROM passages WHERE id = ?').get(h.passage_id).type, 'hospitalisation');
  const e = (await infirmier.get('/api/etat')).data.hospitalisation;
  const x = e.hospitalisations.find(y => y.id === r.data.id);
  assert.equal(x.chambre.code, '103');
  assert.deepEqual(x.infirmiers.map(i => i.nom), ['INFIRMIER']);
  assert.ok((await notifs(meda)).some(t => t.titre === 'Patient hospitalisé' && /chambre 103/.test(t.message)));
  assert.ok((await notifs(infirmier)).some(t => t.titre === 'Patient hospitalisé à votre charge'));
  assert.equal((await accueil.post('/api/hospitalisations', { patient_id: pid, motif: 'Autre', medecin_id: idDe('meda'), chambre_id: chambre('101') })).status, 409, 'déjà hospitalisé');
  const plein = await admettre(accueil, { chambre_id: chambre('103') });
  assert.equal(plein.status, 409);
  assert.match(plein.data.erreur, /complète/);
  assert.equal((await admettre(accueil, { chambre_id: chambre('101'), medecin_id: idDe('caisse') })).status, 400, 'référent non médecin');
  assert.equal((await admettre(caisse, { chambre_id: chambre('101') })).status, 403);
  assert.equal((await accueil.post('/api/passages', { patient_id: await patient(), type: 'hospitalisation' })).status, 400, 'pas d’hospitalisation sans admission');
});

test('Soins : constantes anormales signalées au référent, soin facturé sur le séjour, traçabilité inaltérable', async () => {
  const r = await admettre(meda, { chambre_id: chambre('104'), infirmiers: [idDe('infirmier')] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const c = await infirmier.post(`/api/hospitalisations/${r.data.id}/soins`, { type: 'constantes', valeurs: { ta: '170/100', temperature: '37,2' } });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  assert.deepEqual(c.data.alertes.map(a => a.k), ['ta']);
  assert.ok((await notifs(meda)).some(t => t.titre === 'Alerte en hospitalisation' && t.prioritaire === 1));
  const injection = db.prepare("SELECT id FROM actes WHERE code = 'S-INJ'").get().id;
  const s = await infirmier.post(`/api/hospitalisations/${r.data.id}/soins`, { type: 'soin', acte_id: injection, quantite: 2, description: 'Artésunate IV' });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  const bon = db.prepare('SELECT * FROM bons WHERE id = ?').get(s.data.bon_id);
  assert.equal(bon.quantite, 2);
  assert.equal(bon.origine, 'hospitalisation');
  assert.equal(bon.passage_id, db.prepare('SELECT passage_id FROM hospitalisations WHERE id = ?').get(r.data.id).passage_id);
  assert.equal((await infirmier.post(`/api/hospitalisations/${r.data.id}/soins`, { type: 'observation', description: 'Patient apyrétique, bonne tolérance' })).status, 200);
  assert.equal((await infirmier.post(`/api/hospitalisations/${r.data.id}/soins`, { type: 'soin' })).status, 400);
  assert.equal((await accueil.post(`/api/hospitalisations/${r.data.id}/soins`, { type: 'observation', description: 'x' })).status, 403);
  const d = (await meda.get('/api/hospitalisations/' + r.data.id)).data;
  assert.equal(d.soins.length, 3);
  assert.equal(d.soins[0].type, 'observation', 'historique du plus récent au plus ancien');
  assert.throws(() => db.prepare("UPDATE soins_hospitalisation SET description = 'modifié' WHERE id = ?").run(c.data.id), /ne se modifie pas/);
  assert.throws(() => db.prepare('DELETE FROM soins_hospitalisation WHERE id = ?').run(c.data.id), /Suppression interdite/);
  assert.throws(() => db.prepare('DELETE FROM hospitalisations WHERE id = ?').run(r.data.id), /Suppression interdite/);
});

test('Transfert puis sortie : nuits facturées au tarif de la chambre occupée, encaissement à la caisse', async () => {
  const r = await admettre(accueil, { chambre_id: chambre('102'), infirmiers: [idDe('infirmier')] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const id = r.data.id;
  assert.equal((await infirmier.post(`/api/hospitalisations/${id}/transfert`, { chambre_id: chambre('102') })).status, 400, 'déjà dans cette chambre');
  assert.equal((await infirmier.post(`/api/hospitalisations/${id}/transfert`, { chambre_id: chambre('103') })).status, 409, 'chambre complète');
  /* Séjour réel de trois nuits : admis il y a trois jours en standard, transféré hier en suite VIP. */
  const seg = db.prepare('SELECT id FROM hospitalisation_chambres WHERE hospitalisation_id = ?').get(id).id;
  db.prepare('UPDATE hospitalisations SET admis_le = ? WHERE id = ?').run(ilYa(3, 10), id);
  db.prepare('UPDATE hospitalisation_chambres SET debut = ? WHERE id = ?').run(ilYa(3, 10), seg);
  const t = await meda.post(`/api/hospitalisations/${id}/transfert`, { chambre_id: chambre('201') });
  assert.equal(t.status, 200, JSON.stringify(t.data));
  db.prepare('UPDATE hospitalisation_chambres SET fin = ? WHERE id = ?').run(ilYa(1, 15), seg);
  db.prepare('UPDATE hospitalisation_chambres SET debut = ? WHERE hospitalisation_id = ? AND fin IS NULL').run(ilYa(1, 15), id);
  assert.deepEqual((await meda.get('/api/hospitalisations/' + id)).data.journees, { standard: 2, vip: 1 });
  assert.equal((await infirmier.post(`/api/hospitalisations/${id}/sortie`, { mode: 'Guérison ou amélioration', compte_rendu: 'x' })).status, 403, 'l’infirmier ne prononce pas la sortie');
  assert.equal((await meda.post(`/api/hospitalisations/${id}/sortie`, { mode: 'Partie', compte_rendu: 'x' })).status, 400);
  assert.equal((await meda.post(`/api/hospitalisations/${id}/sortie`, { mode: 'Guérison ou amélioration' })).status, 400, 'compte rendu obligatoire');
  const s = await meda.post(`/api/hospitalisations/${id}/sortie`, { mode: 'Guérison ou amélioration', compte_rendu: 'Évolution favorable sous traitement. Contrôle dans 7 jours.' });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  assert.deepEqual(s.data.journees, { standard: 2, vip: 1 });
  const pass = db.prepare('SELECT passage_id FROM hospitalisations WHERE id = ?').get(id).passage_id;
  const bons = db.prepare("SELECT code, quantite, prix FROM bons WHERE passage_id = ? AND origine = 'hospitalisation' ORDER BY code").all(pass);
  assert.deepEqual(bons.map(b => [b.code, b.quantite, b.prix]), [['HOSP-STD', 2, 15000], ['HOSP-VIP', 1, 35000]]);
  assert.equal(db.prepare('SELECT statut FROM hospitalisations WHERE id = ?').get(id).statut, 'sortie');
  const e = (await accueil.get('/api/etat')).data.hospitalisation;
  assert.deepEqual(e.chambres.find(c => c.code === '201').occupants, [], 'chambre libérée');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM hospitalisation_infirmiers WHERE hospitalisation_id = ? AND retire_le IS NULL').get(id).n, 0);
  const ids = db.prepare('SELECT id FROM bons WHERE passage_id = ? AND paye = 0 AND annule = 0').all(pass).map(b => b.id);
  const enc = await caisse.post('/api/caisse/encaissement', { bon_ids: ids, paiements: [{ mode: 'Espèces', montant: 65000 }] });
  assert.equal(enc.status, 200, JSON.stringify(enc.data));
  assert.equal((await meda.post(`/api/hospitalisations/${id}/soins`, { type: 'observation', description: 'x' })).status, 409, 'séjour clos');
});

test('Chambres : gérées par la direction dans le paramétrage', async () => {
  const r = await dir1.post('/api/referentiels/chambres', { code: '301', nom: 'Suite 301', categorie: 'vip', lits: 1, actif: true });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok((await dir1.get('/api/etat')).data.chambres.some(c => c.code === '301'));
  assert.equal((await dir1.post('/api/referentiels/chambres', { code: '302', categorie: 'luxe', lits: 1 })).status, 400);
  assert.equal((await dir1.post('/api/referentiels/chambres', { code: '301', categorie: 'vip', lits: 1 })).status, 409);
  assert.equal((await accueil.post('/api/referentiels/chambres', { code: '303', categorie: 'vip', lits: 1 })).status, 403);
});

/* Corrections de la reprise 1.7 : quitus de sortie (anti-fuite) et séjour ouvert pour la pharmacie et les examens. */
const chambreStandardLibre = () => db.prepare(`SELECT c.id FROM chambres c WHERE c.actif = 1 AND c.categorie = 'standard' AND c.lits > (SELECT COUNT(*) FROM hospitalisation_chambres hc
  JOIN hospitalisations h ON h.id = hc.hospitalisation_id WHERE hc.chambre_id = c.id AND hc.fin IS NULL AND h.statut = 'en_cours') ORDER BY c.code`).get().id;
const sortieMedicale = (id, cr) => meda.post(`/api/hospitalisations/${id}/sortie`, { mode: 'Guérison ou amélioration', compte_rendu: cr || 'Évolution favorable, sortie autorisée.' });

test('Quitus de sortie : refusé tant que le séjour n’est pas soldé ; la direction peut passer outre avec un motif tracé', async () => {
  await caisse.post('/api/caisse/ouverture', { fonds: 10000 });
  const r = await admettre(accueil, { chambre_id: chambreStandardLibre() });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const id = r.data.id;
  assert.ok((await caisse.get('/api/etat')).data.notifications.some(x => x.titre === 'Admission : caution à encaisser'), 'caisse prévenue de l’admission');
  assert.equal((await caisse.post(`/api/hospitalisations/${id}/quitus`)).status, 409, 'pas de quitus avant la sortie médicale');
  assert.equal((await sortieMedicale(id)).status, 200);
  assert.ok((await caisse.get('/api/etat')).data.notifications.some(x => x.titre === 'Sortie à régler' && x.prioritaire === 1), 'caisse prévenue de la sortie');
  const refus = await caisse.post(`/api/hospitalisations/${id}/quitus`);
  assert.equal(refus.status, 409);
  assert.match(refus.data.erreur, /Reste à payer : 15 000 FCFA/);
  assert.equal((await meda.post(`/api/hospitalisations/${id}/quitus`)).status, 403, 'le médecin ne délivre pas le quitus');
  const pass = db.prepare('SELECT passage_id FROM hospitalisations WHERE id = ?').get(id).passage_id;
  const bons = db.prepare('SELECT id, prix, quantite FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0').all(pass);
  const p = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ mode: 'Espèces', montant: bons.reduce((s, b) => s + b.prix * b.quantite, 0) }] });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  const q = await caisse.post(`/api/hospitalisations/${id}/quitus`);
  assert.equal(q.status, 200, JSON.stringify(q.data));
  assert.equal(q.data.reste, 0);
  assert.equal((await caisse.post(`/api/hospitalisations/${id}/quitus`)).status, 409, 'quitus déjà délivré');
  assert.ok((await caisse.get('/api/hospitalisations/' + id)).data.quitus_le);
  const r2 = await admettre(accueil, { chambre_id: chambreStandardLibre() });
  assert.equal((await sortieMedicale(r2.data.id, 'Sortie à la demande de la famille.')).status, 200);
  assert.equal((await dir1.post(`/api/hospitalisations/${r2.data.id}/quitus`, { motif: 'court' })).status, 400, 'motif exigé');
  const f = await dir1.post(`/api/hospitalisations/${r2.data.id}/quitus`, { motif: 'Patient indigent, prise en charge sociale validée' });
  assert.equal(f.status, 200, JSON.stringify(f.data));
  assert.equal(f.data.reste, 15000);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Quitus de sortie' AND detail LIKE '%malgré 15 000 FCFA%'").get(), 'passe-droit tracé au journal');
});

test('Séjour ouvert : médicaments et examens sur le séjour les jours suivants, plus rien après la sortie', async () => {
  compte('pharma', 'pharmacie');
  const pharma = await client().login('pharma');
  const r = await admettre(accueil, { chambre_id: chambreStandardLibre() });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const id = r.data.id, pass = db.prepare('SELECT passage_id FROM hospitalisations WHERE id = ?').get(id).passage_id;
  db.prepare('UPDATE passages SET cree_le = ? WHERE id = ?').run(ilYa(2, 9), pass);
  db.prepare('UPDATE hospitalisations SET admis_le = ? WHERE id = ?').run(ilYa(2, 9), id);
  db.prepare('UPDATE hospitalisation_chambres SET debut = ? WHERE hospitalisation_id = ?').run(ilYa(2, 9), id);
  assert.ok((await pharma.get('/api/etat')).data.passages.some(v => v.id === pass), 'séjour toujours proposé à la pharmacie');
  const produit = db.prepare("SELECT id FROM produits WHERE code = 'AMOX500'").get().id, glycemie = db.prepare("SELECT id FROM actes WHERE code = 'B-GLY'").get().id;
  const o = await pharma.post('/api/ordonnances', { passage_id: pass, lignes: [{ produit_id: produit, quantite: 2 }] });
  assert.equal(o.status, 200, JSON.stringify(o.data));
  const a = await caisse.post(`/api/passages/${pass}/actes`, { actes: [{ acte_id: glycemie, quantite: 1 }] });
  assert.equal(a.status, 200, JSON.stringify(a.data));
  assert.equal((await sortieMedicale(id, 'Sortie autorisée après deux nuits.')).status, 200);
  assert.equal((await pharma.post('/api/ordonnances', { passage_id: pass, lignes: [{ produit_id: produit, quantite: 1 }] })).status, 409, 'séjour terminé : passage clos');
  assert.equal((await caisse.post(`/api/passages/${pass}/actes`, { actes: [{ acte_id: glycemie, quantite: 1 }] })).status, 409);
});

test('Mise à jour d’une base existante : les tarifs de journée sont créés, à valider par la direction', () => {
  const { tarifsHospitalisation } = require('../serveur/db');
  const b = ouvrir(path.join(dir, 'ancienne.db'));
  init.referentiels(b, { formation: false });
  b.prepare("DELETE FROM actes WHERE code IN ('HOSP-STD', 'HOSP-VIP')").run();
  assert.equal(b.prepare("SELECT COUNT(*) n FROM actes WHERE code LIKE 'HOSP-%'").get().n, 0, 'base 1.6 simulée');
  tarifsHospitalisation(b);
  tarifsHospitalisation(b);
  const t = b.prepare("SELECT code, prix_non, a_valider, actif FROM actes WHERE code LIKE 'HOSP-%' ORDER BY code").all();
  assert.deepEqual(t.map(x => [x.code, x.prix_non, x.a_valider, x.actif]), [['HOSP-STD', 15000, 1, 1], ['HOSP-VIP', 35000, 1, 1]], 'créés une seule fois, à valider');
  b.close();
  const neuve = ouvrir(path.join(dir, 'neuve.db'));
  init.referentiels(neuve, { formation: false });
  assert.equal(neuve.prepare("SELECT COUNT(*) n FROM actes WHERE code LIKE 'HOSP-%'").get().n, 2, 'base neuve : initialisation sans conflit');
  neuve.close();
});
