'use strict';
/* Cohérence du référentiel clinique : à relancer après toute modification de public/js/specialites.js. */
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../public/js/specialites');
const { ACTES } = require('../serveur/donnees-initiales');

test('Chaque spécialité est complète et chaque consultation du catalogue a son formulaire', () => {
  const codes = new Set(ACTES.map(a => a[0]));
  for (const nom of S.noms()) {
    const s = S.SPECIALITES[nom];
    for (const k of ['motifs', 'diagnostics', 'conduites', 'documents']) assert.ok(s[k].length, `${nom} : ${k} vide`);
    for (const c of s.constantes) assert.ok(S.CONSTANTES[c], `${nom} : constante ${c} inconnue`);
    for (const e of s.examens) if (e.code) assert.ok(codes.has(e.code), `${nom} : ${e.code} absent du catalogue`);
    for (const m of s.medicaments) assert.equal(m.length, 4, `${nom} : médicament mal formé`);
    for (const cr of s.comptes_rendus) for (const [mod, v] of Object.entries(cr.modeles)) for (const k of Object.keys(v)) assert.ok(cr.champs.some(c => c.k === k), `${nom}/${cr.cle}/${mod} : champ ${k} hors formulaire`);
    if (s.documents.includes('ordonnance')) assert.ok(s.medicaments.length, `${nom} : ordonnance sans suggestions`);
    assert.ok(!s.documents.includes('lunettes') || nom === 'Ophtalmologie', `${nom} : lunettes hors ophtalmologie`);
  }
  for (const a of ACTES.filter(x => x[2] === 'Consultation')) assert.ok(S.SPECIALITES[a[3]], `consultation sans formulaire : ${a[3]}`);
});

test('Alertes cliniques aux seuils attendus', () => {
  assert.equal(S.alerte('ta', '185/115').niveau, 'bad');
  assert.equal(S.alerte('ta', '15/9').texte, 'Tension élevée');
  assert.equal(S.alerte('pio', '22').niveau, 'warn');
  assert.equal(S.alerte('glycemie', '0,6').texte, 'Hypoglycémie');
  assert.equal(S.alerte('dfg', 25).niveau, 'bad');
  assert.equal(S.alerte('pouls', 140, 'enfant'), null, 'pas de seuil adulte chez l’enfant');
  assert.equal(S.imc(170, 90), 31.1);
  assert.deepEqual(S.terme('2026-06-01', '2026-09-27'), { sa: 16, jours: 6, dpa: '2027-03-08' });
});
