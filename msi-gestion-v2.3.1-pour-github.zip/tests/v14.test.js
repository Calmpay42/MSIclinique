'use strict';
/* Recette de la version 1.4.0 : pilotage (tableau de bord et statistiques de la direction et du RAF). */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, dir1, raf;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le) VALUES (?,?,?,?,0,?)').run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString());
const consultation = spe => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = ? AND actif = 1").get(spe).id;
const aujourdhui = () => new Date().toISOString().slice(0, 10);
const tot = t => t.reduce((s, x) => s + x, 0);
let n = 0;
async function patient(extra = {}) {
  n++;
  const r = await accueil.post('/api/patients', { nom: 'pilotage' + n, prenoms: 'Awa', sexe: 'F', naissance: `1985-02-${String(n).padStart(2, '0')}`, telephone: `07 66 00 00 ${String(n).padStart(2, '0')}`, ...extra });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r.data.id;
}
async function passagePaye(pid, paiement, extra = {}) {
  const v = await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: consultation('Médecine générale'), ...extra });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  const bons = db.prepare('SELECT * FROM bons WHERE passage_id = ?').all(v.data.id);
  const du = bons.reduce((s, b) => { const t = b.prix * b.quantite; return s + t - (b.taux ? Math.round(t * b.taux / 100) : 0); }, 0);
  const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons.map(b => b.id), paiements: [{ ...paiement, montant: du }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return v.data;
}

let adm;
test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v14-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('dir1', 'direction'); compte('raf', 'raf');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, dir1, raf] = await Promise.all(['accueil', 'caisse', 'dir1', 'raf'].map(l => client().login(l)));
  compte('adm', 'admin'); adm = await client().login('adm');
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Pilotage : recettes, modes de paiement et services concordent avec les reçus de la base', async () => {
  await passagePaye(await patient(), { mode: 'Espèces' });
  await passagePaye(await patient(), { mode: 'Orange Money', reference: 'OM-PIL-1' });
  const ass = db.prepare('SELECT id FROM assureurs WHERE actif = 1 ORDER BY id LIMIT 1').get().id;
  await passagePaye(await patient({ assureur_id: ass, num_assure: 'PIL-1', taux: 80, validite: '2030-12-31' }), { mode: 'Espèces' }, { accord: 'ACC-PIL-1' });
  const r = await dir1.get('/api/pilotage?periode=mois');
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const t = r.data.totaux, jour = aujourdhui();
  const base_ = db.prepare("SELECT COALESCE(SUM(net), 0) AS net, COALESCE(SUM(part_assureur), 0) AS pa FROM recus WHERE annule = 0 AND substr(cree_le, 1, 7) = ?").get(jour.slice(0, 7));
  assert.equal(t.recettes, base_.net);
  assert.equal(t.part_assureurs, base_.pa);
  assert.ok(t.part_assureurs > 0, 'la part assureur de la patiente assurée est comptée');
  assert.equal(t.ca, t.recettes + t.part_assureurs);
  assert.equal(tot(r.data.series.recettes), t.recettes, 'la série mensuelle totalise les recettes');
  assert.equal(r.data.modes.reduce((s, m) => s + m.montant, 0), t.recettes, 'les modes de paiement totalisent les recettes');
  assert.equal(r.data.services.reduce((s, x) => s + x.montant, 0), t.ca, 'les services totalisent le chiffre d’affaires');
  assert.ok(r.data.modes.some(m => m.mode === 'Orange Money'));
  assert.equal(r.data.types.reduce((s, x) => s + x.nombre, 0), t.passages);
  assert.equal(r.data.jour.recettes, db.prepare('SELECT COALESCE(SUM(net), 0) AS n FROM recus WHERE annule = 0 AND substr(cree_le, 1, 10) = ?').get(jour).n);
  assert.ok(r.data.assureurs.facture.length >= 1 && Array.isArray(r.data.assureurs.creances));
  assert.equal(r.data.series.recettes.length, Number(jour.slice(8)), 'une case par jour du mois en cours');
});

test('Pilotage : un passage annulé ne compte pas dans l’activité', async () => {
  const avant = (await dir1.get('/api/pilotage?periode=mois')).data.totaux.passages;
  const v = await accueil.post('/api/passages', { patient_id: await patient(), type: 'consultation', acte_id: consultation('Médecine générale') });
  assert.equal((await dir1.get('/api/pilotage?periode=mois')).data.totaux.passages, avant + 1);
  assert.equal((await adm.post(`/api/passages/${v.data.id}/annulation`, { motif: 'Ouvert par erreur' })).status, 200);
  assert.equal((await dir1.get('/api/pilotage?periode=mois')).data.totaux.passages, avant);
});

test('Pilotage : périodes et droits d’accès', async () => {
  const jour = aujourdhui();
  const cases = async p => (await raf.get('/api/pilotage?periode=' + p)).data.periode;
  assert.equal((await cases('12m')).cases.length, 12);
  assert.equal((await cases('annee')).cases.length, Number(jour.slice(5, 7)));
  assert.equal((await cases('anneePrec')).cases.length, 12);
  assert.ok((await cases('tout')).cases.length >= 1);
  assert.equal((await cases('nimporte')).code, '12m', 'période inconnue : 12 derniers mois');
  assert.equal((await accueil.get('/api/pilotage')).status, 403);
  assert.equal((await caisse.get('/api/pilotage')).status, 403);
});
