'use strict';
/* Recette de la version 1.6 : notifications en temps réel, alertes infirmières (priorité et spécialiste suggéré),
   médecin et motif choisis à l'accueil, profil Facturiste. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, infirmier, meda, medb, cardio, labo, gerant, dir1, fact;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null).lastInsertRowid;
const idDe = login => db.prepare('SELECT id FROM utilisateurs WHERE login = ?').get(login).id;
const acte = code => db.prepare('SELECT * FROM actes WHERE code = ?').get(code);
const consultationMG = () => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = 'Médecine générale' AND actif = 1").get().id;
const notifs = async qui => (await qui.get('/api/etat')).data.notifications;
let n = 0;
async function patient() {
  n++;
  const p = await accueil.post('/api/patients', { nom: 'alerte' + n, prenoms: 'yao', sexe: 'M', naissance: `1980-03-${String(n).padStart(2, '0')}`, telephone: `07 77 00 00 ${String(n).padStart(2, '0')}` });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  return p.data.id;
}
async function payer(passage_id) {
  const bons = db.prepare('SELECT id FROM bons WHERE passage_id = ? AND annule = 0 AND paye = 0').all(passage_id).map(b => b.id);
  const total = db.prepare(`SELECT SUM(prix) s FROM (SELECT b.prix * b.quantite AS prix FROM bons b WHERE b.passage_id = ? AND b.annule = 0 AND b.paye = 0)`).get(passage_id).s;
  const r = await caisse.post('/api/caisse/encaissement', { bon_ids: bons, paiements: [{ mode: 'Espèces', montant: total }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
}
async function passage(extra = {}, paye = true) {
  const pid = await patient();
  const v = await accueil.post('/api/passages', { patient_id: pid, type: 'consultation', acte_id: consultationMG(), ...extra });
  assert.equal(v.status, 200, JSON.stringify(v.data));
  if (paye) await payer(v.data.id);
  return v.data.id;
}
const constantes = (passage_id, valeurs, medecin_id) => infirmier.post('/api/constantes', { passage_id, valeurs, medecin_id });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v16-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('infirmier', 'infirmier'); compte('meda', 'medecin', 'Médecine générale'); compte('medb', 'medecin', 'Médecine générale');
  compte('cardio', 'medecin', 'Cardiologie'); compte('labo', 'laboratoire'); compte('gerant', 'pharmacien'); compte('dir1', 'direction'); compte('fact', 'facturiste');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, infirmier, meda, medb, cardio, labo, gerant, dir1, fact] = await Promise.all(['accueil', 'caisse', 'infirmier', 'meda', 'medb', 'cardio', 'labo', 'gerant', 'dir1', 'fact'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 50000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Constantes anormales : patient prioritaire, spécialiste suggéré, tête de file et notification prioritaire', async () => {
  const normal = await passage();
  assert.equal((await constantes(normal, { ta: '120/80', temperature: '36,8' }, idDe('meda'))).data.prioritaire, false);
  const urgent = await passage();
  const r = await constantes(urgent, { ta: '165/105', temperature: '37' }, idDe('meda'));
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.prioritaire, true);
  assert.deepEqual(r.data.alertes.map(a => a.k), ['ta']);
  assert.equal(r.data.suggestion, 'Cardiologie');
  const file = (await meda.get('/api/etat')).data.file_medecin.filter(x => !x.consultation);
  assert.equal(file[0].passage_id, urgent, 'le patient prioritaire passe en tête');
  assert.equal(file[0].prioritaire, true);
  const nt = (await notifs(meda)).find(x => x.titre === 'Patient prioritaire');
  assert.ok(nt && nt.prioritaire === 1 && /Tension/.test(nt.message), JSON.stringify(nt));
  assert.equal((await notifs(meda)).filter(x => x.titre === 'Patient prioritaire').length, 1, 'une seule notification par événement');
});

test('Accueil : médecin et motif choisis à l’admission, repris par l’infirmerie et la consultation', async () => {
  assert.equal((await accueil.post('/api/passages', { patient_id: await patient(), type: 'consultation', acte_id: consultationMG(), medecin_id: idDe('cardio') })).status, 400, 'médecin d’une autre spécialité');
  const v = await passage({ medecin_id: idDe('medb'), motif: 'Douleur thoracique' });
  const p = db.prepare('SELECT medecin_id, motif FROM passages WHERE id = ?').get(v);
  assert.equal(p.medecin_id, idDe('medb'));
  assert.equal(p.motif, 'Douleur thoracique');
  const nt = (await notifs(medb)).find(x => x.titre === 'Nouveau patient en salle d’attente' && /Douleur thoracique/.test(x.message));
  assert.ok(nt, 'le médecin choisi est prévenu');
  assert.ok(!(await meda.get('/api/etat')).data.file_medecin.some(x => x.passage_id === v), 'absent de la file d’un confrère');
  const ligne = (await medb.get('/api/etat')).data.file_medecin.find(x => x.passage_id === v);
  assert.equal(ligne.orientation.par, 'l’accueil');
  assert.equal(ligne.motif, 'Douleur thoracique');
  assert.equal((await infirmier.get('/api/etat')).data.file_infirmerie.find(x => x.passage_id === v).medecin_id, idDe('medb'), 'médecin présélectionné à l’infirmerie');
  const c = await medb.post('/api/consultations', { passage_id: v });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  assert.equal((await medb.get('/api/consultations/' + c.data.id)).data.donnees.motif, 'Douleur thoracique', 'motif pré-rempli');
});

test('Notifications : patient à prendre pour l’infirmier, lecture une à une puis en bloc, chacun ne voit que les siennes', async () => {
  await passage();
  const l = await notifs(infirmier);
  const aPrendre = l.filter(x => x.titre === 'Patient à prendre en charge' && !x.lu_le);
  assert.ok(aPrendre.length >= 1);
  const avant = l.filter(x => !x.lu_le).length;
  assert.equal((await infirmier.post('/api/notifications/lues', { ids: [aPrendre[0].id] })).data.non_lues, avant - 1);
  assert.equal((await dir1.post('/api/notifications/lues', { ids: [aPrendre[1] ? aPrendre[1].id : aPrendre[0].id] })).status, 200);
  assert.ok(!(await notifs(dir1)).some(x => x.titre === 'Patient à prendre en charge'), 'cloisonnement');
  assert.equal((await infirmier.post('/api/notifications/lues', { ids: 'tout' })).data.non_lues, 0);
});

test('Laboratoire prévenu de l’examen à réaliser, médecin prévenu du résultat anormal', async () => {
  const v = await passage();
  assert.equal((await constantes(v, { ta: '120/80' }, idDe('meda'))).status, 200);
  assert.equal((await meda.post('/api/consultations', { passage_id: v })).status, 200);
  const r = await caisse.post(`/api/passages/${v}/actes`, { actes: [{ acte_id: acte('B-GLY').id, quantite: 1 }] });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  await payer(v);
  const bon = db.prepare('SELECT b.id FROM bons b JOIN actes a ON a.id = b.acte_id WHERE b.passage_id = ? AND a.code = ?').get(v, 'B-GLY');
  assert.ok((await notifs(labo)).some(x => x.titre === 'Examen à réaliser'));
  const s = await labo.post('/api/laboratoire/examens/' + bon.id, { lignes: [{ p: 'Glycémie à jeun', valeur: '2,35', unite: 'g/L', min: '0,70', max: '1,10' }] });
  assert.equal(s.status, 200, JSON.stringify(s.data));
  const res = db.prepare('SELECT id FROM resultats WHERE bon_id = ?').get(bon.id);
  assert.equal((await labo.post(`/api/laboratoire/resultats/${res.id}/validation`)).status, 200);
  const nt = (await notifs(meda)).find(x => x.titre === 'Résultats anormaux');
  assert.ok(nt && nt.prioritaire === 1, JSON.stringify(await notifs(meda)));
});

test('Direction prévenue d’une remise à valider ; gérant prévenu d’une péremption à moins de 3 mois', async () => {
  const v = await passage({}, false);
  const bons = db.prepare('SELECT id FROM bons WHERE passage_id = ?').all(v).map(b => b.id);
  const r = await caisse.post('/api/caisse/remise', { bon_ids: bons, pct: 30, motif: 'Patient indigent' });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.ok((await notifs(dir1)).some(x => x.titre === 'Remise à valider' && /Patient indigent/.test(x.message)));
  const per = (await notifs(gerant)).filter(x => x.type === 'peremption');
  assert.ok(per.length >= 1 && per.some(x => /moins de 3 mois/.test(x.titre)), JSON.stringify(per));
});

test('Profil Facturiste : tiers payant, bordereaux et factures, sans accès à la caisse ni au laboratoire', async () => {
  assert.equal((await fact.get('/api/tiers-payant/a-facturer')).status, 200);
  assert.equal((await fact.get('/api/bordereaux')).status, 200);
  assert.equal((await fact.get('/api/tiers-payant/balance-agee')).status, 200);
  assert.equal((await fact.post('/api/caisse/ouverture', { fonds: 1000 })).status, 403);
  assert.equal((await fact.get('/api/laboratoire/file')).status, 403);
  assert.ok((await fact.get('/api/etat')).data.notifications, 'le facturiste reçoit aussi ses notifications');
});
