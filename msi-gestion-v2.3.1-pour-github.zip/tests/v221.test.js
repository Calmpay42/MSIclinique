'use strict';
/* Recette de la version 2.2.1 : un hébergeur géré impose son port (variable PORT), qui prime sur le réglage du logiciel. */
const test = require('node:test');
const assert = require('node:assert/strict');

test('Port : PORT de l’hébergeur prime, puis MSI_PORT, puis le réglage par défaut', () => {
  const avant = { PORT: process.env.PORT, MSI_PORT: process.env.MSI_PORT, MSI_EN_LIGNE: process.env.MSI_EN_LIGNE };
  const { lireConfig } = require('../serveur/config');
  try {
    delete process.env.PORT; delete process.env.MSI_PORT; delete process.env.MSI_EN_LIGNE;
    assert.equal(lireConfig(false).port, 8080, 'réglage par défaut');
    process.env.MSI_PORT = '9090';
    assert.equal(lireConfig(false).port, 9090, 'réglage du conteneur');
    process.env.PORT = '10000'; process.env.MSI_EN_LIGNE = '1';
    const c = lireConfig(false);
    assert.equal(c.port, 10000, 'port imposé par l’hébergeur');
    assert.equal(c.en_ligne, true);
  } finally {
    for (const [k, v] of Object.entries(avant)) { if (v === undefined) delete process.env[k]; else process.env[k] = v; }
  }
});
