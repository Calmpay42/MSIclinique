'use strict';
/* Recette du module clinique : consultation liée au paiement, habilitations, secret médical, documents, rendez-vous. */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, pharma, ophta, generaliste, dir1;

function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return {
    get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(login) { const r = await req('POST', '/api/connexion', { login, mdp: MDP }); assert.equal(r.status, 200); return this; }
  };
}
const compte = (login, roles, specialites) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, 'Dr ' + login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), specialites || null);
const patientId = nom => db.prepare('SELECT id FROM patients WHERE nom = ?').get(nom).id;
const acteId = code => db.prepare('SELECT id FROM actes WHERE code = ?').get(code).id;

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-clinique-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('pharma', 'pharmacie'); compte('dir1', 'direction');
  compte('ophta', 'medecin', 'Ophtalmologie'); compte('generaliste', 'medecin', 'Médecine générale,Cardiologie');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, pharma, ophta, generaliste, dir1] = await Promise.all(['accueil', 'caisse', 'pharma', 'ophta', 'generaliste', 'dir1'].map(l => client().login(l)));
  await caisse.post('/api/caisse/ouverture', { fonds: 10000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

let passage, consultation;
test('Pas de consultation sans bon réglé ; habilitation par spécialité', async () => {
  const v = await accueil.post('/api/passages', { patient_id: patientId('KOUASSI'), type: 'consultation', acte_id: acteId('CS-OPH'), accord: 'ASC-77' });
  passage = v.data.id;
  const file = (await ophta.get('/api/etat')).data.file_medecin;
  assert.equal(file.find(x => x.passage_id === passage).statut, 'a_payer');
  assert.ok(!(await generaliste.get('/api/etat')).data.file_medecin.some(x => x.passage_id === passage), 'hors spécialité : absent de la file');
  const bloque = await ophta.post('/api/consultations', { passage_id: passage });
  assert.equal(bloque.status, 409);
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Consultation bloquée' AND niveau = 'blocage'").get());
  const bon = db.prepare('SELECT * FROM bons WHERE passage_id = ?').get(passage);
  const net = (bon.prix * (100 - bon.taux)) / 100;
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: net }] })).status, 200);
  assert.equal((await generaliste.post('/api/consultations', { passage_id: passage })).status, 403, 'le généraliste n’est pas habilité en ophtalmologie');
  const c = await ophta.post('/api/consultations', { passage_id: passage });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  consultation = c.data.id;
  assert.equal((await ophta.post('/api/consultations', { passage_id: passage })).data.id, consultation, 'une seule consultation par passage');
});

test('Secret médical : seul le médecin lit le dossier', async () => {
  const donnees = { motif: 'Baisse d’acuité visuelle progressive', to: { OD: '24', OG: '18' }, diagnostic: '' };
  assert.equal((await ophta.put(`/api/consultations/${consultation}`, { donnees })).status, 200);
  assert.equal((await caisse.get(`/api/dossiers/${patientId('KOUASSI')}`)).status, 403);
  assert.equal((await accueil.get(`/api/consultations/${consultation}`)).status, 403);
  assert.equal((await dir1.get(`/api/dossiers/${patientId('KOUASSI')}`)).status, 403, 'la direction ne lit pas le contenu médical');
  const d = await ophta.get(`/api/dossiers/${patientId('KOUASSI')}`);
  assert.equal(d.data.consultations[0].donnees.to.OD, '24');
  assert.ok(db.prepare("SELECT 1 FROM audit WHERE action = 'Dossier médical consulté'").get(), 'accès au dossier tracé');
  assert.equal((await generaliste.put(`/api/consultations/${consultation}`, { donnees: {} })).status, 403, 'seul l’auteur modifie le brouillon');
});

test('Examens : facturés à la caisse au tarif du référentiel, jamais au code envoyé par l’écran', async () => {
  const r = await ophta.post('/api/documents', { type: 'examens', consultation_id: consultation, donnees: {
    items: [{ l: 'Champ Visuel Automatisé', code: 'S-INJ' }, { l: 'Angiographie Fluoresceinique' }, { l: 'Nfs' }], renseignement: 'Suspicion de glaucome' } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.factures, 2, 'champ visuel et NFS facturés, angiographie réalisée à l’extérieur');
  const bons = db.prepare("SELECT code, prix FROM bons WHERE passage_id = ? AND origine = 'medecin' ORDER BY id").all(passage);
  assert.deepEqual(bons.map(b => b.code), ['OPH-CV', 'B-NFS']);
  assert.equal(bons[0].prix, 30000, 'tarif OphtaSuite du champ visuel');
  assert.equal((await ophta.post('/api/documents', { type: 'examens', consultation_id: consultation, donnees: { items: [{ l: 'Coronarographie' }] } })).status, 400);
  assert.equal((await ophta.post('/api/documents', { type: 'lunettes', consultation_id: consultation, donnees: { od: { sphere: '-1,25' }, og: { sphere: '-1,00' }, verres: 'Unifocaux' } })).status, 200);
});

test('Ordonnance : la pharmacie reçoit les médicaments sans le diagnostic', async () => {
  const o = await ophta.post('/api/documents', { type: 'ordonnance', consultation_id: consultation, donnees: { lignes: [{ medicament: 'Timolol 0,5 %', posologie: '1 goutte matin et soir', duree: '3 mois' }] } });
  assert.match(o.data.numero, /^ORM-\d{4}-00001$/);
  const p = await pharma.get('/api/prescriptions?passage_id=' + passage);
  assert.equal(p.data[0].lignes[0].medicament, 'Timolol 0,5 %');
  assert.ok(!JSON.stringify(p.data).includes('Baisse'), 'aucune donnée clinique transmise');
  assert.equal((await accueil.get('/api/prescriptions?passage_id=' + passage)).status, 403);
  assert.throws(() => db.prepare("UPDATE documents SET donnees = '{}'").run(), /non modifiable/);
  assert.throws(() => db.prepare('DELETE FROM documents').run(), /interdite/);
});

test('Validation : motif et diagnostic exigés, consultation figée, note complémentaire', async () => {
  const d = { motif: 'Baisse d’acuité visuelle progressive', to: { OD: '24', OG: '18' }, diagnostic: '' };
  assert.equal((await ophta.post(`/api/consultations/${consultation}/validation`, { donnees: d })).status, 400);
  assert.equal((await ophta.post(`/api/consultations/${consultation}/validation`, { donnees: { ...d, diagnostic: 'Suspicion de glaucome' } })).status, 200);
  assert.equal((await ophta.put(`/api/consultations/${consultation}`, { donnees: d })).status, 409);
  assert.throws(() => db.prepare("UPDATE consultations SET diagnostic = 'x'").run(), /non modifiable/);
  assert.equal((await ophta.post('/api/documents', { type: 'note', consultation_id: consultation, donnees: { texte: 'PIO recontrôlée à 19 mmHg.' } })).status, 200);
  assert.equal((await ophta.get('/api/etat')).data.file_medecin.find(x => x.passage_id === passage).statut, 'terminee');
});

test('Documents propres à chaque spécialité', async () => {
  const v = await accueil.post('/api/passages', { patient_id: patientId('DIABATÉ'), type: 'consultation', acte_id: acteId('CS-CAR') });
  const bon = db.prepare('SELECT * FROM bons WHERE passage_id = ?').get(v.data.id);
  await caisse.post('/api/caisse/encaissement', { bon_ids: [bon.id], paiements: [{ mode: 'Espèces', montant: bon.prix }] });
  const c = await generaliste.post('/api/consultations', { passage_id: v.data.id });
  assert.equal(c.status, 200);
  assert.equal((await generaliste.post('/api/documents', { type: 'lunettes', consultation_id: c.data.id, donnees: {} })).status, 400, 'pas de lunettes en cardiologie');
  const cr = await generaliste.post('/api/documents', { type: 'compte_rendu', consultation_id: c.data.id, donnees: { cle: 'ecg', champs: { rythme: 'Sinusal', conclusion: 'ECG normal' } } });
  assert.equal(cr.status, 200);
  const ecg = await generaliste.post('/api/documents', { type: 'examens', consultation_id: c.data.id, donnees: { items: [{ l: 'ECG de repos' }] } });
  assert.equal(ecg.data.factures, 1);
  const cert = await generaliste.post('/api/documents', { type: 'certificat', consultation_id: c.data.id, donnees: { sous_type: 'arret', jours: 3, debut: '2026-09-28' } });
  assert.equal((await generaliste.get('/api/documents/' + cert.data.id)).data.donnees.reprise, '2026-10-01');
});

test('Rendez-vous : posé par le médecin, suivi par l’accueil', async () => {
  const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  assert.equal((await ophta.post('/api/rdv', { patient_id: patientId('KOUASSI'), date: '2020-01-01' })).status, 400);
  const r = await ophta.post('/api/rdv', { patient_id: patientId('KOUASSI'), date: demain, heure: '09:30', specialite: 'Ophtalmologie', motif: 'Suivi glaucome' });
  assert.equal(r.status, 200);
  const l = await accueil.get(`/api/rdv?du=${demain}&au=${demain}`);
  assert.equal(l.data[0].nom, 'KOUASSI');
  assert.equal((await accueil.put(`/api/rdv/${r.data.id}`, { statut: 'honore' })).status, 200);
  assert.equal((await pharma.get('/api/rdv')).status, 403);
});

test('Comptes : un médecin a une spécialité et n’encaisse pas ; fusion du dossier médical', async () => {
  const adm = client(); compte('adm', 'admin'); await adm.login('adm');
  assert.equal((await adm.post('/api/utilisateurs', { login: 'dr.x', nom: 'Dr X', roles: ['medecin'] })).status, 400);
  assert.equal((await adm.post('/api/utilisateurs', { login: 'dr.y', nom: 'Dr Y', roles: ['medecin', 'caisse'], specialites: ['Cardiologie'] })).status, 400);
  assert.equal((await adm.post('/api/utilisateurs', { login: 'dr.z', nom: 'Dr Z', roles: ['medecin'], specialites: ['Dermatologie'], ordre: 'CI-1234' })).status, 200);
  const dup = await accueil.post('/api/patients', { nom: 'KOUASSI', prenoms: 'Aya Marie-Josée', sexe: 'F', naissance: '1991-04-12', telephone: '0708123456', forcer: true });
  db.prepare('UPDATE consultations SET patient_id = ? WHERE id = ?').run(dup.data.id, consultation);
  assert.equal((await dir1.post(`/api/patients/${dup.data.id}/fusion`, { vers_id: patientId('KOUASSI') })).status, 403);
  assert.equal((await adm.post(`/api/patients/${dup.data.id}/fusion`, { vers_id: patientId('KOUASSI') })).status, 200);
  assert.equal(db.prepare('SELECT patient_id FROM consultations WHERE id = ?').get(consultation).patient_id, patientId('KOUASSI'), 'la consultation validée suit la fusion');
});
