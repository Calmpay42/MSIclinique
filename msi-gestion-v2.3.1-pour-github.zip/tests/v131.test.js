'use strict';
/* Recette de la version 1.3.1 : corrections issues du parcours accueil → caisse (identité, passage identique, annulation de passage). */
process.env.TZ = 'Africa/Abidjan';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { ouvrir } = require('../serveur/db');
const { creerApp } = require('../serveur/app');
const init = require('../serveur/donnees-initiales');
const A = require('../serveur/auth');

const MDP = 'motdepasse123';
let db, srv, base, dir, accueil, caisse, labo, dir1, medecin;
function client() {
  let cookie = '';
  const req = async (methode, url, corps) => {
    const r = await fetch(base + url, { method: methode, headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(cookie ? { Cookie: cookie } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    return { status: r.status, data: (r.headers.get('content-type') || '').includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => req('GET', u), post: (u, b) => req('POST', u, b || {}), put: (u, b) => req('PUT', u, b || {}),
    async login(l) { const r = await req('POST', '/api/connexion', { login: l, mdp: MDP }); assert.equal(r.status, 200); return this; } };
}
const compte = (login, roles, spe) => db.prepare('INSERT INTO utilisateurs(login, nom, roles, hash, changer_mdp, cree_le, specialites) VALUES (?,?,?,?,0,?,?)')
  .run(login, login.toUpperCase(), roles, A.hacher(MDP), new Date().toISOString(), spe || null);
const consultation = spe => db.prepare("SELECT id FROM actes WHERE famille = 'Consultation' AND specialite = ? AND actif = 1").get(spe).id;
const bons = passageId => db.prepare('SELECT * FROM bons WHERE passage_id = ? ORDER BY id').all(passageId);
const dernierAudit = action => db.prepare('SELECT * FROM audit WHERE action = ? ORDER BY id DESC LIMIT 1').get(action);
const trouver = (o, k) => {
  if (!o || typeof o !== 'object') return undefined;
  if (Object.prototype.hasOwnProperty.call(o, k)) return o[k];
  for (const v of Object.values(o)) { const r = trouver(v, k); if (r !== undefined) return r; }
  return undefined;
};
let n = 0;
async function patient(extra = {}) {
  n++;
  const r = await accueil.post('/api/patients', { nom: 'recette' + n, prenoms: 'awa', sexe: 'F', naissance: `1990-01-${String(n).padStart(2, '0')}`, telephone: `07 55 00 00 ${String(n).padStart(2, '0')}`, ...extra });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r.data.id;
}
const passage = (qui, corps) => qui.post('/api/passages', corps);
const annuler = (qui, id, motif = 'Passage ouvert par erreur') => qui.post(`/api/passages/${id}/annulation`, { motif });
const demanderSuppression = (qui, id, motif = 'Passage ouvert par erreur') => qui.post('/api/suppressions', { objet: 'passage', id, motif });

let adm;
test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'msi-v131-'));
  db = ouvrir(path.join(dir, 'msi.db'));
  init.referentiels(db, { formation: true });
  init.donneesFormation(db);
  compte('accueil', 'accueil'); compte('caisse', 'caisse'); compte('labo', 'laboratoire'); compte('dir1', 'direction'); compte('medecin', 'medecin', 'Médecine générale');
  srv = await new Promise(r => { const s = creerApp(db).listen(0, '127.0.0.1', () => r(s)); });
  base = `http://127.0.0.1:${srv.address().port}`;
  [accueil, caisse, labo, dir1, medecin] = await Promise.all(['accueil', 'caisse', 'labo', 'dir1', 'medecin'].map(l => client().login(l)));
  compte('adm', 'admin'); adm = await client().login('adm');
  await caisse.post('/api/caisse/ouverture', { fonds: 20000 });
});
test.after(() => { srv.close(); db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('Identité : prénoms avec majuscules initiales, téléphone groupé par deux, à la création comme à la modification', async () => {
  const id = await patient({ prenoms: 'akissi marie-josée', telephone: '0708091011' });
  let p = (await accueil.get('/api/patients/' + id)).data.patient;
  assert.equal(p.prenoms, 'Akissi Marie-Josée');
  assert.equal(p.telephone, '07 08 09 10 11');
  const r = await accueil.put('/api/patients/' + id, { nom: p.nom, prenoms: "n'guessan AYA", sexe: 'F', naissance: p.naissance, telephone: '+2250708091012' });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  p = (await accueil.get('/api/patients/' + id)).data.patient;
  assert.equal(p.prenoms, "N'Guessan Aya");
  assert.equal(p.telephone, '+225 07 08 09 10 12');
  const autre = await patient({ telephone: '+33 6 12 34 56 78' });
  assert.equal((await accueil.get('/api/patients/' + autre)).data.patient.telephone, '+33 6 12 34 56 78', 'format étranger gardé tel quel');
});

test('Passage identique le même jour : alerte, puis second passage seulement sur confirmation, tracée et comptée', async () => {
  const pid = await patient();
  const mg = consultation('Médecine générale');
  const v1 = await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: mg });
  assert.equal(v1.status, 200);
  const v2 = await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: mg });
  assert.equal(v2.status, 409);
  assert.equal(v2.data.deja.numero, v1.data.numero);
  assert.equal(v2.data.deja.paye, false);
  assert.equal(bons(v1.data.id).length, 1, 'aucun second bon sans confirmation');
  const v3 = await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: mg, forcer: true });
  assert.equal(v3.status, 200);
  const j = dernierAudit('Ouverture de passage');
  assert.equal(j.niveau, 'alerte');
  assert.match(j.detail, new RegExp(`malgré ${v1.data.numero} déjà ouvert`));
  assert.equal((await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: consultation('Cardiologie') })).status, 200, 'autre spécialité : pas d’alerte');
  assert.equal((await passage(accueil, { patient_id: pid, type: 'controle', acte_id: mg })).status, 200, 'contrôle : pas d’alerte');
  assert.ok(trouver((await dir1.get('/api/etat')).data, 'passages_doubles') >= 1);
});

test('Annulation d’un passage ouvert par erreur : bons annulés, plus encaissables, tracée et signalée à la direction', async () => {
  const pid = await patient();
  const v = (await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: consultation('Médecine générale') })).data;
  const b = bons(v.id);
  assert.equal((await annuler(accueil, v.id)).status, 403, 'seul l’administrateur annule : l’accueil demande');
  assert.equal((await demanderSuppression(accueil, v.id, 'erreur')).status, 400, 'motif obligatoire (10 caractères au moins)');
  const dem = await demanderSuppression(accueil, v.id);
  assert.equal(dem.status, 200, JSON.stringify(dem.data));
  assert.equal((await demanderSuppression(caisse, v.id)).status, 409, 'une seule demande en attente par élément');
  assert.ok(bons(v.id).every(x => x.annule === 0), 'rien n’est annulé avant la décision');
  assert.equal((await dir1.post(`/api/demandes/${dem.data.id}/decision`, { accepte: true })).status, 403, 'la direction ne décide pas des suppressions');
  assert.equal((await adm.post(`/api/demandes/${dem.data.id}/decision`, { accepte: true })).status, 200);
  assert.ok(bons(v.id).every(x => x.annule === 1));
  assert.equal((await caisse.post('/api/caisse/encaissement', { bon_ids: b.map(x => x.id), paiements: [{ mode: 'Espèces', montant: 10000 }] })).status, 409);
  assert.equal((await annuler(adm, v.id)).status, 409, 'déjà annulé');
  const j = dernierAudit('Annulation de passage');
  assert.equal(j.niveau, 'alerte');
  assert.match(j.detail, /Motif : Passage ouvert par erreur/);
  assert.ok(trouver((await dir1.get('/api/etat')).data, 'passages_annules') >= 1);
  const fiche = (await accueil.get('/api/patients/' + pid)).data;
  assert.equal(fiche.patient.impaye || 0, 0, 'aucun impayé laissé au patient');
});

test('Annulation refusée dès qu’un acte est payé : l’avoir passe par la direction', async () => {
  const pid = await patient();
  const v = (await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: consultation('Médecine générale') })).data;
  const p = await caisse.post('/api/caisse/encaissement', { bon_ids: bons(v.id).map(x => x.id), paiements: [{ mode: 'Espèces', montant: 10000 }] });
  assert.equal(p.status, 200, JSON.stringify(p.data));
  assert.match((await demanderSuppression(caisse, v.id)).data.erreur, /annulation du reçu/, 'demande refusée d’emblée : l’avoir passe par la caisse');
  const r = await annuler(adm, v.id);
  assert.equal(r.status, 409);
  assert.match(r.data.erreur, /déjà payé/);
});

test('Annulation refusée quand la consultation a commencé (urgence prise en charge avant paiement)', async () => {
  const pid = await patient();
  const v = (await passage(accueil, { patient_id: pid, type: 'urgence' })).data;
  const c = await medecin.post('/api/consultations', { passage_id: v.id, specialite: 'Médecine générale' });
  assert.equal(c.status, 200, JSON.stringify(c.data));
  const r = await annuler(adm, v.id);
  assert.equal(r.status, 409);
  assert.match(r.data.erreur, /consultation a commencé/);
});

test('Droits : seul l’administrateur annule, y compris un passage d’un jour précédent ; les autres demandent', async () => {
  const pid = await patient();
  const mg = consultation('Médecine générale');
  const v1 = (await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: mg })).data;
  for (const qui of [labo, caisse, accueil, dir1]) assert.equal((await annuler(qui, v1.id)).status, 403);
  assert.equal((await annuler(adm, v1.id)).status, 200);
  const v2 = (await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: mg })).data;
  db.prepare('UPDATE passages SET cree_le = ? WHERE id = ?').run(new Date(Date.now() - 2 * 86400000).toISOString(), v2.id);
  const ra = await annuler(adm, v2.id);
  assert.equal(ra.status, 200, 'l’administrateur annule un passage d’un jour précédent : ' + JSON.stringify(ra.data));
});

test('Un solde repris de l’ancien logiciel ne s’annule pas depuis l’accueil ou la caisse', async () => {
  const reprise = db.prepare("SELECT id FROM passages WHERE type = 'reprise' LIMIT 1").get();
  assert.ok(reprise, 'la base de formation contient un solde repris');
  const r = await annuler(adm, reprise.id);
  assert.equal(r.status, 409);
  assert.match(r.data.erreur, /repris/);
});

test('Droits expirés : l’ouverture du passage le signale (facturé comme non assuré)', async () => {
  const ass = db.prepare('SELECT id FROM assureurs WHERE actif = 1 LIMIT 1').get().id;
  const pid = await patient({ assureur_id: ass, num_assure: 'X-1', taux: 80, validite: '2020-12-31' });
  const r = await passage(accueil, { patient_id: pid, type: 'consultation', acte_id: consultation('Médecine générale') });
  assert.equal(r.status, 200);
  assert.equal(r.data.non_couvert, 'expiree');
  assert.equal(bons(r.data.id)[0].taux, 0);
});
