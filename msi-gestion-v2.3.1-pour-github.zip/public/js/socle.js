'use strict';
/* MSI Gestion : socle de l'interface. L'écran affiche et transmet ; toutes les règles sont appliquées par le serveur. */
const $ = (s, r) => (r || document).querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n, w) => String(n).padStart(w, '0');
const NF = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 });
const money = n => NF.format(Math.round(Number(n) || 0)) + '\u00a0FCFA';
const signed = n => (n > 0 ? '+\u00a0' : n < 0 ? '\u2212\u00a0' : '') + money(Math.abs(n));
const isoDate = d => d.getFullYear() + '-' + pad(d.getMonth() + 1, 2) + '-' + pad(d.getDate(), 2);
const todayISO = () => isoDate(new Date());
const jourDe = ts => isoDate(new Date(ts));
const fmtDate = iso => { if (!iso) return ''; const p = String(iso).slice(0, 10).split('-'); return p[2] + '/' + p[1] + '/' + p[0]; };
const fmtTime = ts => { const d = new Date(ts); return pad(d.getHours(), 2) + '\u00a0h\u00a0' + pad(d.getMinutes(), 2); };
const fmtDateTime = ts => (jourDe(ts) === todayISO() ? 'aujourd’hui' : 'le ' + fmtDate(jourDe(ts))) + ' à ' + fmtTime(ts);
const horodatageCourt = ts => (jourDe(ts) === todayISO() ? '' : fmtDate(jourDe(ts)).slice(0, 5) + ' ') + fmtTime(ts);
const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5);
const lcFirst = s => (s ? s.charAt(0).toLowerCase() + s.slice(1) : s);
const pl = (n, s, p) => (n > 1 ? (p || s + 's') : s);
function age(n) {
  if (!n) return '?';
  const b = new Date(n + 'T00:00:00'), t = new Date();
  let a = t.getFullYear() - b.getFullYear();
  if (t.getMonth() < b.getMonth() || (t.getMonth() === b.getMonth() && t.getDate() < b.getDate())) a--;
  return a;
}

let MOI = null, E = null, UI = null, VERSION = 0, OCCUPE = false;
const ACTIONS = {}, INPUTS = {}, CHANGES = {}, ONGLETS = [];
const peut = d => !!MOI && MOI.droits.includes(d);
const utilisateur = id => (E && E.utilisateurs[id]) || '?';
const patientE = id => (id && E.patients.find(p => p.id === id)) || null;
const passageE = id => E.passages.find(v => v.id === id) || null;
const produitE = id => E.produits.find(p => p.id === id) || null;
const nomPatient = p => (p ? p.nom + ' ' + p.prenoms : 'Client comptoir');
const typeLibelle = t => (MOI.ref.types_passage[t] || t);

function freshUI() {
  const j = todayISO();
  return {
    tab: null,
    acc: { q: '', res: null, fiche: null, type: 'consultation', acteId: '', accord: '' },
    cai: { sel: null, checked: null, remise: 0, motif: '', dernierRecu: null },
    pay: null, clo: null, add: null,
    pha: { sub: 'ordonnances', vid: '', q: '', lines: [], presc: '', ordExt: '', filtre: 'tous', ouverts: {} },
    dir: { type: 'journal-caisse', du: j.slice(0, 8) + '01', au: j, verif: null },
    adm: { sub: null, users: null, sauv: null, integrite: null, filtre: '' }
  };
}

/* Appels au serveur */
class ErreurApi extends Error { constructor(status, message, data) { super(message); this.status = status; this.data = data || {}; } }
async function api(methode, url, corps, auto) {
  let r;
  try {
    r = await fetch(url, { method: methode, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-MSI': '1', ...(auto ? { 'X-MSI-Auto': '1' } : {}) }, body: corps === undefined ? undefined : JSON.stringify(corps) });
  } catch (e) { throw new ErreurApi(0, 'Serveur injoignable : vérifiez le réseau ou le serveur de la clinique.'); }
  let data = null;
  try { data = await r.json(); } catch (e) { /* réponse sans corps */ }
  if (r.status === 401 && url !== '/api/connexion' && url !== '/api/moi') { MOI = null; E = null; afficherConnexion('Session expirée ou fermée : reconnectez-vous.'); }
  if (r.status === 403 && data && data.changer_mdp && MOI) { MOI.changer_mdp = true; afficherChangementMdp(); }
  if (!r.ok) throw new ErreurApi(r.status, (data && data.erreur) || 'Erreur ' + r.status, data);
  return data;
}
async function charger(auto) {
  const v = await api('GET', '/api/version', undefined, auto);
  E = await api('GET', '/api/etat', undefined, auto);
  VERSION = v.v;
  signalerNotifications();
}
/* Exécute une action : un seul envoi à la fois, rechargement de l'état, message de réussite ou d'erreur. */
async function agir(fn, succes, surErreur) {
  if (OCCUPE) return undefined;
  OCCUPE = true;
  document.body.classList.add('occupe');
  try {
    const r = await fn();
    await charger();
    render();
    if (succes) toast(typeof succes === 'function' ? succes(r) : succes);
    return r === undefined ? true : r;
  } catch (e) {
    if (surErreur && surErreur(e)) return undefined;
    if (e.status !== 401 && !(e.data && e.data.changer_mdp)) toast(e.message, 'bad');
    return undefined;
  } finally {
    OCCUPE = false;
    document.body.classList.remove('occupe');
  }
}

/* Éléments communs */
const IC = {
  laboratoire: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.7 3h10.6a2 2 0 0 0 1.7-3l-5-9V3"/><path d="M7.5 15h9"/>',
  pilotage: '<path d="M3 20h18"/><path d="M6 16v-4"/><path d="M10.5 16V8"/><path d="M15 16v-6"/><path d="M19.5 16V5"/>',
  infirmerie: '<path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.7A4 4 0 0 1 19 11c0 5.6-7 10-7 10z"/><path d="M12 9.5v5"/><path d="M9.5 12h5"/>',
  cloche: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
  compta: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5A2.5 2.5 0 0 1 6.5 19H20v3H6.5"/><path d="M9 7h7M9 11h7"/>',
  corbeille: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/>',
  oeil: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  oeilbarre: '<path d="M9.9 4.2A10.6 10.6 0 0 1 12 4c6.4 0 10 8 10 8a17.9 17.9 0 0 1-2.2 3.2M6.6 6.6C3.9 8.3 2 12 2 12s3.6 8 10 8a9.7 9.7 0 0 0 5.4-1.6"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2"/><path d="M2 2l20 20"/>',
  rh: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/>',
  lit: '<path d="M3 6v13"/><path d="M3 14h18v5"/><path d="M21 14v-2a3 3 0 0 0-3-3h-7v5"/><circle cx="7" cy="11" r="2"/>',
  tiers: '<path d="M5 3h10l4 4v14H5z"/><path d="M15 3v4h4M8.5 11h7M8.5 14.5h7M8.5 18h4"/>',
  accueil: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="11" r="2.2"/><path d="M5.8 16.2c.7-1.6 1.9-2.4 3.2-2.4s2.5.8 3.2 2.4M14.5 10h4M14.5 13.5h3"/>',
  caisse: '<path d="M6 3h12v18l-2.4-1.6L13.2 21l-2.4-1.6L8.4 21 6 19.4z"/><path d="M9 8h6M9 11.5h6M9 15h3.5"/>',
  pharmacie: '<path d="M9.5 3.5h5v6h6v5h-6v6h-5v-6h-6v-5h6z"/>',
  consultations: '<path d="M6 3v6a5 5 0 0 0 10 0V3"/><path d="M11 14v2.5a4.5 4.5 0 0 0 9 0V13"/><circle cx="20" cy="11" r="2"/>',
  direction: '<path d="M4 20V11M10 20V5M16 20v-6M21 20H3"/>',
  parametrage: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  user: '<circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c1.2-3.6 3.9-5.5 7-5.5s5.8 1.9 7 5.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>'
};
const icon = (k, s) => `<svg viewBox="0 0 24 24" width="${s || 20}" height="${s || 20}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[k]}</svg>`;
/* Vrai logo de la clinique (fichier officiel) : une seule adresse d'image pour tout le logiciel (l'édition HTML l'intègre). */
const imageLogo = (classe, hauteur) => `<img src="/img/logo-msi.png" alt="Maison de Santé Innov’Care" class="${classe}"${hauteur ? ` style="height:${hauteur}px;width:auto"` : ''}>`;
const logo = h => imageLogo('logo', h || 32);
const closeBtn = () => `<button class="icon-btn" data-action="closeModal" aria-label="Fermer">${icon('close', 20)}</button>`;
const champ = (label, html, hint) => `<label class="f"><span>${label}</span>${html}${hint ? `<small class="hint">${hint}</small>` : ''}</label>`;
const vide = (titre, texte) => `<div class="panel empty"><h2>${titre}</h2><p class="muted">${texte}</p></div>`;

function header() {
  const onglets = ONGLETS.filter(o => o.visible());
  return `${E.formation ? '<div class="formation-banner">Base de formation : données fictives, sans valeur comptable</div>' : ''}
  <header class="topbar"><div class="topbar-in">
    <div class="brand"><div class="brand-logo">${imageLogo('brand-img')}</div><div class="brand-sub">MSI Gestion, ${esc(E.vacation)}</div></div>${boutonCloche()}
    <button class="user-btn" data-action="menuCompte" title="Mon compte">${icon('user', 18)}<span>${esc(MOI.utilisateur.nom)}</span></button>
    <nav class="tabs" aria-label="Postes de travail">${onglets.map(o => {
      const n = o.compteur ? o.compteur() : 0;
      return `<button class="tab" data-action="onglet" data-tab="${o.id}"${UI.tab === o.id ? ' aria-current="page"' : ''}>${icon(o.icone)}<span>${o.libelle}</span>${n ? `<b class="count">${n}<span class="sr"> en attente</span></b>` : ''}</button>`;
    }).join('')}</nav>
  </div></header>`;
}
function render() {
  if (!MOI || !E) return;
  const onglets = ONGLETS.filter(o => o.visible());
  if (!onglets.length) { $('#app').innerHTML = header() + '<main id="main">' + vide('Aucun poste attribué', 'Votre profil ne donne accès à aucun écran. Contactez l’administrateur.') + '</main>'; return; }
  if (!onglets.some(o => o.id === UI.tab)) {
    /* Écran d'arrivée : le poste principal du profil, puis le premier onglet autorisé. */
    const priorite = { comptable: 'compta', rh: 'rh', infirmier: 'infirmerie', pharmacien: 'pharmacie', facturiste: 'tiers', laboratoire: 'laboratoire', medecin: 'consultations', direction: 'pilotage', caisse: 'caisse', pharmacie: 'pharmacie', accueil: 'accueil', raf: 'pilotage', admin: 'parametrage' };
    const prefere = MOI.utilisateur.roles.map(r => priorite[r]).find(id => onglets.some(o => o.id === id));
    UI.tab = prefere || onglets[0].id;
  }
  const o = onglets.find(x => x.id === UI.tab);
  $('#app').innerHTML = header() + '<main id="main">' + o.vue() + '</main>';
  if (o.apresRendu) o.apresRendu();
}

/* Connexion et compte */
function ecranAuth(contenu) {
  closeModal();
  $('#app').innerHTML = `<main class="auth"><div class="auth-card">${logo(118)}<h1>MSI Gestion</h1>${contenu}</div></main>`;
  const f = $('.auth-card input');
  if (f) f.focus();
}
function afficherConnexion(msg) {
  ecranAuth(`<p class="muted">Connexion au poste de travail</p>
    ${msg ? `<div class="notice warn">${esc(msg)}</div>` : ''}
    ${champ('Identifiant', '<input id="cx-login" autocomplete="username" autocapitalize="none" spellcheck="false" data-enter="connexion">')}
    ${champ('Mot de passe', '<input id="cx-mdp" type="password" autocomplete="current-password" data-enter="connexion">')}
    <button class="btn btn-block" data-action="connexion">Se connecter</button>
    <p class="hint">Compte personnel : ne le prêtez jamais. Déconnexion automatique après une période d’inactivité.</p>`);
}
function afficherChangementMdp() {
  ecranAuth(`<p class="muted">Bonjour ${esc(MOI.utilisateur.nom)}. Choisissez votre mot de passe personnel avant de commencer.</p>
    ${champ('Mot de passe provisoire', '<input id="mdp-ancien" type="password" autocomplete="current-password">')}
    ${champ('Nouveau mot de passe', '<input id="mdp-nouveau" type="password" autocomplete="new-password">', '10 caractères au moins, avec des lettres et des chiffres.')}
    ${champ('Confirmation', '<input id="mdp-confirm" type="password" autocomplete="new-password" data-enter="changerMdp">')}
    <button class="btn btn-block" data-action="changerMdp">Enregistrer et continuer</button>
    <button class="btn btn-ghost btn-block" data-action="deconnexion">Se déconnecter</button>`);
}
async function demarrerSession() {
  try { MOI = await api('GET', '/api/moi'); } catch (e) { afficherConnexion(e.status === 401 ? '' : e.message); return; }
  if (MOI.changer_mdp) { afficherChangementMdp(); return; }
  try { await charger(); } catch (e) { if (e.status !== 401) afficherConnexion(e.message); return; }
  UI = freshUI();
  render();
}
Object.assign(ACTIONS, {
  connexion: async () => {
    const login = $('#cx-login').value.trim(), mdp = $('#cx-mdp').value;
    if (!login || !mdp) { toast('Saisissez votre identifiant et votre mot de passe.', 'bad'); return; }
    try { await api('POST', '/api/connexion', { login, mdp }); await demarrerSession(); }
    catch (e) { toast(e.message, 'bad'); const m = $('#cx-mdp'); if (m) { m.value = ''; m.focus(); } }
  },
  changerMdp: async () => {
    const ancien = $('#mdp-ancien').value, nouveau = $('#mdp-nouveau').value;
    if (nouveau !== $('#mdp-confirm').value) { toast('La confirmation ne correspond pas au nouveau mot de passe.', 'bad'); return; }
    try { await api('POST', '/api/moi/mdp', { ancien, nouveau }); toast('Mot de passe enregistré.'); await demarrerSession(); }
    catch (e) { toast(e.message, 'bad'); }
  },
  deconnexion: async () => { try { await api('POST', '/api/deconnexion'); } catch (e) { /* session déjà close */ } MOI = null; E = null; afficherConnexion('Vous êtes déconnecté.'); },
  menuCompte: () => openModal(`<div class="modal-head"><h2>${esc(MOI.utilisateur.nom)}</h2>${closeBtn()}</div>
    <p class="muted">Identifiant ${esc(MOI.utilisateur.login)}, ${MOI.utilisateur.roles.map(r => esc(MOI.roles_libelles[r] || r)).join(', ')}</p>
    <h3>Changer mon mot de passe</h3>
    ${champ('Mot de passe actuel', '<input id="mc-ancien" type="password" autocomplete="current-password">')}
    ${champ('Nouveau mot de passe', '<input id="mc-nouveau" type="password" autocomplete="new-password">', '10 caractères au moins, avec des lettres et des chiffres.')}
    ${champ('Confirmation', '<input id="mc-confirm" type="password" autocomplete="new-password">')}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="monPlanning">Mon planning</button><button class="btn btn-ghost" data-action="deconnexion">Se déconnecter</button><button class="btn" data-action="mcEnregistrer">Changer le mot de passe</button></div>`),
  mcEnregistrer: async () => {
    const ancien = $('#mc-ancien').value, nouveau = $('#mc-nouveau').value;
    if (nouveau !== $('#mc-confirm').value) { toast('La confirmation ne correspond pas.', 'bad'); return; }
    try { await api('POST', '/api/moi/mdp', { ancien, nouveau }); closeModal(); toast('Mot de passe changé.'); } catch (e) { toast(e.message, 'bad'); }
  },
  onglet: el => { UI.tab = el.dataset.tab; render(); toTop(); },
  backdrop: (el, e) => { if (e.target === el) closeModal(); },
  closeModal: () => closeModal()
});

/* Fenêtres et messages */
let lastFocus = null;
function openModal(html, opts) {
  const root = $('#modal-root');
  if (!root.firstChild) lastFocus = document.activeElement;
  root.innerHTML = `<div class="modal-back" data-action="backdrop"><div class="modal${opts && opts.large ? ' modal-large' : ''}" role="dialog" aria-modal="true" tabindex="-1">${html}</div></div>`;
  document.body.classList.add('modal-open');
  if (!(opts && opts.noFocus)) {
    const m = $('.modal', root), f = m.querySelector('input:not([disabled]):not([type=checkbox]),select,textarea');
    try { (f || m).focus({ preventScroll: true }); } catch (e) { /* ignoré */ }
  }
}
const modalOuverte = () => !!$('#modal-root').firstChild;
function closeModal() {
  $('#modal-root').innerHTML = '';
  document.body.classList.remove('modal-open');
  if (UI) { UI.pay = null; UI.add = null; UI.clo = null; }
  if (lastFocus && document.contains(lastFocus)) { try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* ignoré */ } }
  lastFocus = null;
}
function toast(msg, kind) {
  const root = $('#toast-root');
  const el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : '');
  el.setAttribute('role', kind === 'bad' ? 'alert' : 'status');
  el.textContent = msg;
  root.appendChild(el);
  while (root.children.length > 2) root.removeChild(root.firstChild);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, kind === 'bad' ? 6500 : 3800);
}
function scrollToId(id) {
  if (window.innerWidth >= 860) return;
  const el = document.getElementById(id);
  if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function toTop() { try { window.scrollTo(0, 0); } catch (e) { /* ignoré */ } }
function imprimer(html) {
  $('#print-root').innerHTML = html;
  window.print();
}
function telecharger(nom, contenu, type) {
  const url = URL.createObjectURL(new Blob([contenu], { type: type || 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = nom;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/* Pièce A4 à l'en-tête de la clinique : facture récapitulative, bordereau d'assureur, compte rendu d'analyses. */
function pieceA4({ titre, numero, sous, corps, paysage }) {
  const e = E.parametres;
  return `<div class="piece-a4${paysage ? ' paysage' : ''}"><header class="pa-tete">${imageLogo('pa-logo')}
    <div class="pa-clinique"><div class="pa-raison">${esc(e.raison)}</div><div>${esc(e.forme)}</div><div>${esc(e.adresse)}, ${esc(e.telephone)}</div><div>${esc(e.rccm)}, ${esc(e.ncc)}</div></div>
    <div class="pa-num"><div class="pa-titre">${esc(titre)}</div><strong>${esc(numero)}</strong>${sous ? `<div>${sous}</div>` : ''}</div></header>
    ${corps}${E.formation ? '<p class="pa-demo">Base de formation : document sans valeur.</p>' : ''}</div>`;
}
function apercuA4(titre, html) {
  UI.impression = html;
  openModal(`<div class="modal-head"><h2>${esc(titre)}</h2>${closeBtn()}</div><div class="apercu-a4">${html}</div>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Fermer</button><button class="btn" data-action="imprimerA4">Imprimer</button></div>`, { large: true, noFocus: true });
}
ACTIONS.imprimerA4 = () => imprimer(UI.impression);

/* Notifications en temps réel (v1.6) : cloche, message à l'écran, signal sonore, notification du navigateur si autorisée. */
const NOTIF = { vues: null, utilisateur: null, audio: null };
const nonLues = () => (E && E.notifications ? E.notifications.filter(n => !n.lu_le) : []);
function boutonCloche() {
  const l = nonLues(), prio = l.some(x => x.prioritaire);
  return `<button class="cloche${prio ? ' cloche-prio' : ''}" data-action="notifs" title="Notifications" aria-label="Notifications${l.length ? ` : ${l.length} non lue${l.length > 1 ? 's' : ''}` : ''}">${icon('cloche', 18)}<span class="cloche-lib">Notifications</span>${l.length ? `<b class="count">${l.length}</b>` : ''}</button>`;
}
function bip(prio) {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) return;
    NOTIF.audio = NOTIF.audio || new C();
    const a = NOTIF.audio, t = a.currentTime;
    (prio ? [880, 660, 880] : [660]).forEach((f, i) => {
      const o = a.createOscillator(), g = a.createGain(), d = t + i * 0.18;
      o.frequency.value = f; g.gain.setValueAtTime(0.0001, d); g.gain.exponentialRampToValueAtTime(0.22, d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, d + 0.16);
      o.connect(g).connect(a.destination); o.start(d); o.stop(d + 0.17);
    });
  } catch (e) { /* le son reste facultatif */ }
}
function signalerNotifications() {
  if (!E || !E.notifications || !MOI) return;
  const maxi = E.notifications.reduce((m, n) => Math.max(m, n.id), 0);
  /* À la connexion (ou au changement d'utilisateur sur le poste) : pas de rafale, seulement le compteur. */
  if (NOTIF.utilisateur !== MOI.utilisateur.id || NOTIF.vues === null) { NOTIF.utilisateur = MOI.utilisateur.id; NOTIF.vues = maxi; return; }
  const nouvelles = E.notifications.filter(n => n.id > NOTIF.vues && !n.lu_le).sort((a, b) => a.id - b.id);
  NOTIF.vues = Math.max(NOTIF.vues, maxi);
  if (!nouvelles.length) return;
  nouvelles.slice(-3).forEach(n => toast(`${n.titre} : ${n.message || ''}`, n.prioritaire ? 'bad' : undefined));
  bip(nouvelles.some(n => n.prioritaire));
  if ('Notification' in window && Notification.permission === 'granted' && document.visibilityState !== 'visible') {
    nouvelles.slice(-3).forEach(n => { try { new Notification(n.titre, { body: n.message || '', tag: 'msi-' + n.id }); } catch (e) { /* navigateur sans notifications */ } });
  }
}
Object.assign(ACTIONS, {
  notifs: () => {
    const l = E.notifications || [];
    openModal(`<div class="modal-head"><h2>Notifications</h2>${closeBtn()}</div>
      ${l.length ? `<ul class="notif-liste">${l.map(n => `<li class="${n.lu_le ? 'lue' : ''}${n.prioritaire ? ' prio' : ''}"><button type="button" data-action="notifOuvrir" data-id="${n.id}">
        <strong>${esc(n.titre)}</strong><span>${esc(n.message || '')}</span><small>${fmtDateTime(n.cree_le)}${n.lu_le ? ', lue' : ''}</small></button></li>`).join('')}</ul>`
        : '<p class="muted">Aucune notification pour le moment.</p>'}
      <div class="modal-actions">${'Notification' in window && Notification.permission === 'default' ? '<button class="btn btn-ghost" data-action="notifActiver">Activer les alertes du navigateur</button>' : ''}${nonLues().length ? '<button class="btn" data-action="notifToutLu">Tout marquer comme lu</button>' : '<button class="btn btn-ghost" data-action="closeModal">Fermer</button>'}</div>`, { noFocus: true });
  },
  notifOuvrir: async el => {
    const n = (E.notifications || []).find(x => String(x.id) === el.dataset.id);
    closeModal();
    if (n && !n.lu_le) { await api('POST', '/api/notifications/lues', { ids: [n.id] }); await charger(); }
    if (n && n.onglet && ONGLETS.some(o => o.id === n.onglet && o.visible())) UI.tab = n.onglet;
    render();
  },
  notifToutLu: async () => { await api('POST', '/api/notifications/lues', { ids: 'tout' }); closeModal(); await charger(); render(); },
  notifActiver: async () => { try { await Notification.requestPermission(); } catch (e) { /* refusé */ } ACTIONS.notifs(); }
});

/* Mot de passe visible à la demande (v2.1) : chaque champ de mot de passe reçoit un bouton « œil » pour vérifier la saisie.
   Le bouton ne prend pas le focus : on continue de taper sans perdre le curseur. S'applique à tout écran, y compris les fenêtres. */
function oeilMotDePasse(champ) {
  if (champ.dataset.oeil) return;
  champ.dataset.oeil = '1';
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'oeil'; b.tabIndex = -1;
  const maj = () => { const vu = champ.type === 'text'; b.innerHTML = icon(vu ? 'oeilbarre' : 'oeil', 18); b.setAttribute('aria-label', vu ? 'Masquer le mot de passe' : 'Afficher le mot de passe'); b.setAttribute('aria-pressed', String(vu)); b.title = b.getAttribute('aria-label'); };
  b.addEventListener('mousedown', e => e.preventDefault());
  b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); champ.type = champ.type === 'password' ? 'text' : 'password'; maj(); champ.focus(); });
  maj();
  champ.classList.add('avec-oeil');
  if (champ.parentNode) { champ.parentNode.classList.add('porte-oeil'); champ.insertAdjacentElement('afterend', b); }
}
(function installerOeil() {
  const traiter = racine => { if (racine.querySelectorAll) racine.querySelectorAll('input[type="password"]:not([data-oeil])').forEach(oeilMotDePasse); };
  const lancer = () => { traiter(document); new MutationObserver(l => l.forEach(m => m.addedNodes.forEach(traiter))).observe(document.body, { childList: true, subtree: true }); };
  if (document.body) lancer(); else document.addEventListener('DOMContentLoaded', lancer);
})();

/* Demandes de suppression (v2.2). Seul l'administrateur supprime ; les autres utilisateurs lui adressent une demande avec un motif
   obligatoire (10 caractères au moins), saisi avant l'envoi. Rien n'est modifié avant sa décision ; le demandeur est prévenu de la réponse. */
function demanderSuppression({ objet, id, titre, description, extra }) {
  UI.supDemande = { objet, id: Number(id), extra: extra || {} };
  openModal(`<div class="modal-head"><h2>${esc(titre)}</h2>${closeBtn()}</div>
    <p>${esc(description)}</p>
    <div class="notice">Seul l’administrateur supprime. Votre demande lui est envoyée avec son motif ; rien n’est modifié avant sa décision, et vous serez prévenu de sa réponse.</div>
    ${champ('Motif de la demande (obligatoire)', '<textarea id="sup-motif" rows="3" maxlength="300" data-input="supMotif" placeholder="Ex. passage ouvert par erreur pour le mauvais patient"></textarea>', '<span id="sup-compte">10 caractères au moins.</span>')}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" id="sup-envoyer" data-action="supEnvoyer" disabled>Envoyer la demande à l’administrateur</button></div>`);
}
Object.assign(INPUTS, {
  supMotif: el => {
    const n = el.value.trim().length, b = $('#sup-envoyer'), c = $('#sup-compte');
    if (b) b.disabled = n < 10;
    if (c) c.textContent = n < 10 ? `Encore ${10 - n} caractère${10 - n > 1 ? 's' : ''} au moins.` : 'Motif suffisant.';
  }
});
Object.assign(ACTIONS, {
  supEnvoyer: async () => {
    const d = UI.supDemande, motif = ($('#sup-motif').value || '').trim();
    if (motif.length < 10) { toast('Indiquez le motif de la demande (10 caractères au moins).', 'bad'); return; }
    const r = await agir(() => api('POST', '/api/suppressions', { objet: d.objet, id: d.id, motif, ...d.extra }), 'Demande envoyée à l’administrateur.');
    if (r) closeModal();
  }
});
