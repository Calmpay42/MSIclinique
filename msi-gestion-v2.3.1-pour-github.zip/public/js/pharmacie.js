'use strict';
/* Poste Pharmacie : dispensation des seuls bons payés ou accordés, lots FEFO, réception, ajustements (PHA-01 à PHA-11). */
function etatOrdonnance(o) {
  const bs = E.bons.filter(b => b.ordonnance_id === o.id);
  if (!bs.length || bs.every(b => b.annule)) return 'annulee';
  const actifs = bs.filter(b => !b.annule);
  if (actifs.every(b => b.delivre)) return 'delivree';
  if (actifs.every(b => b.paye)) return 'payee';
  if (actifs.some(b => b.urgent)) return 'urgence';
  return 'a_payer';
}
const ETATS_ORD = {
  a_payer: ['b-due', 'À payer à la caisse'], payee: ['b-ok', 'Payée, à délivrer'], urgence: ['b-bad', 'Urgence, délivrable'],
  delivree: ['b-muted', 'Délivrée'], annulee: ['b-muted', 'Annulée']
};
const passagesPharmacie = () => E.passages.filter(v => jourDe(v.cree_le) === todayISO() && v.patient_id && v.type !== 'reprise' && v.type !== 'comptoir');
const libre = p => p.stock.libre - UI.pha.lines.filter(l => l.produit_id === p.id).reduce((s, l) => s + l.quantite, 0);

function vPharmacie() {
  const subs = [['ordonnances', 'Ordonnances'], ['stock', 'Stock'], ...(peut('pharmacie') ? [['reception', 'Réception']] : [])];
  if (!peut('pharmacie') && UI.pha.sub !== 'stock') UI.pha.sub = 'stock';
  const vue = UI.pha.sub === 'stock' ? phaStock() : UI.pha.sub === 'reception' ? phaReception() : phaOrdonnances();
  return `<div class="view-head"><div><h1>Pharmacie</h1><p class="lead">Délivrer uniquement ce qui est payé ou accordé ; le prix suit la couverture du patient.</p></div></div>
    <div class="seg" role="group" aria-label="Rubriques de la pharmacie">${subs.map(([k, l]) => `<button data-action="phaSub" data-sub="${k}" aria-pressed="${UI.pha.sub === k}">${l}</button>`).join('')}</div>${vue}`;
}
function contexte() {
  if (!UI.pha.vid) return null;
  if (UI.pha.vid === 'comptoir') return { comptoir: true, niveau: 'non', libelle: 'Vente au comptoir (tarif non assurés)' };
  const v = passageE(Number(UI.pha.vid));
  if (!v) return null;
  const p = patientE(v.patient_id), c = p.couverture;
  const niveau = v.accord && c.etat === 'valide' ? c.niveau : 'non';
  return { v, p, niveau, libelle: niveau === 'maj' ? 'Tarif assurances majeures' : niveau === 'aut' ? 'Tarif autres assurances' : 'Tarif non assurés' };
}
function phaOrdonnances() {
  const ctx = contexte();
  return `<div class="grid-2"><section><div class="panel"><h2>Nouvelle ordonnance</h2>
    ${champ('Patient ou vente', `<select data-change="phaPassage"><option value="">Choisir le passage du jour</option>${passagesPharmacie().map(v => { const p = patientE(v.patient_id); return `<option value="${v.id}"${String(UI.pha.vid) === String(v.id) ? ' selected' : ''}>${esc(nomPatient(p))}, ${esc(v.numero)}</option>`; }).join('')}<option value="comptoir"${UI.pha.vid === 'comptoir' ? ' selected' : ''}>Vente au comptoir (ordonnance externe)</option></select>`)}
    ${ctx ? `<p class="hint">${esc(ctx.libelle)}. Le prix n’est jamais modifiable au comptoir.</p>
      ${champ('Rechercher un produit', `<input type="search" value="${esc(UI.pha.q)}" placeholder="Nom commercial ou DCI" autocomplete="off" data-input="phaRecherche">`)}
      ${ctx.v ? prescriptionMedecin(ctx.v.id) : ''}<div id="pha-sugg">${suggestions()}</div><div id="pha-lignes">${lignesOrdonnance()}</div>` : '<p class="muted">Choisissez d’abord le passage du patient ou la vente au comptoir.</p>'}
  </div></section><section><div class="panel"><h2>Ordonnances du jour et en cours</h2>${listeOrdonnances()}</div></section></div>`;
}
/* PHA-04 : la prescription électronique du médecin arrive à la pharmacie (médicaments seuls, sans diagnostic). */
function prescriptionMedecin(vid) {
  if (!peut('prescriptions')) return '';
  if (UI.pha.prescVid !== vid) {
    UI.pha.prescVid = vid; UI.pha.presc = null; UI.pha.aVerifier = [];
    api('GET', '/api/prescriptions?passage_id=' + vid).then(r => { UI.pha.presc = r; if (UI.tab === 'pharmacie' && !modalOuverte()) render(); }).catch(() => {});
    return '';
  }
  const l = UI.pha.presc || [];
  if (!l.length) return '';
  return `<div class="notice"><strong>Prescription du médecin</strong>${l.map(o => `<div class="muted">${esc(o.numero)}, ${esc(o.medecin || '')}</div><ul class="doc-lignes">${o.lignes.map(x => `<li>${esc(x.medicament)}${x.posologie ? ', ' + esc(x.posologie) : ''}${x.duree ? ', ' + esc(x.duree) : ''}</li>`).join('')}</ul>`).join('')}
    ${(UI.pha.aVerifier || []).length ? `<div class="notice warn"><strong>Dosage différent de la prescription : non repris.</strong> Ajoutez-le vous-même seulement si la substitution est conforme et expliquée au patient.<ul class="doc-lignes">${UI.pha.aVerifier.map(v => `<li>${esc(v)}</li>`).join('')}</ul></div>` : ''}
    <button class="btn btn-sm" data-action="phaReprendre">Reprendre les produits disponibles</button></div>`;
}
function suggestions() {
  const q = UI.pha.q.trim().toLowerCase();
  if (q.length < 2) return '';
  const ctx = contexte(), n = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const r = E.produits.filter(p => p.actif && (n(p.nom).includes(n(q)) || n(p.dci).includes(n(q)))).slice(0, 8);
  if (!r.length) return '<p class="muted">Aucun produit trouvé.</p>';
  return `<ul class="sugg">${r.map(p => { const l = libre(p); return `<li><button class="sugg-btn" data-action="phaAjouter" data-id="${p.id}"${l <= 0 ? ' disabled' : ''}>
    <span><strong>${esc(p.nom)}</strong><span class="muted">${esc(p.dci || '')}${p.psychotrope ? ', psychotrope' : ''}</span></span>
    <span class="rb-side"><span>${money(p['prix_' + ctx.niveau])}</span><span class="muted">${l > 0 ? l + ' disponible(s)' : 'Indisponible'}</span></span></button></li>`; }).join('')}</ul>`;
}
function lignesOrdonnance() {
  const L = UI.pha.lines, ctx = contexte();
  if (!L.length) return '<p class="hint">Ajoutez les produits prescrits.</p>';
  const total = L.reduce((s, l) => s + produitE(l.produit_id)['prix_' + ctx.niveau] * l.quantite, 0);
  const psy = L.some(l => produitE(l.produit_id).psychotrope);
  return `<ul class="plist">${L.map((l, i) => { const p = produitE(l.produit_id); return `<li><div><strong>${esc(p.nom)}</strong><div class="muted">${money(p['prix_' + ctx.niveau])} l’unité</div></div>
    <div class="pl-side"><div class="stepper"><button class="icon-btn" data-action="phaPas" data-i="${i}" data-d="-1" aria-label="Retirer une unité">\u2212</button><output>${l.quantite}</output><button class="icon-btn" data-action="phaPas" data-i="${i}" data-d="1" aria-label="Ajouter une unité">+</button></div></div></li>`; }).join('')}</ul>
    <div class="kvline total"><span>Total</span><strong>${money(total)}</strong></div>
    <div class="form-grid two">${champ(psy ? 'Prescripteur (obligatoire, psychotrope)' : 'Prescripteur', `<input value="${esc(UI.pha.presc)}" data-input="phaPresc" autocomplete="off">`)}
    ${champ(psy ? 'N° d’ordonnance (obligatoire)' : 'N° d’ordonnance externe', `<input value="${esc(UI.pha.ordExt)}" data-input="phaOrdExt" autocomplete="off">`)}</div>
    <button class="btn btn-block" data-action="phaEnvoyer">Envoyer à la caisse</button>`;
}
function listeOrdonnances() {
  if (!E.ordonnances.length) return '<p class="muted">Aucune ordonnance aujourd’hui.</p>';
  return E.ordonnances.map(o => {
    const st = etatOrdonnance(o), [cls, txt] = ETATS_ORD[st], bs = E.bons.filter(b => b.ordonnance_id === o.id);
    const p = patientE(o.patient_id), du = bs.filter(b => !b.paye && !b.annule).reduce((s, b) => s + b.net, 0);
    return `<div class="ord"><div class="ord-head"><div><strong>${esc(o.numero)}</strong> <span class="muted">${esc(nomPatient(p))}, ${fmtTime(o.cree_le)}</span></div><span class="badge ${cls}">${txt}</span></div>
      <ul class="plist compact">${bs.map(b => `<li><div>${esc(b.libelle)} × ${b.quantite}</div><div class="pl-side">${money(b.net)}</div></li>`).join('')}</ul>
      ${st === 'a_payer' ? `<p class="hint">${money(du)} à régler à la caisse avant délivrance.</p>` : ''}
      ${st === 'delivree' && o.lots.length ? `<p class="hint">Lots : ${o.lots.map(l => `${esc(l.lot)} × ${l.quantite}`).join(', ')}</p>` : ''}
      ${peut('pharmacie') && st !== 'delivree' && st !== 'annulee' ? `<button class="btn btn-sm${st === 'a_payer' ? ' btn-ghost' : ''}" data-action="delivrer" data-id="${o.id}">Délivrer</button>` : ''}</div>`;
  }).join('');
}
function alertesStock(p) {
  const s = p.stock, a = [];
  if (s.rupture) a.push('<span class="badge b-bad">Rupture</span>');
  else if (s.sous_seuil) a.push('<span class="badge b-warn">Sous le seuil</span>');
  if (s.p30) a.push(`<span class="badge b-bad">Péremption à ${s.jours} j</span>`);
  else if (s.p90) a.push(`<span class="badge b-warn">Péremption à ${s.jours} j</span>`);
  if (s.perimes) a.push(`<span class="badge b-bad">${s.perimes} périmé(s) bloqué(s)</span>`);
  if (!p.actif) a.push('<span class="badge b-muted">Désactivé</span>');
  return a.join('');
}
function phaStock() {
  const f = UI.pha.filtre, j = todayISO();
  const liste = E.produits.filter(p => f === 'alertes' ? (p.stock.rupture || p.stock.sous_seuil || p.stock.p30 || p.stock.p90 || p.stock.perimes) : f === 'perimes' ? p.stock.perimes : true);
  return `<div class="panel"><div class="panel-head"><h2>État du stock</h2>${peut('catalogue') ? '<button class="btn btn-sm" data-action="catNouveau">Ajouter un médicament</button>' : ''}<div class="seg" role="group" aria-label="Filtre">${[['tous', 'Tous'], ['alertes', 'Alertes'], ['perimes', 'Périmés']].map(([k, l]) => `<button data-action="phaFiltre" data-f="${k}" aria-pressed="${f === k}">${l}</button>`).join('')}</div></div>
    ${liste.length ? `<div class="table-wrap"><table><thead><tr><th>Produit</th><th class="num">Disponible</th><th class="num">Réservé</th><th class="num">Libre</th><th>Alertes</th><th></th></tr></thead><tbody>${liste.map(p => `<tr>
      <td><strong>${esc(p.nom)}</strong><div class="muted">${esc(p.code)}, ${esc(p.dci || '')}, seuil ${p.seuil}</div></td><td class="num">${p.stock.dispo}</td><td class="num">${p.stock.reserve}</td><td class="num">${p.stock.libre}</td>
      <td>${alertesStock(p)}</td><td class="actions">${p.a_valider ? '<span class="badge b-warn">Prix à valider</span> ' : ''}${peut('catalogue') ? `<button class="btn btn-sm btn-ghost" data-action="catModifier" data-id="${p.id}">Modifier</button>` : ''}${p.stock.lots.length ? `<button class="btn btn-sm btn-ghost" data-action="phaLots" data-id="${p.id}">${UI.pha.ouverts[p.id] ? 'Masquer' : 'Lots'}</button>` : ''}</td></tr>
      ${UI.pha.ouverts[p.id] ? `<tr class="lots-row"><td colspan="6"><div class="lots">${p.stock.lots.map(l => `<div class="lot${l.peremption < j ? ' is-exp' : ''}"><span><strong>${esc(l.numero)}</strong> <span class="muted">${l.peremption < j ? 'périmé le' : 'expire le'} ${fmtDate(l.peremption)}, ${esc(l.fournisseur || '')}</span></span>
        <span class="rb-side">${l.quantite}${peut('stock_ajuster') ? `<button class="btn btn-sm btn-ghost" data-action="phaAjuster" data-id="${l.id}" data-p="${p.id}">Ajuster</button>` : ''}</span></div>`).join('')}</div></td></tr>` : ''}`).join('')}</tbody></table></div>` : '<p class="muted">Aucun produit pour ce filtre.</p>'}
    <p class="hint">Lots triés par péremption : la délivrance sort d’abord le lot qui expire le plus tôt. Un lot périmé est bloqué.</p></div>`;
}
function phaReception() {
  return `<div class="grid-2"><section><div class="panel"><h2>Réception de marchandise</h2>
    ${champ('Produit', `<select id="rc-produit"><option value="">Choisir</option>${E.produits.filter(p => p.actif).map(p => `<option value="${p.id}">${esc(p.nom)}</option>`).join('')}</select>`)}
    <div class="form-grid two">${champ('N° de lot', '<input id="rc-lot" autocomplete="off">')}${champ('Péremption', `<input id="rc-per" type="date" min="${todayISO()}">`)}
    ${champ('Quantité reçue', '<input id="rc-q" type="number" min="1" inputmode="numeric">')}${champ('Prix d’achat unitaire (FCFA)', '<input id="rc-pa" type="number" min="0" inputmode="numeric">')}</div>
    ${champ('Fournisseur', '<input id="rc-fourn" list="fournisseurs" autocomplete="off">')}
    <datalist id="fournisseurs">${[...new Set(E.receptions.map(r => r.fournisseur).filter(Boolean))].map(f => `<option value="${esc(f)}">`).join('')}</datalist>
    <button class="btn btn-block" data-action="receptionner">Enregistrer la réception</button>
    <p class="hint">Contrôlez la quantité, le lot et la péremption sur le bon de livraison. Un lot déjà périmé est refusé.</p></div></section>
    <section><div class="panel"><h2>Dernières réceptions</h2>${E.receptions.length ? `<ul class="plist">${E.receptions.map(r => `<li><div><strong>${esc(r.produit)}</strong><div class="muted">Lot ${esc(r.lot)}, expire le ${fmtDate(r.peremption)}, ${esc(r.fournisseur || '')}</div></div><div class="pl-side">+${r.quantite}<div class="muted">${fmtDateTime(r.cree_le)}</div></div></li>`).join('')}</ul>` : '<p class="muted">Aucune réception enregistrée.</p>'}</div></section></div>`;
}

const normPha = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
/* Dosage écrit sur une ligne (« 1 g », « 500 mg », « 0,5 % ») ramené à une valeur comparable ; null s'il n'y en a pas. */
function dosagePha(t) {
  const m = /(\d+(?:[.,]\d+)?)\s*(mg|g|µg|mcg|ui|ml|%)(?![a-zà-ÿ])/i.exec(String(t || ''));
  if (!m) return null;
  const v = Number(m[1].replace(',', '.')), u = m[2].toLowerCase();
  if (u === 'g') return { v: v * 1000, u: 'mg' };
  if (u === 'µg' || u === 'mcg') return { v: v / 1000, u: 'mg' };
  return { v, u };
}
const memeDosage = (a, b) => !a || !b || (a.u === b.u && Math.abs(a.v - b.v) < 1e-9);
ACTIONS.phaReprendre = () => {
  let repris = 0, absents = 0;
  UI.pha.aVerifier = [];
  for (const o of UI.pha.presc || []) for (const x of o.lignes) {
    const a = normPha(x.medicament), dose = dosagePha(x.medicament);
    const candidats = E.produits.filter(q => q.actif && libre(q) > 0 && (a.includes(normPha(q.nom)) || normPha(q.nom).includes(a) || (q.dci && a.includes(normPha(q.dci)))));
    if (!candidats.length) { absents++; continue; }
    /* Jamais de substitution silencieuse : quand la prescription précise un dosage, le produit doit avoir le même (1 g prescrit ≠ 500 mg). */
    const p = candidats.find(q => memeDosage(dose, dosagePha(q.nom)));
    if (!p) { UI.pha.aVerifier.push(`${x.medicament} prescrit ; en stock : ${candidats.map(q => q.nom).join(', ')}`); continue; }
    if (!UI.pha.lines.some(l => l.produit_id === p.id)) { UI.pha.lines.push({ produit_id: p.id, quantite: 1 }); repris++; }
  }
  render();
  const n = UI.pha.aVerifier.length;
  toast(`${repris} produit(s) repris : ajustez les quantités.${absents ? ` ${absents} médicament(s) absent(s) du stock MSI.` : ''}${n ? ` ${n} dosage(s) différent(s) à vérifier.` : ''}`, n ? 'bad' : undefined);
};
Object.assign(ACTIONS, {
  phaSub: el => { UI.pha.sub = el.dataset.sub; render(); },
  phaAjouter: el => {
    const p = produitE(Number(el.dataset.id)), l = UI.pha.lines.find(x => x.produit_id === p.id);
    if (libre(p) <= 0) { toast('Plus de stock libre pour ce produit.', 'bad'); return; }
    if (l) l.quantite++; else UI.pha.lines.push({ produit_id: p.id, quantite: 1 });
    UI.pha.q = ''; render();
  },
  phaPas: el => {
    const i = Number(el.dataset.i), l = UI.pha.lines[i], p = produitE(l.produit_id), d = Number(el.dataset.d);
    if (d > 0 && libre(p) <= 0) { toast('Stock libre insuffisant.', 'bad'); return; }
    l.quantite += d;
    if (l.quantite <= 0) UI.pha.lines.splice(i, 1);
    $('#pha-lignes').innerHTML = lignesOrdonnance();
  },
  phaEnvoyer: async () => {
    const ctx = contexte();
    const corps = { lignes: UI.pha.lines, prescripteur: UI.pha.presc, reference_ext: UI.pha.ordExt, ...(ctx.comptoir ? { comptoir: true } : { passage_id: ctx.v.id }) };
    const r = await agir(() => api('POST', '/api/ordonnances', corps), r => `Ordonnance ${r.numero} envoyée : ${money(r.du)} à régler à la caisse${r.urgent ? ' (urgence : délivrable avant paiement)' : ''}.`);
    if (r) { UI.pha.lines = []; UI.pha.presc = ''; UI.pha.ordExt = ''; UI.pha.vid = ''; render(); }
  },
  delivrer: el => agir(() => api('POST', `/api/ordonnances/${el.dataset.id}/delivrance`), r => `Délivré : ${r.sorties.map(s => `${s.produit}, lot ${s.lot} × ${s.quantite}`).join(' ; ')}.`),
  phaFiltre: el => { UI.pha.filtre = el.dataset.f; render(); },
  phaLots: el => { const id = el.dataset.id; UI.pha.ouverts[id] = !UI.pha.ouverts[id]; render(); },
  phaAjuster: el => {
    const p = produitE(Number(el.dataset.p)), l = p.stock.lots.find(x => x.id === Number(el.dataset.id));
    openModal(`<div class="modal-head"><div><h2>Ajuster le stock</h2><p class="muted">${esc(p.nom)}, lot ${esc(l.numero)}, ${l.quantite} en stock</p></div>${closeBtn()}</div>
      <div class="form-grid two">${champ('Type', `<select id="aj-type" data-change="ajType">${Object.entries(MOI.ref.types_ajustement).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select>`)}
      ${champ('Quantité', '<input id="aj-q" type="number" inputmode="numeric">', 'Écart d’inventaire : négatif si manquant, positif si excédent.')}</div>
      <div id="aj-service" hidden>${champ('Service destinataire', '<input id="aj-serv" list="services" placeholder="Soins, Laboratoire…" autocomplete="off"><datalist id="services"><option value="Soins"><option value="Laboratoire"><option value="Urgences"></datalist>')}</div>
      ${champ('Motif', '<input id="aj-motif" autocomplete="off">')}
      <p class="hint">Au-delà de ${money(E.parametres.seuil_ajustement)} de valeur, l’ajustement attend la validation de la direction.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="ajValider" data-id="${l.id}">Enregistrer</button></div>`);
  },
  ajValider: async el => {
    const d = { lot_id: Number(el.dataset.id), type: $('#aj-type').value, quantite: Number($('#aj-q').value), motif: $('#aj-motif').value, service: $('#aj-serv').value };
    if (await agir(() => api('POST', '/api/stock/ajustement', d), r => (r.en_attente ? 'Ajustement transmis à la direction pour validation.' : 'Stock ajusté.'))) closeModal();
  },
  receptionner: async () => {
    const d = { produit_id: Number($('#rc-produit').value), numero: $('#rc-lot').value, peremption: $('#rc-per').value, quantite: Number($('#rc-q').value), prix_achat: Number($('#rc-pa').value), fournisseur: $('#rc-fourn').value };
    await agir(() => api('POST', '/api/stock/reception', d), r => `Réception enregistrée : péremption dans ${r.jours} jours.`);
  }
});
Object.assign(INPUTS, {
  phaRecherche: el => { UI.pha.q = el.value; $('#pha-sugg').innerHTML = suggestions(); },
  phaPresc: el => { UI.pha.presc = el.value; },
  phaOrdExt: el => { UI.pha.ordExt = el.value; }
});
Object.assign(CHANGES, {
  phaPassage: el => { UI.pha.vid = el.value; UI.pha.lines = []; render(); },
  ajType: el => { $('#aj-service').hidden = el.value !== 'sortie_interne'; }
});
ONGLETS.push({
  id: 'pharmacie', libelle: 'Pharmacie', icone: 'pharmacie', visible: () => peut('pharmacie') || peut('stock_ajuster'),
  compteur: () => (peut('pharmacie') ? E.ordonnances.filter(o => ['payee', 'urgence'].includes(etatOrdonnance(o))).length : 0), vue: vPharmacie
});

/* Catalogue des médicaments (v1.5), tenu par le gérant de la pharmacie ; les prix qu'il fixe sont validés par la direction. */
function formCatalogue(p) {
  const v = (k, d) => esc(p ? (p[k] == null ? '' : p[k]) : (d == null ? '' : d));
  openModal(`<div class="modal-head"><h2>${p ? 'Modifier ' + esc(p.nom) : 'Ajouter un médicament'}</h2>${closeBtn()}</div>
    <div class="form-grid">
      ${champ('Code', `<input id="ct-code" value="${v('code')}" maxlength="30" placeholder="Ex. AMOXI1G">`)}
      ${champ('Nom et dosage', `<input id="ct-nom" value="${v('nom')}" maxlength="120" placeholder="Ex. Amoxicilline 1 g">`)}
      ${champ('DCI', `<input id="ct-dci" value="${v('dci')}" maxlength="120">`)}
      ${champ('Forme', `<input id="ct-forme" value="${v('forme')}" maxlength="60" placeholder="Comprimé, sirop, injectable">`)}
      ${champ('Famille', `<input id="ct-famille" value="${v('famille')}" maxlength="60" placeholder="Ex. Antibiotique">`)}
      ${champ('Seuil d’alerte (unités)', `<input id="ct-seuil" type="number" min="0" value="${v('seuil', 0)}">`)}
      ${champ('Prix non assurés (FCFA)', `<input id="ct-prix_non" type="number" min="0" value="${v('prix_non')}">`)}
      ${champ('Prix assurances majeures (FCFA)', `<input id="ct-prix_maj" type="number" min="0" value="${v('prix_maj')}">`)}
      ${champ('Prix autres assurances (FCFA)', `<input id="ct-prix_aut" type="number" min="0" value="${v('prix_aut')}">`)}
    </div>
    <fieldset class="cases"><legend>Options</legend><label><input type="checkbox" id="ct-psy"${p && p.psychotrope ? ' checked' : ''}> Psychotrope (prescripteur et n° d’ordonnance exigés)</label>
      ${p ? `<label><input type="checkbox" id="ct-actif"${p.actif ? ' checked' : ''}> Médicament actif (proposé à la vente)</label>` : ''}</fieldset>
    <p class="hint">${peut('valider') ? 'Enregistré par la direction : les prix sont validés.' : 'Les prix que vous fixez ou modifiez sont validés par la direction avant la première vente.'}</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="catEnregistrer" data-id="${p ? p.id : ''}">Enregistrer</button></div>`);
}
Object.assign(ACTIONS, {
  catNouveau: () => formCatalogue(null),
  catModifier: el => formCatalogue(E.produits.find(p => String(p.id) === el.dataset.id)),
  catEnregistrer: async el => {
    const g = k => $('#ct-' + k).value, n = k => Number(g(k) || 0), id = el.dataset.id;
    const corps = { code: g('code'), nom: g('nom'), dci: g('dci'), forme: g('forme'), famille: g('famille'), seuil: n('seuil'), prix_non: n('prix_non'), prix_maj: n('prix_maj'), prix_aut: n('prix_aut'),
      psychotrope: $('#ct-psy').checked ? 1 : 0, actif: $('#ct-actif') ? ($('#ct-actif').checked ? 1 : 0) : 1 };
    const r = await agir(() => api(id ? 'PUT' : 'POST', '/api/catalogue/produits' + (id ? '/' + id : ''), corps), r => (r.a_valider ? 'Médicament enregistré : prix à valider par la direction.' : 'Médicament enregistré.'));
    if (r) closeModal();
  }
});
