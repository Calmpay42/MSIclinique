'use strict';
/* Graphiques de MSI Gestion : histogrammes, courbes dans le temps, anneaux, barres horizontales, indicateurs.
   SVG dessiné localement (hors ligne), couleurs de la charte : vert pétrole, cuivre, rouge réservé aux alertes.
   Tout est regroupé dans l'objet GR pour ne rien entrer en conflit avec le reste des écrans. */
const GR = (() => {
  const C = { petrole: '#1A3738', cuivre: '#C48546', petroleClair: '#7A9A97', barre: '#2F6D69', barreEnCours: '#9DBAB6', grille: '#E6DFD2',
    alerte: '#B3443D', attention: '#C48546', normal: 'rgba(63,125,90,.11)', neutre: '#D9D2C4' };
  const PALETTE = ['#1A3738', '#C48546', '#5F8F8A', '#8C5A2B', '#A9C2BF', '#E2C8A6', '#46585A', '#B8A58C'];
  const MOIS_C = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  const MOIS_L = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  const JOURS = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
  const nf = new Intl.NumberFormat('fr-FR');
  const nb = v => nf.format(Math.round(v || 0));
  const e = s => esc(String(s == null ? '' : s));
  const montant = v => `${nb(v)}<span class="gr-unite">FCFA</span>`;
  const libMois = (m, annee) => { const [a, mm] = m.split('-').map(Number); return MOIS_C[mm - 1] + (annee ? ' ' + String(a).slice(2) : ''); };
  const libCase = c => (c.length === 10 ? String(Number(c.slice(8))) : libMois(c, false));
  const dateLongue = iso => { if (!iso) return '—'; const [a, m, j] = iso.slice(0, 10).split('-').map(Number); return `${j} ${MOIS_L[m - 1]} ${a}`; };
  const dateCourte = iso => (iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4) : '—');
  const pasRond = v => { if (!(v > 0)) return 1; const p = 10 ** Math.floor(Math.log10(v)); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; };
  const graduer = (max, nMax = 5) => { const pas = pasRond(Math.max(max, 1e-9) / (nMax - 1)); const n = Math.max(1, Math.ceil(max / pas)); return { pas, n, haut: pas * n }; };
  const abrege = v => { const a = Math.abs(v); if (a >= 1e6) return nf.format(Math.round(v / 1e5) / 10) + ' M'; if (a >= 1e4) return nf.format(Math.round(v / 1e3)) + ' k'; return nf.format(Math.round(v)); };
  const vide = texte => `<div class="gr-vide">${e(texte)}</div>`;
  /* « à » contracté : au mois dernier, aux 12 mois précédents, à la même période. */
  const aLib = l => (/^le /i.test(l) ? 'au ' + l.slice(3) : /^les /i.test(l) ? 'aux ' + l.slice(4) : 'à ' + l);

  /* Histogramme, avec courbe facultative sur un second axe aligné sur la même grille. */
  function histogramme(o) {
    const n = o.libs.length, vals = o.barres.vals;
    if (!n || (!vals.some(v => v) && !(o.ligne && o.ligne.vals.some(v => v)))) return vide(o.vide || 'Aucune donnée sur la période.');
    const W = o.w || 700, H = o.h || 260, pl = 54, pr = o.ligne ? 54 : 16, pt = 22, pb = 34;
    const mini = Math.min(0, ...vals), gB = graduer(Math.max(1, ...vals.map(Math.abs))), maxB = gB.haut, basB = mini < 0 ? -gB.haut : 0;
    const maxL = o.ligne ? pasRond(Math.max(1, ...o.ligne.vals) / gB.n) * gB.n : 1;
    const larg = (W - pl - pr) / n, bw = Math.min(46, larg * 0.62);
    const Yb = v => pt + (1 - (v - basB) / (maxB - basB)) * (H - pt - pb), Yl = v => pt + (1 - v / maxL) * (H - pt - pb);
    const cx = i => pl + larg * i + larg / 2, fb = o.barres.fmt || nb, fl = (o.ligne && o.ligne.fmt) || nb;
    const nTicks = basB < 0 ? gB.n * 2 : gB.n;
    const ticks = Array.from({ length: nTicks + 1 }, (_, k) => basB + (maxB - basB) * k / nTicks).map(v => `<line x1="${pl}" x2="${W - pr}" y1="${Yb(v).toFixed(1)}" y2="${Yb(v).toFixed(1)}" class="gr-grille"/>
      <text x="${pl - 8}" y="${(Yb(v) + 4).toFixed(1)}" text-anchor="end" class="gr-axe">${abrege(v)}</text>`).join('')
      + (o.ligne ? Array.from({ length: gB.n + 1 }, (_, k) => maxL * k / gB.n).map(v => `<text x="${W - pr + 8}" y="${(Yl(v) + 4).toFixed(1)}" class="gr-axe" fill="${o.ligne.couleur}">${abrege(v)}</text>`).join('') : '');
    const pasLib = Math.max(1, Math.ceil(n / (W > 600 ? 16 : 9)));
    const barres = vals.map((v, i) => {
      const enCours = o.enCours && i === n - 1, y = v >= 0 ? Yb(v) : Yb(0), h = Math.abs(Yb(v) - Yb(0));
      const col = v < 0 ? C.alerte : enCours ? C.barreEnCours : (o.barres.couleur || C.barre);
      return `<rect x="${(cx(i) - bw / 2).toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="${col}" class="gr-barre" tabindex="0"
        data-tip="${e(`${o.titres ? o.titres[i] : o.libs[i]}${enCours ? ' (en cours)' : ''} : ${fb(v)} ${o.barres.nom}`)}"/>
        ${n <= 14 && v ? `<text x="${cx(i).toFixed(1)}" y="${(v >= 0 ? Yb(v) - 6 : Yb(v) + 14).toFixed(1)}" text-anchor="middle" class="gr-val">${abrege(v)}</text>` : ''}
        ${i % pasLib === 0 ? `<text x="${cx(i).toFixed(1)}" y="${H - 12}" text-anchor="middle" class="gr-axe">${e(o.libs[i])}</text>` : ''}`;
    }).join('');
    const ligne = o.ligne ? `<path d="${o.ligne.vals.map((v, i) => `${i ? 'L' : 'M'}${cx(i).toFixed(1)},${Yl(v).toFixed(1)}`).join(' ')}" fill="none" stroke="${o.ligne.couleur}" stroke-width="2.4" stroke-linejoin="round"/>
      ${o.ligne.vals.map((v, i) => `<circle cx="${cx(i).toFixed(1)}" cy="${Yl(v).toFixed(1)}" r="${n > 20 ? 2.6 : 4}" fill="${o.ligne.couleur}" stroke="#fff" stroke-width="1.4"/>
      <circle cx="${cx(i).toFixed(1)}" cy="${Yl(v).toFixed(1)}" r="10" fill="transparent" class="gr-cible" tabindex="0" data-tip="${e(`${o.titres ? o.titres[i] : o.libs[i]} : ${fl(v)} ${o.ligne.nom}`)}"/>`).join('')}` : '';
    return `<figure class="gr-graph"><svg viewBox="0 0 ${W} ${H}" style="max-width:${Math.round(W * 1.3)}px" role="img" aria-label="${e(o.titre || '')}">${ticks}
      <line x1="${pl}" x2="${W - pr}" y1="${Yb(0).toFixed(1)}" y2="${Yb(0).toFixed(1)}" class="gr-base"/>${barres}${ligne}</svg>
      <figcaption class="gr-legende"><span><i style="background:${o.barres.couleur || C.barre}"></i>${e(o.barres.libelle || o.barres.nom)}</span>
      ${o.ligne ? `<span><i class="gr-trait" style="background:${o.ligne.couleur}"></i>${e(o.ligne.libelle || o.ligne.nom)}</span>` : ''}
      ${o.enCours ? `<span><i style="background:${C.barreEnCours}"></i>${e(o.enCoursLib || 'Période en cours')}</span>` : ''}</figcaption></figure>`;
  }

  /* Courbes dans le temps (dates réellement espacées), zones de référence et seuils. */
  function courbeTemps(o) {
    const series = o.series.filter(s => s.points.length);
    if (!series.length) return vide(o.vide || 'Aucune mesure enregistrée.');
    const W = o.w || 760, H = o.h || 240, pl = 58, pr = 18, pt = 16, pb = 32;
    let t0 = Math.min(...series.flatMap(s => s.points.map(p => Date.parse(p.t)))), t1 = Math.max(...series.flatMap(s => s.points.map(p => Date.parse(p.t))));
    if (t1 - t0 < 40 * 864e5) { t0 -= 20 * 864e5; t1 += 20 * 864e5; }
    const X = t => pl + (Date.parse(t) - t0) / (t1 - t0) * (W - pl - pr);
    const Y = v => pt + (1 - (Math.min(Math.max(v, o.y.min), o.y.max) - o.y.min) / (o.y.max - o.y.min)) * (H - pt - pb);
    const zones = (o.zones || []).map(z => `<rect x="${pl}" y="${Y(z.a).toFixed(1)}" width="${W - pl - pr}" height="${Math.max(0, Y(z.de) - Y(z.a)).toFixed(1)}" fill="${z.couleur || C.normal}"/>
      ${z.l ? `<text x="${W - pr - 6}" y="${(Y(z.a) + 13).toFixed(1)}" text-anchor="end" class="gr-zone">${e(z.l)}</text>` : ''}`).join('');
    const grille = o.y.ticks.map(v => `<line x1="${pl}" x2="${W - pr}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}" class="gr-grille"/>
      <text x="${pl - 8}" y="${(Y(v) + 4).toFixed(1)}" text-anchor="end" class="gr-axe">${e(String(v).replace('.', ','))}</text>`).join('');
    const seuils = (o.seuils || []).map(s => `<line x1="${pl}" x2="${W - pr}" y1="${Y(s.v).toFixed(1)}" y2="${Y(s.v).toFixed(1)}" stroke="${s.couleur}" stroke-width="1.2" stroke-dasharray="5 4"/>
      <text x="${pl + 6}" y="${(Y(s.v) - 5).toFixed(1)}" class="gr-seuil" fill="${s.couleur}">${e(s.l)}</text>`).join('');
    const nMois = Math.max(1, Math.round((t1 - t0) / (30.44 * 864e5))), pas = Math.max(1, Math.ceil(nMois / 7)), grad = [];
    let m = new Date(Date.UTC(new Date(t0).getUTCFullYear(), new Date(t0).getUTCMonth() + 1, 1));
    for (let i = 0; m.getTime() <= t1 && i < 200; i++) {
      if (i % pas === 0) grad.push(`<text x="${X(m.toISOString()).toFixed(1)}" y="${H - 10}" text-anchor="middle" class="gr-axe">${libMois(m.toISOString().slice(0, 7), true)}</text>`);
      m = new Date(Date.UTC(m.getUTCFullYear(), m.getUTCMonth() + 1, 1));
    }
    const traces = series.map(s => {
      const pts = s.points.slice().sort((a, b) => a.t.localeCompare(b.t));
      return `<path d="${pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p.v).toFixed(1)}`).join(' ')}" fill="none" stroke="${s.couleur}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>
        ${pts.map(p => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="4.2" fill="${s.couleur}" stroke="#fff" stroke-width="1.6"/>
        <circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="11" fill="transparent" class="gr-cible" tabindex="0" data-tip="${e(`${s.nom}, ${dateLongue(p.t)} : ${p.txt}${o.unite ? ' ' + o.unite : ''}`)}"/>`).join('')}`;
    }).join('');
    return `<figure class="gr-graph"><svg viewBox="0 0 ${W} ${H}" style="max-width:${Math.round(W * 1.3)}px" role="img" aria-label="${e(o.titre || '')}">
      ${zones}${grille}<line x1="${pl}" x2="${W - pr}" y1="${H - pb}" y2="${H - pb}" class="gr-base"/>${grad.join('')}${seuils}${traces}</svg>
      <figcaption class="gr-legende">${series.map(s => `<span><i style="background:${s.couleur}"></i>${e(s.nom)}</span>`).join('')}${o.unite ? `<span class="gr-note-unite">en ${e(o.unite)}</span>` : ''}</figcaption></figure>`;
  }

  /* Anneau de répartition. */
  function anneau(o) {
    const parts = o.parts.filter(p => p.v > 0), tot = parts.reduce((s, p) => s + p.v, 0);
    if (!tot) return vide(o.vide || 'Aucune donnée sur la période.');
    const R = 62, circ = 2 * Math.PI * R, f = o.fmt || nb, fl = o.fmtLeg || f;
    let cumul = 0;
    const arcs = parts.map((p, i) => {
      const long = p.v / tot * circ, col = p.c || PALETTE[i % PALETTE.length];
      const a = `<circle cx="90" cy="90" r="${R}" fill="none" stroke="${col}" stroke-width="26" stroke-dasharray="${long.toFixed(2)} ${(circ - long).toFixed(2)}" stroke-dashoffset="${(-cumul).toFixed(2)}"
        transform="rotate(-90 90 90)" class="gr-arc" tabindex="0" data-tip="${e(`${p.l} : ${f(p.v)} (${Math.round(p.v / tot * 100)} %)`)}"/>`;
      cumul += long;
      return a;
    }).join('');
    return `<div class="gr-anneau"><svg viewBox="0 0 180 180" role="img" aria-label="${e(o.titre || '')}">${arcs}
      <text x="90" y="88" text-anchor="middle" class="gr-centre">${o.centre != null ? o.centre : abrege(tot)}</text>
      <text x="90" y="108" text-anchor="middle" class="gr-axe">${e(o.centreLib || 'au total')}</text></svg>
      <ul class="gr-anneau-leg">${parts.map((p, i) => `<li><i style="background:${p.c || PALETTE[i % PALETTE.length]}"></i><span title="${e(p.l)}">${e(p.l)}</span><b>${fl(p.v)}</b><em>${Math.round(p.v / tot * 100)} %</em></li>`).join('')}</ul></div>`;
  }

  /* Barres horizontales (classements). */
  function barresH(lignes, { couleur = C.barre, fmt = nb, videTxt, detail } = {}) {
    if (!lignes.length) return vide(videTxt || 'Aucune donnée sur la période.');
    const m = Math.max(1, ...lignes.map(l => l.v));
    return `<div class="gr-hbars">${lignes.map(l => `<div class="gr-hbar"><div class="gr-hbar-l" title="${e(l.l)}">${e(l.l)}${detail && l.d ? `<small>${e(l.d)}</small>` : ''}</div>
      <div class="gr-hbar-p"><span style="width:${Math.max(1.5, l.v / m * 100).toFixed(1)}%;background:${l.c || couleur}"></span></div><div class="gr-hbar-v">${fmt(l.v)}</div></div>`).join('')}</div>`;
  }

  /* Petite courbe d'indicateur (30 derniers jours). */
  function etincelle(vals, couleur = C.petrole) {
    if (vals.length < 2 || !vals.some(v => v > 0)) return '';
    const W = 120, H = 30, m = Math.max(...vals) || 1, X = i => 2 + i / (vals.length - 1) * (W - 4), Y = v => H - 3 - v / m * (H - 6);
    return `<svg class="gr-etincelle" viewBox="0 0 ${W} ${H}" aria-hidden="true"><path d="${vals.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ')}" fill="none" stroke="${couleur}" stroke-width="1.8" stroke-linejoin="round"/>
      <circle cx="${X(vals.length - 1).toFixed(1)}" cy="${Y(vals[vals.length - 1]).toFixed(1)}" r="2.6" fill="${couleur}"/></svg>`;
  }

  function tendance(actuel, precedent, libelle) {
    if (!precedent && !actuel) return '';
    if (!precedent) return `<span class="gr-tend gr-tend-neutre">nouveau par rapport ${e(aLib(libelle))}</span>`;
    const pct = Math.round((actuel - precedent) / precedent * 100), sens = pct > 0 ? 'hausse' : pct < 0 ? 'baisse' : 'egal';
    return `<span class="gr-tend gr-tend-${sens}">${pct > 0 ? '+' : ''}${pct} % par rapport ${e(aLib(libelle))}</span>`;
  }
  function kpi({ lib, val, sous, tend, spark, onglet, alerte }) {
    return `<div class="gr-kpi${alerte ? ' gr-kpi-alerte' : ''}"${onglet ? ` data-action="onglet" data-tab="${onglet}" role="button" tabindex="0"` : ''}>
      <div class="gr-kpi-lib">${e(lib)}</div><div class="gr-kpi-val">${val}</div>${sous ? `<div class="gr-kpi-sous">${sous}</div>` : ''}${tend || ''}${spark || ''}</div>`;
  }

  /* Bulle d'information au survol, au toucher et au clavier ; onglets des courbes du dossier. */
  let bulle = null;
  const montrer = (el, x, y) => {
    if (!bulle) { bulle = document.createElement('div'); bulle.className = 'gr-bulle'; bulle.setAttribute('role', 'status'); document.body.appendChild(bulle); }
    bulle.textContent = el.getAttribute('data-tip');
    bulle.style.display = 'block';
    const r = bulle.getBoundingClientRect();
    bulle.style.left = Math.min(window.innerWidth - r.width - 8, Math.max(8, x - r.width / 2)) + 'px';
    bulle.style.top = (y - r.height - 14 < 8 ? y + 18 : y - r.height - 14) + 'px';
  };
  const cacher = () => { if (bulle) bulle.style.display = 'none'; };
  const suivre = ev => { const el = ev.target.closest && ev.target.closest('[data-tip]'); if (el) montrer(el, ev.clientX, ev.clientY); else cacher(); };
  document.addEventListener('pointermove', suivre);
  document.addEventListener('pointerdown', suivre);
  document.addEventListener('scroll', cacher, true);
  document.addEventListener('focusin', ev => { const el = ev.target.closest && ev.target.closest('[data-tip]'); if (el) { const r = el.getBoundingClientRect(); montrer(el, r.left + r.width / 2, r.top); } });
  document.addEventListener('focusout', cacher);
  document.addEventListener('click', ev => {
    const o = ev.target.closest && ev.target.closest('[data-gr-onglet]');
    if (!o) return;
    const bloc = o.closest('[data-gr-onglets]');
    bloc.querySelectorAll('[data-gr-onglet]').forEach(b => b.setAttribute('aria-selected', String(b === o)));
    bloc.querySelectorAll('[data-gr-panneau]').forEach(p => { p.hidden = p.getAttribute('data-gr-panneau') !== o.getAttribute('data-gr-onglet'); });
  });
  document.addEventListener('keydown', ev => {
    if ((ev.key === 'Enter' || ev.key === ' ') && ev.target.matches && ev.target.matches('.gr-kpi[role="button"]')) { ev.preventDefault(); ev.target.click(); }
  });

  return { aLib, C, PALETTE, MOIS_L, JOURS, nb, montant, libMois, libCase, dateLongue, dateCourte, abrege, vide, histogramme, courbeTemps, anneau, barresH, etincelle, tendance, kpi };
})();
