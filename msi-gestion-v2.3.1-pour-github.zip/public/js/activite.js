'use strict';
/* Mon activité (v1.9) : tableau de bord personnel du médecin. Patients reçus (jour, mois), examens demandés, résultats,
   alertes de l'infirmerie et de l'hospitalisation, patients hospitalisés, rendez-vous. Chaque médecin ne voit que sa propre activité. */
const actUI = () => (UI.act = UI.act || { donnees: null, version: null, charge: false, erreur: null });
async function chargerActivite() {
  const a = actUI();
  if (a.charge) return;
  a.charge = true;
  try { a.donnees = await api('GET', '/api/medecin/tableau'); a.erreur = null; } catch (e) { a.erreur = e.message || 'Chargement impossible.'; }
  a.version = VERSION; a.charge = false;
  render();
}
const actMois = m => new Date(m + '-01T00:00:00Z').toLocaleDateString('fr-FR', { month: 'long', timeZone: 'UTC' });
function actAlertes(t) {
  if (!t.alertes.length) return '<p class="muted">Aucune alerte aujourd’hui.</p>';
  return `<ul class="list act-alertes">${t.alertes.map(a => `<li><div><strong>${esc(a.patient)}</strong> <span class="badge ${a.source === 'hospitalisation' ? 'b-warn' : 'b-bad'}">${a.source === 'hospitalisation' ? 'Hospitalisation' : 'Infirmerie'}</span></div>
    <div class="alerte-file">${esc(a.alertes.map(x => `${x.texte} (${x.valeur})`).join(', '))}</div>
    <small class="muted">${fmtDateTime(a.le)}${a.par ? ', ' + esc(a.par) : ''}${a.source === 'infirmerie' ? (a.recu ? ', patient reçu' : ', en attente de consultation') : ''}</small></li>`).join('')}</ul>`;
}
function vActivite() {
  const a = actUI();
  if (!a.charge && (!a.donnees || a.version !== VERSION)) chargerActivite();
  const t = a.donnees;
  const tete = `<div class="view-head"><div><h1>Mon activité</h1><p class="lead">Vos patients, vos examens et les alertes de l’infirmerie.</p></div><button class="btn btn-ghost btn-sm" data-action="actRafraichir">Actualiser</button></div>`;
  if (!t) return tete + `<p class="muted">${a.erreur ? esc(a.erreur) : 'Chargement…'}</p>`;
  const mois = actMois(t.mois), prec = t.precedent.patients, cur = t.mois_courant.patients;
  const evol = prec ? `${cur >= prec ? '+' : ''}${Math.round((cur - prec) * 100 / prec)} % par rapport à ${actMois(t.mois_precedent)}` : `${t.mois_courant.consultations} consultation${t.mois_courant.consultations > 1 ? 's' : ''}`;
  const enAttente = t.alertes.filter(x => x.source === 'infirmerie' && !x.recu).length;
  return `${tete}
    <div class="pil-kpis">
      ${GR.kpi({ lib: 'Patients reçus aujourd’hui', val: t.aujourdhui.patients, sous: `${t.aujourdhui.consultations} consultation${t.aujourdhui.consultations > 1 ? 's' : ''}${t.en_cours ? `, ${t.en_cours} en cours` : ''}`, onglet: 'consultations' })}
      ${GR.kpi({ lib: `Patients reçus en ${mois}`, val: cur, sous: evol, spark: GR.etincelle(t.serie.map(x => x.n)) })}
      ${GR.kpi({ lib: 'Examens demandés ce mois', val: t.examens.demandes, sous: `${t.resultats.recus} résultat${t.resultats.recus > 1 ? 's' : ''} reçu${t.resultats.recus > 1 ? 's' : ''}${t.resultats.anormaux ? `, dont ${t.resultats.anormaux} anormal${t.resultats.anormaux > 1 ? 'aux' : ''}` : ''} ; ${t.resultats.en_attente} en attente`, alerte: t.resultats.anormaux > 0 })}
      ${GR.kpi({ lib: 'Alertes de l’infirmerie', val: t.alertes.length, sous: enAttente ? `${enAttente} patient${enAttente > 1 ? 's' : ''} en attente de consultation` : `${t.hospitalises} patient${t.hospitalises > 1 ? 's' : ''} hospitalisé${t.hospitalises > 1 ? 's' : ''} sous votre référence`, alerte: enAttente > 0 })}
    </div>
    <div class="pil-grille">
      <div class="panel"><h2>Alertes du jour</h2>${actAlertes(t)}</div>
      <div class="panel">${GR.histogramme({ titre: 'Consultations des 30 derniers jours', libs: t.serie.map(x => x.jour.slice(8, 10)), titres: t.serie.map(x => fmtDate(x.jour)), barres: { vals: t.serie.map(x => x.n), nom: 'Consultations', fmt: GR.nb }, vide: 'Aucune consultation sur les 30 derniers jours.' })}</div>
      <div class="panel"><h2>Examens les plus demandés en ${mois}</h2>${GR.barresH(t.examens.top.map(x => ({ l: x.l, v: x.n })), { videTxt: 'Aucune demande d’examens ce mois.' })}</div>
      <div class="panel"><h2>Documents émis en ${mois}</h2>${GR.barresH(t.documents.map(x => ({ l: x.libelle, v: x.n })), { videTxt: 'Aucun document émis ce mois.' })}</div>
      <div class="panel"><h2>Rendez-vous des 7 prochains jours</h2>${t.rdv.length ? `<ul class="list">${t.rdv.map(r => `<li><strong>${esc(r.nom)} ${esc(r.prenoms || '')}</strong><small class="muted">${fmtDate(r.date)}${r.heure ? ' à ' + esc(String(r.heure).replace(':', ' h ')) : ''}${r.motif ? ', ' + esc(r.motif) : ''}</small></li>`).join('')}</ul>` : '<p class="muted">Aucun rendez-vous à venir.</p>'}</div>
    </div>`;
}
Object.assign(ACTIONS, { actRafraichir: () => { actUI().version = null; chargerActivite(); } });
ONGLETS.push({ id: 'activite', libelle: 'Mon activité', icone: 'pilotage', visible: () => peut('consulter'),
  compteur: () => (UI.act && UI.act.donnees ? UI.act.donnees.alertes.filter(x => x.source === 'infirmerie' && !x.recu).length : 0), vue: vActivite });
