'use strict';
/* Poste Consultations : le formulaire de chaque spécialité est construit à partir du référentiel partagé (specialites.js). */
const SP = window.MSI_SPECIALITES;
const ETATS_FILE = { a_payer: ['b-due', 'À régler à la caisse'], prete: ['b-ok', 'Prêt'], en_cours: ['b-warn', 'En cours'], terminee: ['b-muted', 'Terminée'] };
function etatCons() {
  if (!UI.cons) UI.cons = { sel: null, cid: null, c: null, d: {}, dossier: null, onglet: 'consultation', sale: false };
  return UI.cons;
}
const mesSpecialites = () => (MOI.utilisateur.specialites && MOI.utilisateur.specialites.length ? MOI.utilisateur.specialites : SP.noms());
const ligneFile = id => (E.file_medecin || []).find(x => x.passage_id === id) || null;
const contexteClinique = sp => (/pédiatri/i.test(sp.nom) ? 'enfant' : null);
const alerteHTML = a => (a ? `<span class="badge ${a.niveau === 'bad' ? 'b-bad' : 'b-warn'}">${esc(a.texte)}</span>` : '');
const idSur = s => String(s).replace(/[^a-zA-Z0-9]+/g, '_');

/* Structure commune à toutes les spécialités : motif, antécédents, constantes, examen propre, conclusion. */
function structure(sp) {
  return [
    { titre: 'Motif de consultation', champs: [{ k: 'motif', l: 'Plainte du patient', t: 'zone', suggestions: sp.motifs, lignes: 2 }] },
    { titre: 'Antécédents', champs: [
      { k: 'atcd_familiaux', l: 'Familiaux', t: 'zone', suggestions: sp.atcd.familiaux },
      { k: 'atcd_medicaux', l: 'Médicaux', t: 'zone', suggestions: sp.atcd.medicaux },
      ...(sp.atcd.chirurgicaux.length ? [{ k: 'atcd_chirurgicaux', l: 'Chirurgicaux', t: 'zone', suggestions: sp.atcd.chirurgicaux }] : []),
      { k: 'traitements', l: 'Traitements en cours', t: 'zone', suggestions: sp.atcd.traitements },
      { k: 'allergies', l: 'Allergies', t: 'texte' }, ...sp.atcd_extra] },
    ...(sp.constantes.length ? [{ titre: 'Constantes', champs: sp.constantes.map(k => ({ k, l: SP.CONSTANTES[k].l, t: 'constante', unite: SP.CONSTANTES[k].unite })) }] : []),
    ...sp.sections,
    { titre: 'Conclusion', champs: [
      { k: 'diagnostic', l: 'Diagnostic', t: 'zone', suggestions: sp.diagnostics },
      { k: 'conduite', l: 'Conduite à tenir', t: 'zone', suggestions: sp.conduites },
      { k: 'prochain_controle', l: 'Prochain contrôle', t: 'date' }] }
  ];
}

function vConsultations() {
  const s = etatCons(), file = E.file_medecin || [];
  const rdv = (E.rdv || []).filter(r => r.date === todayISO() && r.medecin_id === MOI.utilisateur.id && r.statut === 'prevu');
  return `<div class="view-head"><div><h1>Consultations</h1><p class="lead">${esc(mesSpecialites().join(', '))}. La consultation s’ouvre dès que le bon est réglé.</p></div>${mesSpecialites().includes('Ophtalmologie') ? '<div class="head-actions"><button class="btn btn-ghost" data-action="repriseOuvrir">Reprise OphtaSuite</button></div>' : ''}</div>
  <div class="grid-2"><section>
    <div class="panel"><h2>Ma file du jour</h2>${file.length ? `<ul class="list">${file.map(x => {
      const [cls, txt] = ETATS_FILE[x.statut];
      return `<li><button class="row-btn" data-action="consChoisir" data-id="${x.passage_id}"${s.sel === x.passage_id ? ' aria-current="true"' : ''}>
        <span class="rb-main"><strong>${esc(nomPatient(x.patient))}</strong><span class="muted">${esc(x.numero)}, ${fmtTime(x.cree_le)}${x.specialite ? ', ' + esc(lcFirst(x.specialite)) : ''}</span></span>
        <span class="rb-side">${x.urgent ? '<span class="badge b-bad">Urgence</span>' : ''}<span class="badge ${cls}">${txt}</span></span>${x.prioritaire ? `<small class="alerte-file">Prioritaire : ${esc((x.alertes || []).map(a => a.texte + ' (' + a.valeur + ')').join(', '))}</small>` : ''}${x.orientation ? `<small class="muted">${x.orientation.par === 'l’accueil' ? 'Choisi par l’accueil' : 'Constantes prises par ' + esc(x.orientation.par)}</small>` : ''}${x.motif ? `<small class="muted">Motif : ${esc(x.motif)}</small>` : ''}</button></li>`;
    }).join('')}</ul>` : '<p class="muted">Aucun patient pour vos spécialités aujourd’hui.</p>'}</div>
    ${rdv.length ? `<div class="panel"><h2>Mes rendez-vous du jour</h2><ul class="plist">${rdv.map(r => `<li><div><strong>${esc(r.nom + ' ' + r.prenoms)}</strong><div class="muted">${esc(r.motif || '')}</div></div><div class="pl-side">${esc(r.heure || '')}</div></li>`).join('')}</ul></div>` : ''}
  </section><section id="cons-detail">${detailConsultation()}</section></div>`;
}
function enTete(x) {
  const p = x.patient, [cls, txt] = ETATS_FILE[x.statut];
  return `<div class="pat-head"><div><h2 class="pat-name">${esc(nomPatient(p))}</h2><p class="muted">${esc(p.ipp)}${p.sexe ? ', ' + (p.sexe === 'F' ? 'femme' : 'homme') : ''}${p.naissance ? ', ' + age(p.naissance) + ' ans' : ''}, passage ${esc(x.numero)}</p></div><span class="badge ${cls}">${txt}</span></div>` + boutonFicheMedecin(p);
}
function detailConsultation() {
  const s = etatCons(), x = ligneFile(s.sel);
  if (!x) return vide('Aucun patient sélectionné', 'Choisissez un patient dans votre file du jour.');
  if (x.statut === 'a_payer') return `<div class="panel">${enTete(x)}<div class="notice bad">Consultation bloquée : le bon de consultation n’est pas réglé. Dès le passage du patient à la caisse, sa fiche s’ouvre ici automatiquement.</div></div>`;
  if (!s.c) {
    return `<div class="panel">${enTete(x)}${x.urgent ? '<div class="notice warn">Urgence : le règlement sera régularisé à la caisse.</div>' : ''}
      ${x.specialite ? `<p class="muted">Consultation de ${esc(lcFirst(x.specialite))}.</p>` : champ('Spécialité', `<select id="cons-sp">${mesSpecialites().map(n => `<option>${esc(n)}</option>`).join('')}</select>`)}
      <button class="btn btn-block" data-action="consCommencer">Commencer la consultation</button></div>`;
  }
  const c = s.c, sp = SP.SPECIALITES[c.specialite], lecture = (!!c.valide_le && !s.modif) || c.medecin_id !== MOI.utilisateur.id;
  return `<div class="panel">${enTete(x)}<p class="muted">${esc(c.specialite)}${c.valide_le ? `, validée ${fmtDateTime(c.valide_le)}` : ''}</p>
    <div class="seg" role="group" aria-label="Volets de la consultation">${[['consultation', 'Consultation'], ['documents', 'Documents'], ['dossier', 'Dossier']].map(([k, l]) => `<button data-action="consOnglet" data-o="${k}" aria-pressed="${s.onglet === k}">${l}</button>`).join('')}</div></div>
    ${s.onglet === 'documents' ? ongletDocuments(c, sp) : s.onglet === 'dossier' ? ongletDossier() : lecture ? resumeConsultation(c, sp) : formulaireConsultation(sp, s.d)}`;
}

/* Champs de saisie */
const chipsHTML = (k, suggestions, cote) => (suggestions && suggestions.length ? `<div class="chips">${suggestions.map(v => `<button class="chip" data-action="consChip" data-k="${esc(k)}"${cote ? ` data-cote="${esc(cote)}"` : ''} data-v="${esc(v)}">${esc(v)}</button>`).join('')}</div>` : '');
function termeHTML(ddr) {
  const t = SP.terme(ddr);
  return t ? `<span class="badge">Terme ${t.sa} SA + ${t.jours} j, accouchement prévu le ${fmtDate(t.dpa)}</span>` : '';
}
function champHTML(f, d, sp) {
  const v = d[f.k] == null ? '' : d[f.k], lab = esc(f.l) + (f.unite ? ` (${esc(f.unite)})` : '');
  const attr = `data-input="consChamp" data-k="${esc(f.k)}"`;
  switch (f.t) {
    case 'zone': return `<label class="f"><span>${lab}</span><textarea rows="${f.lignes || 2}" ${attr}>${esc(v)}</textarea></label>${chipsHTML(f.k, f.suggestions)}`;
    case 'liste': return champ(lab, `<select ${attr.replace('data-input', 'data-change')}><option value=""></option>${f.options.map(o => `<option${o === v ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`);
    case 'date': return `<label class="f"><span>${lab}</span><input type="date" ${attr} value="${esc(v)}">${f.k === 'ddr' ? `<span class="alerte" id="al-ddr">${termeHTML(v)}</span>` : ''}</label>`;
    case 'constante': {
      const valeur = f.k === 'imc' ? (SP.imc(d.taille, d.poids) || '') : v;
      return `<label class="f"><span>${lab}</span><input ${f.k === 'imc' ? 'readonly tabindex="-1" id="imc"' : attr + (d._constantes && v ? ' readonly title="Prise à l’infirmerie"' : '')} value="${esc(valeur)}" inputmode="${f.k === 'ta' ? 'text' : 'decimal'}" placeholder="${esc(SP.CONSTANTES[f.k].exemple || '')}" autocomplete="off"><span class="alerte" id="al-${f.k}">${alerteHTML(SP.alerte(f.k, valeur, contexteClinique(sp)))}</span></label>`;
    }
    case 'nombre': return `<label class="f"><span>${lab}</span><input ${attr} value="${esc(v)}" inputmode="decimal" autocomplete="off"><span class="alerte" id="al-${f.k}">${alerteHTML(f.alerte ? SP.alerte(f.alerte, v) : null)}</span></label>`;
    case 'paire': {
      const vals = d[f.k] || {};
      return `<div class="f-bloc"><div class="f-titre">${lab}</div><div class="paire">${f.cotes.map(cote => {
        const a = `data-input="consChamp" data-k="${esc(f.k)}" data-cote="${esc(cote)}"`;
        return `<div><label class="f"><span>${esc(cote)}</span>${f.zone ? `<textarea rows="3" ${a}>${esc(vals[cote] || '')}</textarea>` : `<input ${a} value="${esc(vals[cote] || '')}" inputmode="${f.nombre ? 'decimal' : 'text'}" autocomplete="off">`}
          ${f.alerte ? `<span class="alerte" id="al-${idSur(f.k + '-' + cote)}">${alerteHTML(SP.alerte(f.alerte, vals[cote]))}</span>` : ''}</label>
          ${f.constats ? `<details class="constats"><summary>Constats ${esc(cote)}</summary>${Object.entries(f.constats).map(([gr, items]) => `<div class="constats-groupe"><strong>${esc(gr)}</strong>${chipsHTML(f.k, items.map(i => `${gr} : ${i}`), cote)}</div>`).join('')}</details>` : ''}</div>`;
      }).join('')}</div></div>`;
    }
    default: return champ(lab, `<input ${attr} value="${esc(v)}" placeholder="${esc(f.exemple || '')}" autocomplete="off">`);
  }
}
/* Constantes prises à l'infirmerie (v1.5) : affichées avec leur auteur ; le médecin complète seulement ce qui manque. */
function noteConstantes(d) {
  const c = d && d._constantes;
  return c ? `<p class="notice ok">Prises par ${esc(c.par || 'l’infirmerie')} ${fmtDateTime(c.le)}${c.observation ? `. Observation : ${esc(c.observation)}` : ''}.</p>` : '';
}
function formulaireConsultation(sp, d) {
  return structure(sp).map(sec => `<div class="panel"><h2>${esc(sec.titre)}</h2>${sec.titre === 'Constantes' ? `${noteConstantes(d)}<div class="constantes">${sec.champs.map(f => champHTML(f, d, sp)).join('')}</div>` : sec.champs.map(f => champHTML(f, d, sp)).join('')}</div>`).join('') +
    `<div class="panel"><p class="hint" id="cons-etat">${etatCons().sale ? 'Modifications non enregistrées.' : 'Brouillon à jour.'} Enregistrement automatique toutes les 30 secondes.</p>
    ${etatCons().modif ? '<div class="notice">Modification d’une consultation validée : sa version actuelle sera conservée dans l’historique, avec votre motif. Les documents déjà remis au patient ne changent pas.</div><div class="row-actions"><button class="btn btn-ghost" data-action="consModifAnnuler">Abandonner la modification</button><button class="btn btn-accent" data-action="consModifEnregistrer">Enregistrer la modification</button></div>' : '<div class="row-actions"><button class="btn btn-ghost" data-action="consEnregistrer">Enregistrer le brouillon</button><button class="btn btn-accent" data-action="consValider">Valider la consultation</button></div>'}</div>`;
}
function resumeConsultation(c, sp) {
  const d = c.donnees || {}, lignes = [];
  for (const sec of structure(sp)) for (const f of sec.champs) {
    let v = f.k === 'imc' ? SP.imc(d.taille, d.poids) : d[f.k];
    if (v && typeof v === 'object') v = Object.entries(v).filter(([, x]) => x).map(([k, x]) => `${k} : ${x}`).join('\n');
    if (v === undefined || v === null || v === '') continue;
    lignes.push(`<div><dt>${esc(f.l)}${f.unite ? ` (${esc(f.unite)})` : ''}</dt><dd>${esc(f.t === 'date' ? fmtDate(v) : v)}</dd></div>`);
  }
  return `<div class="panel"><h2>${c.valide_le ? 'Consultation validée' : 'Consultation en cours d’un autre médecin'}</h2><dl class="kv-lecture">${lignes.join('') || '<p class="muted">Aucune donnée saisie.</p>'}</dl>${historiqueModifications(c)}
    ${c.valide_le && c.medecin_id === MOI.utilisateur.id ? '<button class="btn" data-action="consModifier">Modifier la consultation</button> ' : ''}${c.valide_le && c.medecin_id === MOI.utilisateur.id ? '<button class="btn btn-ghost" data-action="docNouveau" data-type="note">Ajouter une note complémentaire</button>' : ''}</div>`;
}
/* Évolution des constantes du patient au fil des consultations : tension, poids, glycémie, température. */
function courbesConstantes(liste) {
  const cs = liste.filter(x => x.donnees).slice().sort((a, b) => a.cree_le.localeCompare(b.cree_le));
  const num = (v, min, max) => { const n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) && n >= min && n <= max ? n : null; };
  const ta = v => {
    const m = /(\d+(?:[.,]\d+)?)\s*[/\\-]\s*(\d+(?:[.,]\d+)?)/.exec(String(v || ''));
    if (!m) return null;
    let s = Number(m[1].replace(',', '.')), d = Number(m[2].replace(',', '.'));
    if (s < 30) { s *= 10; d *= 10; }
    return s > 50 && s < 300 && d > 20 && d < 200 ? { s, d } : null;
  };
  const gly = v => { const n = num(v, 0.2, 700); return n == null ? null : n > 20 ? n / 100 : n; };
  const pts = (lire, champ, cle) => cs.map(x => { const v = lire(x.donnees[champ]); return v == null ? null : { t: x.cree_le.slice(0, 10), v: cle ? v[cle] : v, txt: x.donnees[champ] }; }).filter(Boolean);
  const dans = (t, a, b) => t.filter(v => v >= a && v <= b);
  const onglets = [];
  const taS = pts(ta, 'ta', 's'), taD = pts(ta, 'ta', 'd');
  if (taS.length) onglets.push({ id: 'ta', lib: 'Tension artérielle', html: GR.courbeTemps({ titre: 'Tension artérielle', unite: 'mmHg', w: 760, h: 240,
    series: [{ nom: 'Systolique', couleur: GR.C.petrole, points: taS }, { nom: 'Diastolique', couleur: GR.C.cuivre, points: taD }],
    y: { min: 40, max: 200, ticks: [60, 80, 90, 120, 140, 160, 180] }, seuils: [{ v: 140, couleur: GR.C.alerte, l: 'Hypertension : systolique 140' }, { v: 90, couleur: GR.C.cuivre, l: 'diastolique 90' }] }) });
  const poids = pts(v => num(v, 1, 350), 'poids');
  if (poids.length) {
    const bas = Math.max(0, Math.floor((Math.min(...poids.map(p => p.v)) - 5) / 5) * 5), haut = Math.ceil((Math.max(...poids.map(p => p.v)) + 5) / 5) * 5, pas = haut - bas > 40 ? 10 : 5;
    onglets.push({ id: 'poids', lib: 'Poids', html: GR.courbeTemps({ titre: 'Poids', unite: 'kg', w: 760, h: 220, series: [{ nom: 'Poids', couleur: GR.C.petrole, points: poids }],
      y: { min: bas, max: haut, ticks: Array.from({ length: Math.floor((haut - bas) / pas) + 1 }, (_, i) => bas + i * pas) } }) });
  }
  const glyc = pts(gly, 'glycemie');
  if (glyc.length) {
    const haut = Math.max(2.5, Math.ceil(Math.max(...glyc.map(p => p.v)) * 2) / 2);
    onglets.push({ id: 'gly', lib: 'Glycémie', html: GR.courbeTemps({ titre: 'Glycémie', unite: 'g/L', w: 760, h: 220, series: [{ nom: 'Glycémie', couleur: GR.C.cuivre, points: glyc }],
      y: { min: 0.4, max: haut, ticks: dans([0.5, 1, 1.26, 2, 3, 4, 5], 0.4, haut) }, zones: [{ de: 0.7, a: 1.1, l: 'À jeun normale (0,70 à 1,10 g/L)' }], seuils: [{ v: 1.26, couleur: GR.C.alerte, l: 'Diabète à jeun 1,26 g/L' }] }) });
  }
  const temp = pts(v => num(v, 30, 45), 'temperature');
  if (temp.length) onglets.push({ id: 'temp', lib: 'Température', html: GR.courbeTemps({ titre: 'Température', unite: '°C', w: 760, h: 200, series: [{ nom: 'Température', couleur: GR.C.petrole, points: temp }],
    y: { min: 35, max: 41, ticks: [35, 36, 37, 38, 39, 40, 41] }, zones: [{ de: 36.1, a: 37.5, l: 'Normale' }], seuils: [{ v: 38, couleur: GR.C.alerte, l: 'Fièvre 38 °C' }] }) });
  if (!onglets.length) return '';
  return `<div class="panel gr-panneau-courbes" data-gr-onglets><div class="gr-tete"><h2>Évolution des constantes</h2><span class="muted">${cs.length} consultation${cs.length > 1 ? 's' : ''}</span></div>
    <div class="gr-seg" role="tablist">${onglets.map((o, i) => `<button type="button" role="tab" aria-selected="${i === 0}" data-gr-onglet="${o.id}">${o.lib}</button>`).join('')}</div>
    ${onglets.map((o, i) => `<div data-gr-panneau="${o.id}"${i ? ' hidden' : ''}>${o.html}</div>`).join('')}</div>`;
}
function ongletDossier() {
  const d = etatCons().dossier;
  if (!d) return vide('Dossier indisponible', 'Rechargez la fiche du patient.');
  const cons = d.consultations.filter(x => x.id !== etatCons().cid);
  return `${courbesConstantes(d.consultations)}<div class="panel"><h2>Consultations antérieures</h2>${cons.length ? `<ul class="plist">${cons.map(x => `<li><div><strong>${esc(x.specialite)}</strong>, ${fmtDate(jourDe(x.cree_le))}<div class="muted">${esc(x.medecin || '')}${x.diagnostic ? ' : ' + esc(x.diagnostic) : ''}${x.valide_le ? '' : ' (non validée)'}</div></div>
    <div class="pl-side"><button class="btn btn-sm btn-ghost" data-action="consVoirAncienne" data-id="${x.id}">Voir</button></div></li>`).join('')}</ul>` : '<p class="muted">Première consultation enregistrée pour ce patient.</p>'}</div>
    ${(d.resultats || []).length ? `<div class="panel"><h2>Résultats de laboratoire</h2>${d.resultats.map(r => `<div class="res-labo"><strong>${esc(r.libelle)}</strong> <span class="muted">validé le ${fmtDate(jourDe(r.valide_le))}</span>
      <ul class="plist compact">${r.donnees.filter(l => l.valeur).map(l => `<li><div>${esc(l.p)}</div><div class="pl-side"><strong${l.drapeau ? ' class="is-bad"' : ''}>${esc(l.valeur)} ${esc(l.unite)}</strong>${l.drapeau ? (l.drapeau === 'H' ? ' ↑' : ' ↓') : ''}</div></li>`).join('')}</ul>${r.conclusion ? `<p class="muted">${esc(r.conclusion)}</p>` : ''}</div>`).join('')}</div>` : ''}
    <div class="panel"><h2>Documents médicaux</h2>${listeDocuments(d.documents)}</div>
    ${galeriePieces(d.pieces || [], false)}
    ${d.rdv.length ? `<div class="panel"><h2>Rendez-vous</h2><ul class="plist">${d.rdv.map(r => `<li><div><strong>${fmtDate(r.date)}${r.heure ? ' à ' + esc(r.heure) : ''}</strong><div class="muted">${esc(r.specialite || '')}${r.motif ? ', ' + esc(r.motif) : ''}</div></div><div class="pl-side"><span class="badge b-muted">${esc(r.statut)}</span></div></li>`).join('')}</ul></div>` : ''}`;
}

/* Saisie, enregistrement, validation */
function majChamp(el) {
  const s = etatCons(), k = el.dataset.k, cote = el.dataset.cote;
  if (cote) { s.d[k] = { ...(s.d[k] || {}), [cote]: el.value }; } else s.d[k] = el.value;
  s.sale = true;
  const sp = SP.SPECIALITES[s.c.specialite], etat = $('#cons-etat');
  if (etat) etat.textContent = 'Modifications non enregistrées. Enregistrement automatique toutes les 30 secondes.';
  if (SP.CONSTANTES[k]) { const al = $('#al-' + k); if (al) al.innerHTML = alerteHTML(SP.alerte(k, el.value, contexteClinique(sp))); }
  if (k === 'taille' || k === 'poids') { const i = $('#imc'), v = SP.imc(s.d.taille, s.d.poids); if (i) i.value = v || ''; const al = $('#al-imc'); if (al) al.innerHTML = alerteHTML(SP.alerte('imc', v)); }
  if (k === 'ddr') { const al = $('#al-ddr'); if (al) al.innerHTML = termeHTML(el.value); }
  const f = structure(sp).flatMap(x => x.champs).find(x => x.k === k);
  if (f && f.alerte) { const al = $('#al-' + idSur(cote ? k + '-' + cote : k)); if (al) al.innerHTML = alerteHTML(SP.alerte(f.alerte, el.value)); }
}
async function sauverBrouillon(silencieux) {
  const s = etatCons();
  if (!s.c || s.c.valide_le || s.c.medecin_id !== MOI.utilisateur.id || !s.sale) return true;
  try {
    await api('PUT', '/api/consultations/' + s.cid, { donnees: s.d });
    s.sale = false;
    const etat = $('#cons-etat');
    if (etat) etat.textContent = 'Brouillon enregistré à ' + fmtTime(new Date()) + '.';
    if (!silencieux) toast('Brouillon enregistré.');
    return true;
  } catch (e) { if (!silencieux) toast(e.message, 'bad'); return false; }
}
setInterval(() => { if (UI && UI.cons && UI.tab === 'consultations') sauverBrouillon(true); }, 30000);
async function chargerConsultation(passageId) {
  const s = etatCons(), x = ligneFile(passageId);
  s.sel = passageId; s.c = null; s.cid = null; s.d = {}; s.sale = false; s.modif = false; s.dAvantModif = null;
  if (!x) return;
  if (x.consultation) { const c = await api('GET', '/api/consultations/' + x.consultation.id); s.c = c; s.cid = c.id; s.d = c.donnees || {}; }
  if (x.statut !== 'a_payer' && (!s.dossier || s.dossier.patient.id !== x.patient.id)) s.dossier = await api('GET', '/api/dossiers/' + x.patient.id);
}
async function rechargerDossier() {
  const x = ligneFile(etatCons().sel);
  if (x) etatCons().dossier = await api('GET', '/api/dossiers/' + x.patient.id);
}

Object.assign(ACTIONS, {
  consChoisir: async el => {
    if (etatCons().modif && etatCons().sale) { toast('Enregistrez ou abandonnez d’abord la modification de la consultation.', 'bad'); return; }
    if (!(await sauverBrouillon(true))) return;
    try { etatCons().onglet = 'consultation'; await chargerConsultation(Number(el.dataset.id)); render(); scrollToId('cons-detail'); } catch (e) { toast(e.message, 'bad'); }
  },
  consCommencer: async () => {
    const s = etatCons(), x = ligneFile(s.sel), choix = $('#cons-sp');
    const r = await agir(() => api('POST', '/api/consultations', { passage_id: x.passage_id, specialite: choix ? choix.value : undefined }));
    if (r) { await chargerConsultation(x.passage_id); s.onglet = 'consultation'; render(); }
  },
  consOnglet: async el => { await sauverBrouillon(true); etatCons().onglet = el.dataset.o; render(); },
  consChip: el => {
    const k = el.dataset.k, cote = el.dataset.cote, v = el.dataset.v;
    const cible = [...document.querySelectorAll('[data-input="consChamp"]')].find(x => x.dataset.k === k && (x.dataset.cote || '') === (cote || ''));
    if (!cible) return;
    const actuel = cible.value.trim();
    if (actuel.split('\n').map(z => z.trim()).includes(v)) return;
    cible.value = actuel ? actuel + '\n' + v : v;
    majChamp(cible);
  },
  consEnregistrer: () => sauverBrouillon(false),
  consValider: () => openModal(`<div class="modal-head"><h2>Valider la consultation</h2>${closeBtn()}</div>
    <p>Une consultation validée n’est plus modifiable : toute précision ultérieure se fait par une note complémentaire, datée et signée.</p>
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Continuer la saisie</button><button class="btn btn-accent" data-action="consValiderConfirmer">Valider</button></div>`),
  consValiderConfirmer: async () => {
    const s = etatCons();
    const ok = await agir(() => api('POST', `/api/consultations/${s.cid}/validation`, { donnees: s.d }), 'Consultation validée.');
    closeModal();
    if (ok) { s.sale = false; await chargerConsultation(s.sel); render(); }
  },
  consVoirAncienne: el => {
    const c = etatCons().dossier.consultations.find(x => x.id === Number(el.dataset.id));
    openModal(`<div class="modal-head"><div><h2>${esc(c.specialite)}, ${fmtDate(jourDe(c.cree_le))}</h2><p class="muted">${esc(c.medecin || '')}</p></div>${closeBtn()}</div>${resumeConsultation({ ...c, medecin_id: -1 }, SP.SPECIALITES[c.specialite])}`, { large: true, noFocus: true });
  }
});
Object.assign(INPUTS, { consChamp: el => majChamp(el) });
Object.assign(CHANGES, { consChamp: el => majChamp(el) });
ONGLETS.push({ id: 'consultations', libelle: 'Consultations', icone: 'consultations', visible: () => peut('consulter'),
  compteur: () => (E.file_medecin || []).filter(x => x.statut === 'prete').length, vue: vConsultations });

/* Consultation validée (v2.2) : son auteur peut la modifier ; chaque modification est motivée et la version précédente
   est conservée (historique inaltérable). Les médecins peuvent aussi corriger la fiche administrative du patient. */
function historiqueModifications(c) {
  const v = c.versions || [];
  return v.length ? `<div class="notice">Modifiée après validation ${v.length === 1 ? 'une fois' : v.length + ' fois'} ; les versions précédentes sont conservées.</div>
    <ul class="list cons-versions">${v.map(x => `<li><span>${fmtDateTime(x.modifie_le)}, ${esc(x.par || '')}</span><small class="muted">Motif : ${esc(x.motif)}</small></li>`).join('')}</ul>` : '';
}
function boutonFicheMedecin(p) {
  return peut('patient_ecrire') && p ? `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-action="consFiche" data-id="${p.id}">Modifier la fiche du patient</button></div>` : '';
}
Object.assign(ACTIONS, {
  consModifier: () => { const s = etatCons(); s.modif = true; s.sale = false; s.dAvantModif = JSON.parse(JSON.stringify(s.d || {})); s.onglet = 'consultation'; render(); },
  consModifAnnuler: () => { const s = etatCons(); s.d = s.dAvantModif || s.d; s.modif = false; s.sale = false; s.dAvantModif = null; render(); },
  consModifEnregistrer: () => openModal(`<div class="modal-head"><h2>Enregistrer la modification</h2>${closeBtn()}</div>
    <p>La consultation validée sera mise à jour. Sa version actuelle est conservée dans l’historique, avec votre motif ; les documents déjà remis au patient ne changent pas.</p>
    ${champ('Motif de la modification (obligatoire)', '<textarea id="cm-motif" rows="2" maxlength="300" placeholder="Ex. résultat de glycémie reçu, diagnostic précisé"></textarea>')}
    <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Retour</button><button class="btn" data-action="consModifConfirmer">Enregistrer la modification</button></div>`),
  consModifConfirmer: async () => {
    const s = etatCons(), motif = ($('#cm-motif').value || '').trim();
    if (motif.length < 5) { toast('Indiquez le motif de la modification.', 'bad'); return; }
    const r = await agir(() => api('POST', `/api/consultations/${s.c.id}/modification`, { donnees: s.d, motif }), 'Consultation modifiée : la version précédente est conservée.');
    if (!r) return;
    closeModal();
    const c = await api('GET', '/api/consultations/' + s.c.id);
    s.c = c; s.cid = c.id; s.d = c.donnees || {}; s.modif = false; s.sale = false; s.dAvantModif = null;
    render();
  },
  consFiche: async el => {
    const f = await api('GET', '/api/patients/' + el.dataset.id), p = f.patient || f;
    openModal(`<div class="modal-head"><h2>Fiche du patient ${esc(p.ipp)}</h2>${closeBtn()}</div>${formPatient(p)}
      <p class="hint">Chaque modification est journalisée avec l’ancienne et la nouvelle valeur.</p>
      <div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Annuler</button><button class="btn" data-action="consFicheEnregistrer" data-id="${p.id}">Enregistrer</button></div>`, { large: true });
  },
  consFicheEnregistrer: async el => {
    const d = lireFormPatient();
    if (!verifierFormPatient(d)) return;
    const r = await agir(() => api('PUT', '/api/patients/' + el.dataset.id, d), 'Fiche du patient mise à jour (modification journalisée).');
    if (r) { closeModal(); await rechargerDossier(); render(); }
  }
});
