'use strict';
/* Poste Direction : pilotage du jour, validations, contrôles anti-fuite, exports. */
const EXPORTS = {
  'journal-caisse': 'Journal de caisse (reçus et paiements)', sorties: 'Sorties de caisse (SYSCOHADA)', 'tiers-payants': 'Tiers payants par assureur',
  stock: 'État du stock par lot (à date)', psychotropes: 'Registre des psychotropes', audit: 'Journal d’audit'
};
const LIBELLES_DEMANDE = { remboursement_avance: 'Remboursement d’avance', remise: 'Remise', annulation: 'Annulation de reçu', ecart: 'Écart de caisse', ajustement: 'Ajustement de stock' };

function demandeHTML(d) {
  const x = d.donnees;
  const quoi = d.type === 'remise' ? `${x.pct}&nbsp;% soit ${money(x.montant)}, ${esc(x.patient)}`
    : d.type === 'annulation' ? `Reçu ${esc(x.numero)} de ${money(x.net)}, ${esc(x.patient)}`
    : d.type === 'ecart' ? `${signed(x.ecart)} sur la caisse de ${esc(x.caissier)} (attendu ${money(x.theorique)}, compté ${money(x.compte)})`
    : d.type === 'remboursement_avance' ? `${money(x.montant)} à rendre à ${esc(x.patient)}`
    : `${esc(x.produit)}, lot ${esc(x.lot)} : ${x.quantite > 0 ? '+' : ''}${x.quantite} (${money(x.valeur)})`;
  const soi = d.demandeur_id === MOI.utilisateur.id;
  return `<div class="dem"><div><strong>${LIBELLES_DEMANDE[d.type] || d.type}</strong> <span class="muted">par ${esc(utilisateur(d.demandeur_id))}, ${fmtDateTime(d.cree_le)}</span>
    <div>${quoi}</div>${d.motif ? `<div class="muted">Motif : ${esc(d.motif)}</div>` : ''}</div>
    ${d.statut === 'en_attente'
      ? (peut('valider') ? (soi ? '<span class="badge b-warn">Votre demande : un autre membre de la direction décide</span>' : `<div class="row-actions"><button class="btn btn-sm btn-ghost" data-action="decider" data-id="${d.id}" data-ok="0">Refuser</button><button class="btn btn-sm" data-action="decider" data-id="${d.id}" data-ok="1">${d.type === 'ecart' ? 'Valider l’écart' : 'Valider'}</button></div>`) : '<span class="badge b-warn">En attente</span>')
      : `<span class="badge ${d.statut === 'validee' ? 'b-ok' : 'b-muted'}">${d.statut === 'validee' ? 'Validée' : 'Refusée'} par ${esc(utilisateur(d.decideur_id))}</span>`}</div>`;
}
function vDirection() {
  const k = E.indicateurs;
  if (!k) return vide('Pilotage indisponible', 'Votre profil ne donne pas accès aux indicateurs.');
  const attente = E.demandes.filter(d => d.statut === 'en_attente'), decidees = E.demandes.filter(d => d.statut !== 'en_attente');
  const controles = [
    ['Délivrances sans paiement (hors urgence)', k.delivrances_sans_paiement, k.delivrances_sans_paiement ? 'bad' : 'ok', k.delivrances_sans_paiement ? 'Anomalie à examiner' : 'Aucune : la règle d’or est respectée'],
    ['Tentatives bloquées (délivrance ou consultation)', k.tentatives_bloquees, k.tentatives_bloquees ? 'warn' : 'ok', `Patients renvoyés vers la caisse, dont ${k.consultations_bloquees} en consultation`],
    ['Bons du jour non encaissés', k.non_encaisses.n, k.non_encaisses.n ? 'warn' : 'ok', money(k.non_encaisses.montant) + ' en attente'],
    ['Urgences à régulariser', k.urgences.n, k.urgences.n ? 'bad' : 'ok', money(k.urgences.montant)],
    ['Avoirs émis aujourd’hui', k.avoirs, k.avoirs ? 'warn' : 'ok', 'Annulations validées'],
    ['Dossiers en identité provisoire', k.provisoires, k.provisoires ? 'warn' : 'ok', 'À compléter avant la sortie'],
    ['Doublons créés malgré l’alerte', k.doublons_forces, k.doublons_forces ? 'warn' : 'ok', 'À fusionner si nécessaire'],
    ['Seconds passages identiques', k.passages_doubles, k.passages_doubles ? 'warn' : 'ok', 'Ouverts malgré l’alerte de l’accueil'],
    ['Passages annulés', k.passages_annules, k.passages_annules ? 'warn' : 'ok', 'Motif consigné au journal'],
    ['Examens payés non réalisés (plus de 48 h)', k.examens_non_realises, k.examens_non_realises ? 'warn' : 'ok', k.examens_non_realises ? 'À vérifier avec le laboratoire' : 'Tous les examens payés sont réalisés'],
    ['Tarifs à valider', k.tarifs_a_valider, k.tarifs_a_valider ? 'bad' : 'ok', k.tarifs_a_valider ? 'Facturation bloquée sur ces tarifs' : 'Référentiel validé']
  ];
  const modes = Object.entries(k.modes).sort((a, b) => b[1] - a[1]), maxMode = Math.max(1, ...modes.map(m => m[1]));
  const ass = Object.entries(k.assureurs_mois).sort((a, b) => b[1].montant - a[1].montant);
  return `<div class="view-head"><div><h1>Direction</h1><p class="lead">La journée en un coup d’œil : recettes, validations et contrôles anti-fuite.</p></div></div>
    <div class="kpis">
      <div class="kpi"><span class="l">Passages du jour</span><span class="v">${k.passages}</span></div>
      <div class="kpi"><span class="l">Consultations validées</span><span class="v">${k.consultations}</span></div>
      <div class="kpi"><span class="l">Facturé</span><span class="v">${money(k.facture)}</span></div>
      <div class="kpi"><span class="l">Encaissé</span><span class="v">${money(k.encaisse)}</span></div>
      <div class="kpi"><span class="l">Part assureurs</span><span class="v">${money(k.part_assureurs)}</span></div>
      <div class="kpi"><span class="l">Remises accordées</span><span class="v">${money(k.remises)}</span></div>
      <div class="kpi${k.ecart ? ' is-bad' : ''}"><span class="l">Écarts de caisse</span><span class="v">${k.clotures ? (k.ecart ? signed(k.ecart) : 'Aucun') : 'Pas de clôture'}</span></div>
    </div>
    <div class="grid-2 wide-right">
      <section class="panel"><h2>Validations en attente <span class="muted">(${attente.length})</span></h2>${attente.length ? attente.map(demandeHTML).join('') : '<p class="muted">Aucune demande en attente.</p>'}
        ${decidees.length ? `<h3>Décidées aujourd’hui</h3>${decidees.map(demandeHTML).join('')}` : ''}</section>
      <section class="panel"><h2>Contrôles anti-fuite</h2><ul class="checks">${controles.map(([l, n, cls, s]) => `<li><div><strong>${l}</strong><div class="muted">${esc(s)}</div></div><span class="val${cls === 'bad' ? ' is-bad' : cls === 'warn' ? ' is-warn' : ''}">${n}</span></li>`).join('')}</ul></section>
      <section class="panel"><h2>Encaissements du jour par mode</h2>${modes.length ? `<div class="bars">${modes.map(([m, v]) => `<div class="bar-row"><span>${esc(m)}</span><div class="bar"><i style="width:${Math.max(3, Math.round(v / maxMode * 100))}%"></i></div><strong>${money(v)}</strong></div>`).join('')}</div>` : '<p class="muted">Aucun encaissement aujourd’hui.</p>'}</section>
      <section class="panel"><h2>Part assureurs du mois</h2>${ass.length ? `<div class="table-wrap"><table><thead><tr><th>Assureur</th><th class="num">Bons</th><th class="num">Montant</th></tr></thead><tbody>${ass.map(([n, x]) => `<tr><td>${esc(n)}</td><td class="num">${x.bons}</td><td class="num">${money(x.montant)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">Aucune part assureur encaissée ce mois-ci.</p>'}</section>
      <section class="panel"><h2>Caisses</h2>${E.sessions.length ? `<ul class="plist">${E.sessions.map(s => `<li><div><strong>${esc(utilisateur(s.caissier_id))}</strong><div class="muted">${esc(s.vacation)}, ouverte à ${fmtTime(s.ouverte_le)}</div></div>
        <div class="pl-side">${s.fermee_le ? `<span class="badge ${s.ecart ? 'b-bad' : 'b-ok'}">Clôturée, écart ${s.ecart ? signed(s.ecart) : 'nul'}</span>` : `<span class="badge b-due">Ouverte</span><div class="muted">${money(s.especes.theorique)} attendus</div>`}</div></li>`).join('')}</ul>` : '<p class="muted">Aucune caisse ouverte aujourd’hui.</p>'}</section>
      <section class="panel"><h2>Stock : alertes</h2>${alertesDirection(k.stock)}</section>
      ${peut('exports') ? `<section class="panel"><h2>Exports pour Excel</h2>
        ${champ('Document', `<select data-change="dirType">${Object.entries(EXPORTS).filter(([t]) => t !== 'audit' || peut('audit')).map(([t, l]) => `<option value="${t}"${UI.dir.type === t ? ' selected' : ''}>${l}</option>`).join('')}</select>`)}
        <div class="form-grid">${champ('Du', `<input type="date" value="${UI.dir.du}" data-change="dirDu">`)}${champ('Au', `<input type="date" value="${UI.dir.au}" data-change="dirAu">`)}</div>
        <a class="btn btn-block" href="/api/exports/${UI.dir.type}?du=${UI.dir.du}&amp;au=${UI.dir.au}" download>Télécharger le fichier CSV</a>
        <p class="hint">Fichier lisible par Excel (séparateur point-virgule). Chaque export est journalisé.</p></section>` : ''}
      <section class="panel"><h2>Vérifier un reçu</h2>${champ('N° du reçu', '<input id="vr-num" placeholder="R-2026-000123" autocomplete="off" data-enter="verifierRecu">')}
        <button class="btn btn-ghost btn-block" data-action="verifierRecu">Vérifier</button><div id="vr-res">${resultatVerification()}</div></section>
    </div>
    ${E.audit ? `<section class="panel mt"><h2>Journal d’audit, dernières opérations</h2><ul class="audit">${E.audit.map(a => `<li${a.niveau === 'alerte' || a.niveau === 'blocage' ? ' class="alerte"' : ''}><time>${horodatageCourt(a.t)}</time><span class="poste">${esc(a.poste)}</span><span>${esc(a.login)} : ${esc(a.action)}${a.detail ? ', ' + esc(a.detail) : ''}</span></li>`).join('')}</ul></section>` : ''}`;
}
function alertesDirection(s) {
  const l = [['Ruptures', s.ruptures, 'b-bad'], ['Sous le seuil', s.sous_seuil, 'b-warn'], ['Péremption à 30 jours', s.p30, 'b-bad'], ['Lots périmés bloqués', s.perimes, 'b-bad']].filter(x => x[1].length);
  if (!l.length) return '<p class="muted">Aucune alerte de stock.</p>';
  return l.map(([t, noms, cls]) => `<div class="kvline small"><span><span class="badge ${cls}">${t}</span></span><span>${esc(noms.join(', '))}</span></div>`).join('');
}
function resultatVerification() {
  const v = UI.dir.verif;
  if (!v) return '';
  if (!v.trouve) return '<div class="notice bad">Aucun reçu MSI ne porte ce numéro.</div>';
  return `<div class="notice ${v.authentique ? (v.annule ? 'warn' : 'ok') : 'bad'}"><strong>${esc(v.numero)}</strong> du ${fmtDate(jourDe(v.cree_le))} : ${money(v.net)}, code de contrôle ${esc(v.code_controle)}.
    ${v.annule ? ` Annulé par l’avoir ${esc(v.avoir)}.` : ''}${v.authentique ? '' : ' Code de contrôle incohérent : reçu à examiner.'}</div>`;
}
Object.assign(ACTIONS, {
  decider: el => agir(() => api('POST', `/api/demandes/${el.dataset.id}/decision`, { accepte: el.dataset.ok === '1' }), el.dataset.ok === '1' ? 'Demande validée.' : 'Demande refusée.'),
  verifierRecu: async () => {
    try { UI.dir.verif = await api('GET', '/api/verification-recu?numero=' + encodeURIComponent($('#vr-num').value.trim())); $('#vr-res').innerHTML = resultatVerification(); }
    catch (e) { toast(e.message, 'bad'); }
  }
});
Object.assign(CHANGES, {
  dirType: el => { UI.dir.type = el.value; render(); },
  dirDu: el => { UI.dir.du = el.value; render(); },
  dirAu: el => { UI.dir.au = el.value; render(); }
});
ONGLETS.push({ id: 'direction', libelle: 'Direction', icone: 'direction', visible: () => peut('pilotage') || peut('valider'), compteur: () => (peut('valider') ? E.demandes.filter(d => d.statut === 'en_attente' && d.demandeur_id !== MOI.utilisateur.id).length : 0), vue: vDirection });
