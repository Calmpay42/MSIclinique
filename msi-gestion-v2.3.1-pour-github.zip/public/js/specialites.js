/* MSI Gestion : référentiel des spécialités médicales, partagé par le serveur et les écrans.
   Modèle : l'ophtalmologie reprend intégralement le contenu clinique d'OphtaSuite ; chaque autre spécialité suit la même
   structure avec son propre contenu. Tout texte proposé est une suggestion : le médecin le modifie librement. */
(function (racine) {
  'use strict';
  const OPHTA = {
   "motifs": [
    "Baisse d'acuité visuelle progressive",
    "Baisse d'acuité visuelle brutale",
    "Douleur oculaire",
    "Rougeur oculaire",
    "Larmoiement",
    "Sensation de corps étranger",
    "Prurit oculaire (démangeaisons)",
    "Sécrétions oculaires",
    "Photophobie",
    "Vision double (diplopie)",
    "Mouches volantes / corps flottants",
    "Contrôle de routine"
   ],
   "atcd_familiaux": [
    "Aucun antécédent familial notable",
    "Glaucome dans la famille",
    "Diabète dans la famille",
    "Cataracte dans la famille",
    "DMLA dans la famille",
    "Forte myopie dans la famille"
   ],
   "atcd_pathologiques": [
    "Aucun antécédent pathologique notable",
    "Diabète",
    "Hypertension artérielle",
    "Cardiopathie",
    "Insuffisance rénale",
    "Asthme",
    "Dyslipidémie"
   ],
   "atcd_medicaux": [
    "Aucun traitement en cours",
    "Sous traitement antihypertenseur",
    "Sous traitement antidiabétique",
    "Allergie médicamenteuse connue",
    "Sous corticothérapie au long cours",
    "Sous anticoagulant/antiagrégant"
   ],
   "atcd_chirurgicaux": [
    "Aucune chirurgie oculaire antérieure",
    "Chirurgie de la cataracte",
    "Chirurgie du glaucome",
    "Chirurgie réfractive (LASIK/PKR)",
    "Chirurgie de la rétine",
    "Autre chirurgie générale"
   ],
   "atcd_traumatismes": [
    "Aucun traumatisme oculaire antérieur",
    "Traumatisme oculaire ancien",
    "Corps étranger oculaire ancien",
    "Traumatisme crânien avec atteinte visuelle"
   ],
   "segment": {
    "Conjonctive": [
     "Conjonctive normale",
     "Hyperhémie conjonctivale",
     "Chémosis",
     "Sécrétions conjonctivales",
     "Follicules conjonctivaux",
     "Papilles conjonctivales",
     "Hémorragie sous-conjonctivale"
    ],
    "Cornée": [
     "Cornée transparente",
     "Œdème cornéen",
     "Kératite ponctuée superficielle",
     "Ulcère cornéen",
     "Opacité cornéenne",
     "Arc sénile",
     "Néovascularisation cornéenne",
     "Corps étranger cornéen",
     "Cicatrice cornéenne"
    ],
    "Chambre antérieure": [
     "Chambre antérieure profonde et calme",
     "Tyndall (inflammation)",
     "Hyphéma",
     "Hypopion",
     "Chambre antérieure étroite"
    ],
    "Iris": [
     "Iris normal",
     "Synéchies irido-cristalliniennes",
     "Atrophie irienne",
     "Rubéose irienne"
    ],
    "Pupille": [
     "Pupille normale, réactive",
     "Myosis",
     "Mydriase",
     "Anisocorie",
     "Réflexe photomoteur aboli"
    ],
    "Cristallin": [
     "Cristallin transparent",
     "Cataracte nucléaire",
     "Cataracte corticale",
     "Cataracte sous-capsulaire postérieure",
     "Pseudophakie (implant en place)",
     "Aphakie",
     "Subluxation du cristallin"
    ]
   },
   "fond": {
    "Papille": [
     "Papille bien limitée, à bords nets",
     "Excavation papillaire augmentée (C/D élevé)",
     "Pâleur papillaire",
     "Œdème papillaire",
     "Hémorragie péripapillaire"
    ],
    "Macula": [
     "Macula normale",
     "Drusen maculaires",
     "Œdème maculaire",
     "Membrane épirétinienne",
     "Trou maculaire",
     "Signes de DMLA"
    ],
    "Vaisseaux rétiniens": [
     "Calibre vasculaire normal",
     "Rétrécissement artériel",
     "Signe du croisement artério-veineux (Salus/Gunn)",
     "Tortuosité vasculaire",
     "Néovascularisation rétinienne"
    ],
    "Rétine périphérique": [
     "Rétine périphérique à plat, sans lésion",
     "Dégénérescence périphérique",
     "Déchirure rétinienne",
     "Décollement de rétine",
     "Hémorragies rétiniennes",
     "Exsudats (durs/cotonneux)",
     "Microanévrysmes"
    ]
   },
   "diagnostics": [
    "Œil normal, pas de pathologie décelée",
    "Glaucome primitif à angle ouvert",
    "Suspicion de glaucome",
    "Cataracte",
    "Rétinopathie diabétique",
    "DMLA (dégénérescence maculaire liée à l'âge)",
    "Conjonctivite",
    "Kératite",
    "Sécheresse oculaire",
    "Trouble de la réfraction (myopie/hypermétropie/astigmatisme)",
    "Uvéite"
   ],
   "conduites": [
    "Traitement médical prescrit, contrôle dans 1 mois",
    "Surveillance simple, contrôle dans 6 mois",
    "Surveillance simple, contrôle dans 1 an",
    "Bilan complémentaire demandé (champ visuel, OCT)",
    "Orientation vers une autre spécialité",
    "Indication chirurgicale à discuter",
    "Correction optique prescrite",
    "Prescription de lunettes"
   ],
   "rdv_motifs": [
    "Consultation initiale",
    "Contrôle de routine",
    "Contrôle post-opératoire",
    "Suivi glaucome",
    "Suivi rétinopathie diabétique",
    "Renouvellement d'ordonnance",
    "Résultats d'examens",
    "Contrôle de la tension oculaire",
    "Contrôle réfraction / lunettes",
    "Urgence oculaire"
   ],
   "examens": [
    {
     "l": "Angiographie Fluoresceinique"
    },
    {
     "l": "Champ Visuel Automatisé",
     "code": "OPH-CV",
     "prix": 30000
    },
    {
     "l": "Topographie Cornéenne"
    },
    {
     "l": "Réfraction Automatique",
     "code": "OPH-REF",
     "prix": 20000
    },
    {
     "l": "OCT FNR et CCG",
     "code": "OPH-OCTN",
     "prix": 80000
    },
    {
     "l": "OCT maculaire",
     "code": "OPH-OCTM",
     "prix": 80000
    },
    {
     "l": "OCT Angiographie",
     "code": "OPH-OCTA",
     "prix": 80000
    },
    {
     "l": "OCT du Segment antérieur",
     "code": "OPH-OCTSA",
     "prix": 80000
    },
    {
     "l": "Retinophotographie",
     "code": "OPH-RETI",
     "prix": 80000
    },
    {
     "l": "Pachymetrie",
     "code": "OPH-PACHY",
     "prix": 20000
    },
    {
     "l": "Fond d'œil",
     "code": "OPH-FO",
     "prix": 30000
    },
    {
     "l": "Fond d'œil au V3M",
     "code": "OPH-FOV3",
     "prix": 30000
    },
    {
     "l": "PIO",
     "code": "OPH-PIO",
     "prix": 20000
    },
    {
     "l": "Échographie Oculaire mode A"
    },
    {
     "l": "Échographie Oculaire mode B"
    }
   ],
   "interpretations": {
    "champ_visuel": {
     "cv_programme": "24-2",
     "cv_strategie": "Fasthreshold",
     "cv_od": "Indice de fiabilité : bon\nVision centrale conservée\nSensibilité périphérique conservée\nMD : normal\nPas de scotome",
     "cv_og": "Indice de fiabilité : bon\nVision centrale conservée\nSensibilité périphérique conservée\nMD : normal\nPas de scotome",
     "cv_conclusion": "Champ visuel automatisé normal ODG ce jour",
     "cv_cat": "Adapter à la clinique"
    },
    "oct_fnr_ccg": {
     "oct_od": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : aspect normal en aile de papillon\nÉpaisseur moyenne des RNFL : normale\nDéroulé TSNIT des RNFL : pas de déficit",
     "oct_og": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : aspect normal en aile de papillon\nÉpaisseur moyenne des RNFL : normale\nDéroulé TSNIT des RNFL : pas de déficit",
     "oct_ggl": "Épaisseur moyenne des cellules ganglionnaires maculaires\nOD : normale\nOG : normale",
     "oct_conclusion": "OCT des FNR et du GCC non en faveur d'une neuropathie optique glaucomateuse.\nContrôle dans 06 mois"
    },
    "oct_maculaire": {
     "ocm_od": "Puissance de signal : bonne\nPas de diminution globale des couches rétiniennes maculaires\nÉpaisseur maculaire centrale normale",
     "ocm_og": "Puissance de signal : bonne\nPas de diminution globale des couches rétiniennes maculaires\nÉpaisseur maculaire centrale normale",
     "ocm_conclusion": "OCT maculaire sans particularité"
    },
    "fond_oeil": {
     "fo_lampeod": "Segment antérieur normal",
     "fo_lampeog": "Segment antérieur normal",
     "fo_fondod": "Pôle postérieur : papille sans particularité, macula sans particularité\nLe reste du champ choriorétinien est sans particularité",
     "fo_fondog": "Pôle postérieur : papille sans particularité, macula sans particularité\nLe reste du champ choriorétinien est sans particularité",
     "fo_autotal": "Examen du fond d'œil normal ce jour",
     "fo_conclusion": "Examen ophtalmologique normal ce jour, aucune anomalie décelée à ce jour."
    }
   },
   "glaucome": {
    "champ_visuel": {
     "normal": {
      "cv_od": "Indice de fiabilité : bon\nVision centrale conservée\nSensibilité périphérique conservée\nMD : normal\nPas de scotome",
      "cv_og": "Indice de fiabilité : bon\nVision centrale conservée\nSensibilité périphérique conservée\nMD : normal\nPas de scotome",
      "cv_conclusion": "Champ visuel automatisé normal ODG ce jour",
      "cv_cat": "Adapter à la clinique"
     },
     "glaucomateux": {
      "cv_od": "Indice de fiabilité : bon\nDéficit fasciculaire supéro-nasal\nMD : abaissé, altération significative\nPSD augmenté\nScotome relatif proche du point de fixation",
      "cv_og": "Indice de fiabilité : bon\nDéficit fasciculaire supéro-nasal\nMD : abaissé, altération significative\nPSD augmenté\nScotome relatif proche du point de fixation",
      "cv_conclusion": "Champ visuel évocateur d'une neuropathie optique glaucomateuse, déficit fasciculaire bilatéral",
      "cv_cat": "Bilan glaucome complet recommandé (OCT FNR/CCG, pachymétrie, gonioscopie), avis spécialisé et contrôle rapproché"
     }
    },
    "oct_fnr_ccg": {
     "normal": {
      "oct_od": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : aspect normal en aile de papillon\nÉpaisseur moyenne des RNFL : normale\nDéroulé TSNIT des RNFL : pas de déficit",
      "oct_og": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : aspect normal en aile de papillon\nÉpaisseur moyenne des RNFL : normale\nDéroulé TSNIT des RNFL : pas de déficit",
      "oct_ggl": "Épaisseur moyenne des cellules ganglionnaires maculaires\nOD : normale\nOG : normale",
      "oct_conclusion": "OCT des FNR et du GCC non en faveur d'une neuropathie optique glaucomateuse.\nContrôle dans 06 mois"
     },
     "glaucomateux": {
      "oct_od": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : amincissement localisé en secteur supéro-temporal\nÉpaisseur moyenne des RNFL : diminuée\nDéroulé TSNIT des RNFL : déficit focal",
      "oct_og": "Puissance de signal : bonne\nCarte des épaisseurs RNFL : amincissement localisé en secteur supéro-temporal\nÉpaisseur moyenne des RNFL : diminuée\nDéroulé TSNIT des RNFL : déficit focal",
      "oct_ggl": "Épaisseur moyenne des cellules ganglionnaires maculaires\nOD : diminuée\nOG : diminuée",
      "oct_conclusion": "OCT des FNR et du GCC en faveur d'une neuropathie optique glaucomateuse.\nBilan glaucome complet et avis spécialisé recommandés.\nContrôle rapproché dans 03 mois"
     }
    }
   },
   "chirurgie": {
    "Cataracte": {
     "indication": "Cataracte avec retentissement fonctionnel sur l'acuité visuelle, confirmée par l'examen clinique préopératoire (acuité visuelle, examen à la lampe à fente, biométrie).",
     "technique": "Phacoémulsification par voie cornéenne, sous anesthésie topique, avec implantation d'un implant intraoculaire de chambre postérieure dans le sac capsulaire.",
     "deroulement": "Intervention réalisée sans complication per-opératoire. Capsulorhexis continu circulaire, phacoémulsification du noyau, aspiration des masses corticales, implantation dans le sac capsulaire. Chambre antérieure reformée en fin d'intervention. Étanchéité cornéenne satisfaisante sans nécessité de suture.",
     "suites": "Suites opératoires immédiates simples. Œil calme, cornée transparente, chambre antérieure formée en fin d'intervention.",
     "prescription": "Collyre antibiotique et anti-inflammatoire associés, en décroissance sur 3 à 4 semaines selon protocole habituel. Protection oculaire (coque) la nuit pendant la première semaine.",
     "consignes": "Contrôle à J1, J8, puis à 1 mois. Éviter l'effort physique intense, la poussière et l'eau non stérile dans l'œil pendant les 3 premières semaines. Consulter en urgence en cas de douleur, de baisse brutale de la vision, ou de rougeur importante."
    },
    "Ptérygion": {
     "indication": "Ptérygion évolutif avec gêne fonctionnelle (irritation chronique, rougeur récidivante) et/ou empiètement progressif sur l'axe visuel, confirmé par l'examen préopératoire.",
     "technique": "Exérèse du ptérygion avec autogreffe conjonctivale libre, fixée par colle biologique (ou points de suture résorbables selon disponibilité), sous anesthésie locale.",
     "deroulement": "Intervention réalisée sans complication per-opératoire. Dissection et exérèse complète du tissu ptérygial, hémostase soigneuse, prélèvement et positionnement du greffon conjonctival autologue en bonne position.",
     "suites": "Suites opératoires immédiates simples. Œil calme en fin d'intervention, greffon bien affronté.",
     "prescription": "Collyre antibiotique et corticoïde associés, en décroissance progressive sur 3 à 4 semaines selon protocole habituel. Larmes artificielles en complément.",
     "consignes": "Contrôle à J1, J8, puis à 1 mois. Port de lunettes de soleil recommandé en extérieur. Consulter en urgence en cas de douleur importante, d'écoulement anormal, ou de désunion du greffon."
    }
   },
   "certificats": {
    "Certificat de bonne santé": [
     {
      "label": "Examen normal, sans réserve",
      "constat": "L'examen clinique ophtalmologique réalisé ce jour (acuité visuelle, segment antérieur à la lampe à fente, tension oculaire, fond d'œil) ne révèle aucune anomalie apparente.",
      "conclusion": "Le/la patient(e) ne présente, à la date de ce jour et sur le plan ophtalmologique, aucun signe clinique apparent de nature à altérer son état de santé.",
      "validiteMonths": 12
     },
     {
      "label": "Avec port de correction optique",
      "constat": "L'examen clinique ophtalmologique réalisé ce jour ne révèle aucune anomalie apparente. Le/la patient(e) porte une correction optique (lunettes ou lentilles), avec laquelle l'acuité visuelle est satisfaisante.",
      "conclusion": "Le/la patient(e) ne présente, à la date de ce jour et sur le plan ophtalmologique, aucun signe clinique apparent de nature à altérer son état de santé, sous réserve du port de sa correction optique habituelle.",
      "validiteMonths": 12
     }
    ],
    "Aptitude sportive": [
     {
      "label": "Aptitude sans réserve",
      "constat": "L'examen ophtalmologique complet réalisé ce jour (acuité visuelle, segment antérieur à la lampe à fente, tension oculaire, fond d'œil) ne révèle aucune anomalie oculaire apparente.",
      "conclusion": "Sur le plan ophtalmologique et à la date de ce jour, aucune contre-indication n'est retenue à la pratique de l'activité sportive.",
      "validiteMonths": 12
     },
     {
      "label": "Aptitude avec port obligatoire de la correction optique",
      "constat": "L'examen ophtalmologique complet réalisé ce jour ne révèle aucune anomalie oculaire apparente. L'acuité visuelle n'est satisfaisante qu'avec le port de la correction optique habituelle.",
      "conclusion": "Sur le plan ophtalmologique et à la date de ce jour, aucune contre-indication n'est retenue à la pratique de l'activité sportive, sous réserve du port systématique de la correction optique (lunettes adaptées ou lentilles) pendant l'activité.",
      "validiteMonths": 12
     },
     {
      "label": "Aptitude avec réserve médicale",
      "constat": "L'examen ophtalmologique complet réalisé ce jour retrouve un élément clinique nécessitant une surveillance particulière, précisé ci-dessous.",
      "conclusion": "Sur le plan ophtalmologique et à la date de ce jour, l'aptitude à la pratique sportive est accordée sous réserve des précautions suivantes : [à préciser par le médecin]. Un contrôle de suivi est recommandé.",
      "validiteMonths": 6
     }
    ],
    "Aptitude scolaire": [
     {
      "label": "Aptitude normale",
      "constat": "L'examen ophtalmologique réalisé ce jour ne révèle aucune anomalie visuelle apparente susceptible de gêner la scolarité.",
      "conclusion": "Sur le plan ophtalmologique et à la date de ce jour, aucune contre-indication n'est retenue à la scolarité normale.",
      "validiteMonths": 12
     },
     {
      "label": "Avec recommandation d'aménagement (placement en classe, etc.)",
      "constat": "L'examen ophtalmologique réalisé ce jour retrouve une acuité visuelle diminuée par rapport à la normale, sans contre-indication à la scolarité.",
      "conclusion": "Sur le plan ophtalmologique, aucune contre-indication n'est retenue à la scolarité normale. Il est toutefois recommandé un placement préférentiel de l'élève au premier rang, ainsi qu'un affichage en gros caractères si possible.",
      "validiteMonths": 12
     }
    ],
    "Certificat de non contre-indication": [
     {
      "label": "Sans réserve",
      "constat": "L'examen clinique ophtalmologique réalisé ce jour ne révèle, à la date de cet examen, aucune anomalie apparente contre-indiquant l'activité concernée.",
      "conclusion": "Aucune contre-indication médicale n'est retenue, sur le plan ophtalmologique, à la date de ce jour.",
      "validiteMonths": 12
     },
     {
      "label": "Avec réserve ou recommandation",
      "constat": "L'examen clinique ophtalmologique réalisé ce jour ne révèle pas de contre-indication formelle, mais retrouve un élément à surveiller, précisé ci-dessous.",
      "conclusion": "Aucune contre-indication médicale formelle n'est retenue, sur le plan ophtalmologique, à la date de ce jour, sous réserve de : [à préciser par le médecin].",
      "validiteMonths": 6
     }
    ],
    "Certificat de visite médicale": [
     {
      "label": "Rien à signaler",
      "constat": "Le/la patient(e) s'est présenté(e) ce jour pour une visite médicale ophtalmologique. L'examen clinique a été réalisé dans son intégralité.",
      "conclusion": "La visite médicale ophtalmologique de ce jour ne révèle aucune anomalie nécessitant une prise en charge immédiate.",
      "validiteMonths": null
     },
     {
      "label": "Avec orientation complémentaire",
      "constat": "Le/la patient(e) s'est présenté(e) ce jour pour une visite médicale ophtalmologique. L'examen clinique a été réalisé dans son intégralité et retrouve un élément nécessitant un avis complémentaire.",
      "conclusion": "La visite médicale ophtalmologique de ce jour justifie une orientation complémentaire, précisée ci-dessous, sans caractère d'urgence.",
      "validiteMonths": null
     }
    ]
   },
   "orientation": {
    "Cardiologie": [
     "HTA découverte en consultation d'ophtalmologie, à explorer.",
     "Rétinopathie hypertensive constatée au fond d'œil.",
     "Souffle cardiaque rapporté par le patient."
    ],
    "Diabétologie": [
     "Rétinopathie diabétique constatée au fond d'œil.",
     "Glycémie élevée découverte en consultation d'ophtalmologie.",
     "Suivi ophtalmologique d'un diabète connu."
    ],
    "Néphrologie": [
     "Œdème périorbitaire d'origine indéterminée.",
     "Suivi ophtalmologique dans le cadre d'une insuffisance rénale connue."
    ],
    "Rhumatologie": [
     "Suspicion d'atteinte oculaire inflammatoire (uvéite) à corréler à une pathologie rhumatismale.",
     "Sécheresse oculaire évocatrice d'un syndrome de Gougerot-Sjögren."
    ],
    "Dermatologie": [
     "Lésion palpébrale ou périoculaire à explorer.",
     "Chalazion ou orgelet récidivant."
    ],
    "Infectiologie": [
     "Suspicion d'infection oculaire d'origine systémique.",
     "Conjonctivite ne répondant pas au traitement local."
    ],
    "Pédiatrie médicale": [
     "Trouble visuel de l'enfant nécessitant un avis pédiatrique.",
     "Strabisme ou amblyopie à corréler à un bilan pédiatrique."
    ],
    "Chirurgie pédiatrique": [
     "Anomalie orbito-palpébrale congénitale à évaluer.",
     "Obstruction des voies lacrymales de l'enfant."
    ],
    "Gynécologie-obstétrique": [
     "Trouble visuel chez la femme enceinte, à corréler à une possible pré-éclampsie.",
     "Suivi ophtalmologique dans le cadre d'une grossesse à risque."
    ],
    "Médecine générale": [
     "Bilan général demandé en complément du suivi ophtalmologique."
    ],
    "Autre": []
   },
   "exploration_infos": [
    "Contrôle glaucome (tension oculaire, champ visuel)",
    "Suivi rétinopathie diabétique",
    "Baisse d'acuité visuelle inexpliquée",
    "Bilan pré-opératoire de cataracte",
    "Suivi DMLA (dégénérescence maculaire liée à l'âge)",
    "Contrôle post-opératoire",
    "Suspicion de neuropathie optique",
    "Traumatisme oculaire"
   ],
   "medicaments": [
    [
     "Correctol",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Maxmoist",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Lubrifiant oculaire (sécheresse oculaire)"
    ],
    [
     "Dinopat",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Diffrarel E",
     "Comprimés",
     "1 comprimé/jour",
     "Complément vitaminé (vitamine E) — à confirmer selon la fiche produit"
    ],
    [
     "Metagard",
     "Comprimés",
     "1 comprimé 2 fois/jour",
     ""
    ],
    [
     "Cougard",
     "Gélules",
     "1 gélule/jour",
     ""
    ],
    [
     "Sofdropt",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Co-avazir",
     "Collyre et pommade",
     "Collyre : 1 goutte 5 fois/jour · Pommade : application le soir",
     "Antiviral (probable) — herpès oculaire, à confirmer avant prescription"
    ],
    [
     "Cotipred",
     "Comprimé",
     "Selon prescription",
     "Anti-inflammatoire corticoïde (probable) — à confirmer"
    ],
    [
     "Levophta",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique (probable, famille fluoroquinolone) — infection oculaire, à confirmer"
    ],
    [
     "Tobrex",
     "Collyre",
     "1 goutte 4 à 6 fois/jour",
     "Antibiotique (tobramycine) — infection bactérienne oculaire"
    ],
    [
     "Catacol",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Akaryd",
     "Comprimés",
     "1 comprimé/jour",
     ""
    ],
    [
     "Cornetus",
     "Collyre",
     "1 goutte 3 fois/jour",
     "Cicatrisant cornéen (probable) — à confirmer"
    ],
    [
     "Diffustero",
     "Collyre",
     "1 goutte 3 fois/jour",
     "Corticoïde (probable) — à confirmer"
    ],
    [
     "Fresh Eye",
     "Collyre",
     "1 goutte autant que nécessaire",
     "Lubrifiant oculaire (sécheresse oculaire)"
    ],
    [
     "Primalan",
     "Comprimés et sirop",
     "Comprimé : 1/jour · Sirop : selon poids/âge",
     "Antihistaminique — allergie oculaire"
    ],
    [
     "Lubrinex",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Lubrifiant oculaire (sécheresse oculaire)"
    ],
    [
     "ODM5",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Diamox",
     "Comprimés",
     "Selon prescription (souvent 1 comp. 2 à 4 fois/jour)",
     "Anti-glaucomateux (acétazolamide) — hypertonie oculaire / glaucome"
    ],
    [
     "Diffu-K",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation potassique — souvent associée au Diamox"
    ],
    [
     "Indo",
     "Collyre",
     "1 goutte 3 fois/jour",
     "Anti-inflammatoire non stéroïdien (indométacine)"
    ],
    [
     "Ozolamid",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (probable, inhibiteur de l'anhydrase carbonique) — à confirmer"
    ],
    [
     "Xanternet",
     "Collyre",
     "1 goutte 3 fois/jour",
     ""
    ],
    [
     "Netildex",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique + corticoïde (nétilmicine/dexaméthasone) — infection avec inflammation"
    ],
    [
     "Monoprost",
     "Collyre",
     "1 goutte le soir",
     "Anti-glaucomateux (latanoprost, prostaglandine)"
    ],
    [
     "Cateol LP2%",
     "Collyre ou unidose",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (probable, bêta-bloquant) — à confirmer"
    ],
    [
     "Mydriaticum",
     "Collyre",
     "1 goutte 3 fois/jour",
     "Mydriatique — dilatation pupillaire pour examen du fond d'œil"
    ],
    [
     "Tuvers",
     "Comprimés",
     "1 comprimé à J1, J2 et J3, puis 3 comprimés le matin à jeun",
     "Antiparasitaire (probable) — à confirmer"
    ],
    [
     "Bactrim Forte",
     "Comprimés",
     "1 comprimé matin et soir",
     "Antibiotique (cotrimoxazole) — infection bactérienne"
    ],
    [
     "Ciloxan",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique (ciprofloxacine) — infection bactérienne oculaire"
    ],
    [
     "Exocine",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique (ofloxacine) — infection bactérienne oculaire"
    ],
    [
     "Azyter",
     "Collyre unidose",
     "1 goutte 2 fois/jour pendant 3 jours",
     "Antibiotique (azithromycine) — conjonctivite bactérienne"
    ],
    [
     "Rifamycine collyre",
     "Collyre",
     "1 à 2 gouttes, 4 fois/jour",
     "Antibiotique (rifamycine) — infection bactérienne oculaire"
    ],
    [
     "Vitabact",
     "Collyre",
     "1 goutte 2 à 4 fois/jour",
     "Antiseptique local — prévention et traitement d'appoint des infections oculaires"
    ],
    [
     "Maxidex",
     "Collyre",
     "1 à 2 gouttes, 4 à 6 fois/jour",
     "Corticoïde (dexaméthasone) — inflammation oculaire"
    ],
    [
     "Pred Forte",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Corticoïde (prednisolone) — inflammation oculaire"
    ],
    [
     "Flucon",
     "Collyre",
     "1 goutte 2 à 4 fois/jour",
     "Corticoïde faible (fluorométholone) — inflammation oculaire légère"
    ],
    [
     "Tobradex",
     "Collyre ou pommade",
     "1 goutte 4 fois/jour",
     "Antibiotique + corticoïde (tobramycine/dexaméthasone) — infection avec inflammation"
    ],
    [
     "Maxitrol",
     "Collyre ou pommade",
     "1 goutte 4 fois/jour",
     "Antibiotique + corticoïde (néomycine/polymyxine B/dexaméthasone)"
    ],
    [
     "Nevanac",
     "Collyre",
     "1 goutte/jour",
     "Anti-inflammatoire non stéroïdien (népafénac) — inflammation post-opératoire"
    ],
    [
     "Acular",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Anti-inflammatoire non stéroïdien (kétorolac)"
    ],
    [
     "Timoptol",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (timolol, bêta-bloquant)"
    ],
    [
     "Xalatan",
     "Collyre",
     "1 goutte le soir",
     "Anti-glaucomateux (latanoprost, prostaglandine)"
    ],
    [
     "Travatan",
     "Collyre",
     "1 goutte le soir",
     "Anti-glaucomateux (travoprost, prostaglandine)"
    ],
    [
     "Azopt",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (brinzolamide, inhibiteur de l'anhydrase carbonique)"
    ],
    [
     "Trusopt",
     "Collyre",
     "1 goutte 2 à 3 fois/jour",
     "Anti-glaucomateux (dorzolamide, inhibiteur de l'anhydrase carbonique)"
    ],
    [
     "Alphagan",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (brimonidine, agoniste alpha-2)"
    ],
    [
     "Cosopt",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (timolol + dorzolamide, association)"
    ],
    [
     "Ganfort",
     "Collyre",
     "1 goutte le matin",
     "Anti-glaucomateux (bimatoprost + timolol, association)"
    ],
    [
     "Atropine collyre",
     "Collyre",
     "1 goutte 1 à 2 fois/jour selon prescription",
     "Cycloplégique / mydriatique puissant et prolongé"
    ],
    [
     "Néosynéphrine collyre",
     "Collyre",
     "1 goutte avant l'examen",
     "Mydriatique (phényléphrine) — dilatation pupillaire"
    ],
    [
     "Skiacol",
     "Collyre",
     "1 goutte avant l'examen",
     "Cycloplégique (cyclopentolate) — dilatation pupillaire, réfraction sous cycloplégie"
    ],
    [
     "Opatanol",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Antihistaminique (olopatadine) — allergie oculaire"
    ],
    [
     "Zaditen collyre",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Antihistaminique (kétotifène) — allergie oculaire"
    ],
    [
     "Cromabak",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Anti-allergique (cromoglycate de sodium, stabilisateur des mastocytes)"
    ],
    [
     "Zovirax collyre",
     "Collyre ou pommade",
     "Application 5 fois/jour",
     "Antiviral (aciclovir) — herpès oculaire"
    ],
    [
     "Virgan",
     "Gel ophtalmique",
     "1 application 5 fois/jour puis 3 fois/jour après cicatrisation",
     "Antiviral (ganciclovir) — kératite herpétique"
    ],
    [
     "Novésine",
     "Collyre",
     "1 goutte avant l'examen (usage diagnostique uniquement)",
     "Anesthésique local (oxybuprocaïne) — geste ou examen douloureux"
    ],
    [
     "Larmes artificielles",
     "Collyre",
     "1 goutte autant que nécessaire",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "Hylo-Comod",
     "Collyre",
     "1 goutte 3 à 5 fois/jour",
     "Lubrifiant oculaire (acide hyaluronique) — sécheresse oculaire"
    ],
    [
     "Systane",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "Vismed",
     "Collyre",
     "1 goutte 3 à 5 fois/jour",
     "Lubrifiant oculaire (acide hyaluronique) — sécheresse oculaire"
    ],
    [
     "Chloramphénicol collyre",
     "Collyre",
     "1 goutte 4 à 6 fois/jour",
     "Antibiotique à large spectre — infection bactérienne oculaire"
    ],
    [
     "Cebemyxine",
     "Collyre ou pommade",
     "1 goutte ou application 2 à 3 fois/jour",
     "Antibiotique + corticoïde (néomycine/polymyxine B/dexaméthasone)"
    ],
    [
     "Tétracycline pommade ophtalmique",
     "Pommade",
     "Application 2 fois/jour",
     "Antibiotique — prévention et traitement du trachome, conjonctivite néonatale"
    ],
    [
     "Rohto",
     "Collyre",
     "1 à 2 gouttes selon besoin",
     "Décongestionnant — confort oculaire, yeux fatigués ou irrités"
    ],
    [
     "Optrex",
     "Collyre",
     "1 à 2 gouttes selon besoin",
     "Décongestionnant — confort oculaire, yeux fatigués ou irrités"
    ],
    [
     "Visine",
     "Collyre",
     "1 à 2 gouttes selon besoin",
     "Décongestionnant vasoconstricteur — yeux rouges"
    ],
    [
     "Fluorescéine collyre",
     "Collyre",
     "1 goutte au moment de l'examen",
     "Colorant diagnostique — exploration de la cornée, test lacrymal"
    ],
    [
     "Vitamine A",
     "Gélules",
     "Selon prescription",
     "Supplémentation — carence en vitamine A, sécheresse oculaire, héméralopie"
    ],
    [
     "Zinc",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation en zinc — soutien de la fonction rétinienne, cicatrisation"
    ],
    [
     "Doxycycline",
     "Comprimés",
     "1 comprimé/jour",
     "Antibiotique — blépharite chronique, meibomite, rosacée oculaire"
    ],
    [
     "Cortancyl",
     "Comprimés",
     "Selon prescription (schéma dégressif)",
     "Corticothérapie orale (prednisone) — inflammation oculaire sévère, uvéite"
    ],
    [
     "Solupred",
     "Comprimés",
     "Selon prescription (schéma dégressif)",
     "Corticoïde oral (prednisolone) — inflammation oculaire sévère"
    ],
    [
     "Neurobion",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation vitamines B — neuropathie optique"
    ],
    [
     "Tanakan",
     "Comprimés",
     "1 comprimé 2 à 3 fois/jour",
     "Vasodilatateur (Ginkgo biloba) — troubles de la microcirculation oculaire"
    ],
    [
     "Zovirax comprimés",
     "Comprimés",
     "Selon prescription",
     "Antiviral oral (aciclovir) — zona ophtalmique, herpès oculaire sévère"
    ],
    [
     "Zithromax",
     "Comprimés",
     "Dose unique selon prescription",
     "Antibiotique (azithromycine) — traitement du trachome"
    ],
    [
     "Clamoxyl",
     "Comprimés",
     "1 comprimé 3 fois/jour",
     "Antibiotique (amoxicilline) — infection bactérienne"
    ],
    [
     "Paracétamol",
     "Comprimés",
     "1 comprimé toutes les 6 heures si besoin",
     "Antalgique / antipyrétique"
    ],
    [
     "Ibuprofène",
     "Comprimés",
     "1 comprimé 3 fois/jour",
     "Anti-inflammatoire non stéroïdien — douleur, inflammation"
    ],
    [
     "Amoxicilline",
     "Gélules",
     "1 gélule 3 fois/jour",
     "Antibiotique (famille pénicilline) — infection bactérienne"
    ],
    [
     "Fucithalmic",
     "Collyre gel",
     "1 application 2 fois/jour",
     "Antibiotique (acide fusidique) — infection à staphylocoque"
    ],
    [
     "Voltarène Ophtabak",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Anti-inflammatoire non stéroïdien (diclofénac)"
    ],
    [
     "Corneregel",
     "Gel ophtalmique",
     "1 application plusieurs fois/jour",
     "Cicatrisant cornéen (dexpanthénol)"
    ],
    [
     "Ikervis",
     "Collyre",
     "1 goutte le soir",
     "Immunosuppresseur (ciclosporine) — sécheresse oculaire sévère"
    ],
    [
     "Aciclovir pommade ophtalmique",
     "Pommade",
     "Application 5 fois/jour",
     "Antiviral — herpès oculaire"
    ],
    [
     "Vitamine B12",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation — neuropathie"
    ],
    [
     "Tardyferon",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation en fer — anémie"
    ],
    [
     "Célestène",
     "Comprimés",
     "Selon prescription",
     "Corticoïde systémique (bétaméthasone) — allergie sévère, inflammation"
    ],
    [
     "Prednisolone",
     "Comprimés",
     "Selon prescription (schéma dégressif)",
     "Corticoïde oral — inflammation sévère, uvéite"
    ],
    [
     "Métronidazole",
     "Comprimés",
     "1 comprimé 2 à 3 fois/jour",
     "Antibiotique/antiparasitaire — rosacée, infection anaérobie"
    ],
    [
     "Rétinol A pommade",
     "Pommade ophtalmique",
     "Application selon prescription",
     "Vitamine A — xérophtalmie, carence"
    ],
    [
     "Cétirizine",
     "Comprimés",
     "1 comprimé/jour",
     "Antihistaminique — allergie"
    ],
    [
     "Vigamox",
     "Collyre",
     "1 goutte 3 fois/jour",
     "Antibiotique (moxifloxacine) — infection bactérienne oculaire"
    ],
    [
     "Betoptic",
     "Collyre",
     "1 goutte 2 fois/jour",
     "Anti-glaucomateux (bétaxolol, bêta-bloquant cardiosélectif)"
    ],
    [
     "Betagan",
     "Collyre",
     "1 goutte 1 à 2 fois/jour",
     "Anti-glaucomateux (lévobunolol, bêta-bloquant)"
    ],
    [
     "Iopidine",
     "Collyre",
     "1 goutte avant/après un geste laser",
     "Anti-glaucomateux (apraclonidine) — contrôle des pics tensionnels"
    ],
    [
     "Cyclogyl",
     "Collyre",
     "1 goutte avant l'examen",
     "Cycloplégique (cyclopentolate) — dilatation, réfraction sous cycloplégie"
    ],
    [
     "Homatropine collyre",
     "Collyre",
     "1 goutte selon prescription",
     "Cycloplégique / mydriatique"
    ],
    [
     "Celluvisc",
     "Collyre",
     "1 goutte autant que nécessaire",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "Cationorm",
     "Collyre",
     "1 goutte 2 à 4 fois/jour",
     "Lubrifiant oculaire — sécheresse oculaire sévère"
    ],
    [
     "Thealoz",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Lubrifiant oculaire (tréhalose) — sécheresse oculaire"
    ],
    [
     "Naabak",
     "Collyre",
     "1 goutte 3 à 5 fois/jour",
     "Lubrifiant oculaire sans conservateur — sécheresse oculaire"
    ],
    [
     "Vitamine E",
     "Comprimés",
     "1 comprimé/jour",
     "Complément antioxydant"
    ],
    [
     "Vitamine C",
     "Comprimés",
     "1 comprimé/jour",
     "Complément antioxydant"
    ],
    [
     "Chibro-Cadron",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique + corticoïde (néomycine/dexaméthasone)"
    ],
    [
     "Genoptic",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique (gentamicine) — infection bactérienne oculaire"
    ],
    [
     "Polydexa collyre",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Antibiotique + corticoïde (néomycine/polymyxine B/dexaméthasone)"
    ],
    [
     "Dacryum",
     "Collyre",
     "1 goutte autant que nécessaire",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "Duotrav",
     "Collyre",
     "1 goutte le soir",
     "Anti-glaucomateux (travoprost + timolol, association)"
    ],
    [
     "Xalacom",
     "Collyre",
     "1 goutte le soir",
     "Anti-glaucomateux (latanoprost + timolol, association)"
    ],
    [
     "Augmentin",
     "Comprimés",
     "1 comprimé 2 à 3 fois/jour",
     "Antibiotique (amoxicilline + acide clavulanique) — infection bactérienne"
    ],
    [
     "Ampicilline",
     "Gélules",
     "1 gélule 3 fois/jour",
     "Antibiotique (famille pénicilline) — infection bactérienne"
    ],
    [
     "Bévitine",
     "Comprimés",
     "1 comprimé/jour",
     "Supplémentation vitamine B1 — neuropathie"
    ],
    [
     "Mannitol",
     "Solution injectable",
     "Selon prescription (usage hospitalier)",
     "Traitement d'urgence de l'hypertonie oculaire aiguë (glaucome aigu par fermeture de l'angle)"
    ],
    [
     "Biocidan",
     "Collyre",
     "1 goutte 2 à 3 fois/jour",
     "Antiseptique oculaire"
    ],
    [
     "Sérum physiologique",
     "Collyre / solution",
     "Lavage oculaire selon besoin",
     "Lavage et confort oculaire"
    ],
    [
     "Optive",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "GenTeal",
     "Collyre",
     "1 goutte 3 à 4 fois/jour",
     "Lubrifiant oculaire — sécheresse oculaire"
    ],
    [
     "Predsol collyre",
     "Collyre",
     "1 goutte 4 fois/jour",
     "Corticoïde (prednisolone) — inflammation oculaire"
    ],
    [
     "Ciprofloxacine comprimés",
     "Comprimés",
     "1 comprimé 2 fois/jour",
     "Antibiotique (fluoroquinolone) — infection bactérienne"
    ],
    [
     "Spasfon",
     "Comprimés",
     "1 à 2 comprimés, 3 fois/jour",
     "Antispasmodique"
    ],
    [
     "Vogalène",
     "Comprimés",
     "1 comprimé 2 à 3 fois/jour",
     "Antiémétique — nausées, vomissements"
    ],
    [
     "Coartem",
     "Comprimés",
     "Selon poids, schéma sur 3 jours",
     "Antipaludéen (artéméther/luméfantrine)"
    ],
    [
     "Amodiaquine",
     "Comprimés",
     "Selon poids et prescription",
     "Antipaludéen"
    ],
    [
     "Feldene",
     "Comprimés",
     "1 comprimé/jour",
     "Anti-inflammatoire non stéroïdien (piroxicam) — douleur, inflammation"
    ],
    [
     "Profenid",
     "Comprimés",
     "1 comprimé 2 à 3 fois/jour",
     "Anti-inflammatoire non stéroïdien (kétoprofène) — douleur, inflammation"
    ]
   ]
  };
  const BILAN = [{"title": "Immuno / Hématologie", "items": ["Nfs", "Gousse Epaisse (Ge)", "Hba 1c", "Groupe/Rh", "Electrophorèse Hb", "TP", "TCA", "Fibrinemie"]}, {"title": "Sérologie", "items": ["Widal & Felix", "CRP", "TOXO", "RUBEOLE", "Syphilis", "Aslo", "VIH", "DENGUE"]}, {"title": "Sérologie — hépatite", "items": ["Ag Hbs", "Ag Hbe", "Ac anti Hbs", "Ac anti Hbs tx", "Ac anti Hbc", "Ac anti Hbe", "Ac anti Hvc", "AFD"]}, {"title": "Hormone", "items": ["LH", "FSH", "T3", "T4", "OESTROGENE", "PROGESTERONE", "Beta-HCG", "D-DIMERE", "Prolactine"]}, {"title": "Bactériologie", "items": ["ECBU + ATB", "Coproculture + ATB", "PU + Mycoplasmes", "PU + Chlamydia + Mycoplasme", "Hémoculture + ATB", "LCR (ECB)", "Spermogramme + ATB", "Microalbuminurie", "Protéinurie/24h"]}, {"title": "Biochimie", "items": ["UREE", "GLYCEMIE", "CREAT", "TRANSAMINASE", "IONOGRAMME", "CALCIUM", "MAGNESIUM", "ACIDE URIQUE", "BILIRUBINE T", "BILIRUBINE C", "Gamma-GT", "PHOSPHOREMIE", "PSA", "Phosphatase Alcaline", "CHOLESTEROL TOTAL", "TRIGLYCERIDES", "CHOLESTEROL LDL", "CHOLESTEROL HDL", "Glycémie p-prandiale", "PROTEINE TOTL", "PROTIDEMIE"]}];
  /* Examens du bulletin de biologie MSI déjà présents au catalogue des actes (facturés à la caisse). */
  const LABO = { 'Nfs': 'B-NFS', 'Gousse Epaisse (Ge)': 'B-GE', 'GLYCEMIE': 'B-GLY', 'CREAT': 'B-CREA', 'CRP': 'B-CRP', 'TRANSAMINASE': 'B-TRA', 'ECBU': 'B-ECBU' };

  const CONSTANTES = {
    taille: { l: 'Taille', unite: 'cm' }, poids: { l: 'Poids', unite: 'kg' }, imc: { l: 'IMC', unite: 'kg/m²', calcule: true },
    temperature: { l: 'Température', unite: '°C' }, ta: { l: 'Tension artérielle', unite: 'mmHg', exemple: '120/80' },
    pouls: { l: 'Pouls', unite: 'bpm' }, fr: { l: 'Fréquence respiratoire', unite: '/min' }, spo2: { l: 'Saturation (SpO₂)', unite: '%' },
    glycemie: { l: 'Glycémie capillaire', unite: 'g/L' }, pc: { l: 'Périmètre crânien', unite: 'cm' }, eva: { l: 'Douleur (EVA)', unite: '/10' }
  };
  const ATCD = {
    familiaux: ['HTA', 'Diabète', 'Drépanocytose', 'Asthme', 'Cancer', 'Aucun antécédent familial notable'],
    medicaux: ['HTA', 'Diabète', 'Asthme', 'Drépanocytose', 'Infection à VIH', 'Hépatite B', 'Tuberculose traitée', 'Allergie médicamenteuse', 'Aucun antécédent médical notable'],
    chirurgicaux: ['Aucune intervention chirurgicale', 'Appendicectomie', 'Césarienne', 'Cure de hernie', 'Fracture opérée'],
    traitements: ['Aucun traitement en cours', 'Antihypertenseur', 'Antidiabétique', 'Anticoagulant ou antiagrégant', 'Corticothérapie au long cours']
  };
  const CERTIF_OBJETS = ['Certificat de bonne santé', 'Aptitude sportive', 'Aptitude scolaire', 'Certificat de non contre-indication', 'Certificat de visite médicale', 'Autre (préciser)'];
  const MOTIFS_RDV = ['Contrôle', 'Résultats d’examens', 'Renouvellement d’ordonnance', 'Suivi au long cours', 'Contrôle post-opératoire'];
  const CONDUITES = ['Traitement prescrit, contrôle dans 1 mois', 'Surveillance simple', 'Bilan complémentaire demandé', 'Orientation vers une autre spécialité', 'Hospitalisation ou mise en observation', 'Conseils hygiéno-diététiques donnés'];

  const zone = (k, l, suggestions, lignes) => ({ k, l, t: 'zone', suggestions: suggestions || [], lignes: lignes || 2 });
  const texte = (k, l, unite, exemple) => ({ k, l, t: 'texte', unite, exemple });
  const nombre = (k, l, unite, alerte) => ({ k, l, t: 'nombre', unite, alerte });
  const liste = (k, l, options) => ({ k, l, t: 'liste', options });
  const paire = (k, l, opts) => ({ k, l, t: 'paire', cotes: ['OD', 'OG'], ...opts });
  const RISQUE_SUICIDAIRE = ['Non évalué', 'Absent', 'Faible', 'Moyen', 'Élevé : mesures de protection immédiates'];
  const ex = (l, code) => (code ? { l, code } : { l });

  function certificatsGeneriques(nom) {
    const constat = `L’examen clinique de ${nom.toLowerCase()} réalisé ce jour ne révèle aucune anomalie apparente.`;
    const reserve = 'Ce certificat n’engage que sur les constatations de l’examen de ce jour.';
    const c = conclusion => [{ label: 'Examen normal, sans réserve', constat, conclusion: `${conclusion} ${reserve}` }];
    return {
      'Certificat de bonne santé': c('Le/la patient(e) ne présente, à la date de ce jour et sur la base de cet examen, aucun signe apparent de maladie.'),
      'Aptitude sportive': c('Le/la patient(e) ne présente pas, ce jour, de contre-indication apparente à la pratique du sport en loisir.'),
      'Aptitude scolaire': c('L’état de santé constaté ce jour est compatible avec la fréquentation scolaire.'),
      'Certificat de non contre-indication': c('Aucune contre-indication apparente n’a été relevée ce jour à l’activité mentionnée.'),
      'Certificat de visite médicale': c('Le/la patient(e) s’est présenté(e) ce jour à la consultation.')
    };
  }
  const SPECIALITES = {};
  function ajouter(d) {
    SPECIALITES[d.nom] = {
      constantes: ['taille', 'poids', 'imc', 'temperature', 'ta', 'pouls', 'fr', 'spo2', 'glycemie'],
      atcd: { familiaux: ATCD.familiaux, medicaux: ATCD.medicaux, chirurgicaux: ATCD.chirurgicaux, traitements: ATCD.traitements },
      atcd_extra: [], sections: [], diagnostics: [], conduites: CONDUITES, examens: [], infos_examens: [],
      documents: ['ordonnance', 'examens', 'certificat', 'compte_rendu', 'orientation', 'rdv'],
      comptes_rendus: [], medicaments: [], rdv_motifs: MOTIFS_RDV, certificats: certificatsGeneriques(d.nom), orientation: {}, bilan: true,
      ...d
    };
  }

  /* ===== Ophtalmologie : reprise d'OphtaSuite ===== */
  const cr = (cle, l, champs, modeles) => ({ cle, l, champs, modeles: modeles || {} });
  const g = OPHTA.glaucome;
  ajouter({
    nom: 'Ophtalmologie', constantes: ['taille', 'poids', 'temperature', 'ta', 'fr', 'pouls', 'glycemie'], motifs: OPHTA.motifs,
    atcd: { familiaux: OPHTA.atcd_familiaux, medicaux: OPHTA.atcd_pathologiques.concat(OPHTA.atcd_medicaux), chirurgicaux: OPHTA.atcd_chirurgicaux, traitements: ATCD.traitements },
    atcd_extra: [zone('atcd_traumatismes', 'Antécédents de traumatisme', OPHTA.atcd_traumatismes), liste('porte_verres', 'Port de verres correcteurs', ['Non', 'Oui']), texte('porte_verres_details', 'Précisions (type, depuis quand…)')],
    sections: [
      { titre: 'Acuité visuelle et réfraction', champs: [
        paire('av_loin_sc', 'AV de loin sans correction'), paire('av_loin_ac', 'AV de loin avec correction'), paire('av_ts', 'AV au trou sténopéique'),
        paire('av_pres_sc', 'AV de près sans correction'), paire('av_pres_ac', 'AV de près avec correction'),
        paire('to', 'Tension oculaire', { unite: 'mmHg', nombre: true, alerte: 'pio' }), paire('pachy', 'Pachymétrie', { unite: 'µm', nombre: true })] },
      { titre: 'Examen clinique', champs: [
        paire('segment', 'Segment antérieur', { zone: true, constats: OPHTA.segment }), paire('fond', 'Fond d’œil', { zone: true, constats: OPHTA.fond })] }
    ],
    diagnostics: OPHTA.diagnostics, conduites: OPHTA.conduites, examens: OPHTA.examens, infos_examens: OPHTA.exploration_infos,
    documents: ['ordonnance', 'examens', 'lunettes', 'certificat', 'compte_rendu', 'orientation', 'rdv'],
    comptes_rendus: [
      cr('champ_visuel', 'Champ visuel automatisé', [texte('cv_programme', 'Programme'), texte('cv_strategie', 'Stratégie'), zone('cv_od', 'Œil droit', [], 5), zone('cv_og', 'Œil gauche', [], 5), zone('cv_conclusion', 'Conclusion'), zone('cv_cat', 'Conduite à tenir')],
        { Normal: OPHTA.interpretations.champ_visuel, 'Glaucomateux': { ...OPHTA.interpretations.champ_visuel, ...g.champ_visuel.glaucomateux } }),
      cr('oct_fnr_ccg', 'OCT des FNR et du CCG (nerf optique)', [zone('oct_od', 'Œil droit', [], 4), zone('oct_og', 'Œil gauche', [], 4), zone('oct_ggl', 'Cellules ganglionnaires maculaires', [], 3), zone('oct_conclusion', 'Conclusion', [], 3)],
        { Normal: OPHTA.interpretations.oct_fnr_ccg, 'Glaucomateux': { ...OPHTA.interpretations.oct_fnr_ccg, ...g.oct_fnr_ccg.glaucomateux } }),
      cr('oct_maculaire', 'OCT maculaire', [zone('ocm_od', 'Œil droit', [], 3), zone('ocm_og', 'Œil gauche', [], 3), zone('ocm_conclusion', 'Conclusion')], { Normal: OPHTA.interpretations.oct_maculaire }),
      cr('fond_oeil', 'Examen clinique et fond d’œil', [zone('fo_lampeod', 'Lampe à fente, œil droit'), zone('fo_lampeog', 'Lampe à fente, œil gauche'), zone('fo_fondod', 'Fond d’œil droit', [], 3), zone('fo_fondog', 'Fond d’œil gauche', [], 3), zone('fo_autotal', 'Au total'), zone('fo_conclusion', 'Conclusion')],
        { Normal: OPHTA.interpretations.fond_oeil }),
      cr('pio_pachymetrie', 'PIO et pachymétrie', [texte('pio_od', 'PIO œil droit', 'mmHg'), texte('pio_og', 'PIO œil gauche', 'mmHg'), texte('pachy_od', 'Pachymétrie œil droit', 'µm'), texte('pachy_og', 'Pachymétrie œil gauche', 'µm'), zone('pio_conclusion', 'Conclusion', [], 3)]),
      cr('cro', 'Compte rendu opératoire', [liste('intervention', 'Intervention', Object.keys(OPHTA.chirurgie)), zone('indication', 'Indication'), zone('technique', 'Technique', [], 3), zone('deroulement', 'Déroulement', [], 3), zone('suites', 'Suites immédiates'), zone('prescription', 'Prescription de sortie', [], 3), zone('consignes', 'Consignes au patient', [], 3)],
        Object.fromEntries(Object.entries(OPHTA.chirurgie).map(([k, v]) => [k, { intervention: k, ...v }]))),
      cr('autre', 'Autre examen (compte rendu libre)', [texte('titre', 'Examen'), zone('texte', 'Compte rendu', [], 8)])
    ],
    medicaments: OPHTA.medicaments, rdv_motifs: OPHTA.rdv_motifs, certificats: OPHTA.certificats, orientation: OPHTA.orientation
  });

  /* ===== Médecine générale ===== */
  ajouter({
    nom: 'Médecine générale',
    motifs: ['Fièvre', 'Céphalées', 'Douleurs abdominales', 'Toux', 'Asthénie', 'Vomissements ou diarrhée', 'Douleurs articulaires', 'Vertiges', 'Bilan de santé', 'Renouvellement de traitement'],
    sections: [{ titre: 'Examen clinique', champs: [
      zone('etat_general', 'État général', ['Bon état général', 'Altération de l’état général', 'Conscient, bien orienté', 'Pâleur conjonctivale', 'Déshydratation', 'Ictère']),
      zone('examen_appareils', 'Examen par appareil', ['Auscultation cardio-pulmonaire normale', 'Abdomen souple et indolore', 'Pas de signe neurologique de localisation', 'Pas d’adénopathie', 'Examen ORL normal', 'Téguments sans particularité'], 5)] }],
    diagnostics: ['Paludisme simple', 'Paludisme grave (à hospitaliser)', 'Infection respiratoire haute', 'Gastro-entérite aiguë', 'Infection urinaire', 'Hypertension artérielle', 'Diabète', 'Fièvre typhoïde (suspicion)', 'Syndrome grippal', 'Parasitose intestinale'],
    conduites: ['Traitement ambulatoire, contrôle si persistance au-delà de 72 h', ...CONDUITES],
    examens: [ex('TDR paludisme', 'S-TDR'), ex('NFS', 'B-NFS'), ex('Goutte épaisse', 'B-GE'), ex('Glycémie', 'B-GLY'), ex('CRP', 'B-CRP'), ex('Créatininémie', 'B-CREA'), ex('Transaminases', 'B-TRA'), ex('ECBU', 'B-ECBU'), ex('ECG', 'T-ECG'), ex('Échographie abdominale', 'T-ECHO'), ex('Radiographie pulmonaire')],
    medicaments: [['Paracétamol 500 mg', 'Comprimé', '1 g 3 fois par jour (adulte)', 'Antalgique, antipyrétique'], ['Artéméther-luméfantrine 80/480 mg', 'Comprimé', '1 comprimé 2 fois par jour pendant 3 jours (adulte)', 'Paludisme simple'],
      ['Amoxicilline 500 mg', 'Gélule', '1 g 2 fois par jour pendant 7 jours (adulte)', 'Antibiotique'], ['Ibuprofène 400 mg', 'Comprimé', '1 comprimé 3 fois par jour au repas', 'Anti-inflammatoire'],
      ['Métronidazole 500 mg', 'Comprimé', '1 comprimé 3 fois par jour pendant 7 jours', 'Antibiotique, antiparasitaire'], ['Oméprazole 20 mg', 'Gélule', '1 gélule le matin à jeun', 'Protecteur gastrique'],
      ['Albendazole 400 mg', 'Comprimé', '1 comprimé en prise unique', 'Déparasitage'], ['Sels de réhydratation orale', 'Sachet', '1 sachet dans 1 litre d’eau, à boire après chaque selle liquide', 'Réhydratation']]
  });

  /* ===== Cardiologie ===== */
  ajouter({
    nom: 'Cardiologie',
    motifs: ['HTA découverte', 'Suivi d’HTA', 'Douleur thoracique', 'Palpitations', 'Dyspnée d’effort', 'Œdèmes des membres inférieurs', 'Malaise ou syncope', 'Bilan préopératoire', 'Suivi d’insuffisance cardiaque'],
    sections: [{ titre: 'Examen cardiovasculaire', champs: [
      paire('ta_bras', 'TA aux deux bras', { cotes: ['Bras droit', 'Bras gauche'], unite: 'mmHg', alerte: 'ta' }),
      zone('facteurs_risque', 'Facteurs de risque', ['HTA', 'Diabète', 'Tabagisme', 'Dyslipidémie', 'Obésité', 'Sédentarité', 'Hérédité coronarienne']),
      zone('auscultation', 'Auscultation cardiaque', ['Bruits du cœur réguliers, sans souffle', 'Souffle systolique', 'Souffle diastolique', 'Arythmie', 'Bruit de galop']),
      zone('insuffisance', 'Signes d’insuffisance cardiaque', ['Aucun signe', 'Œdèmes des membres inférieurs', 'Turgescence jugulaire', 'Reflux hépato-jugulaire', 'Crépitants pulmonaires']),
      zone('pouls_peripheriques', 'Pouls périphériques', ['Pouls perçus et symétriques', 'Pouls pédieux abolis', 'Souffle carotidien']),
      zone('ecg', 'ECG de repos', ['Rythme sinusal régulier', 'Hypertrophie ventriculaire gauche électrique', 'Troubles de la repolarisation', 'Fibrillation atriale', 'Bloc de branche'])] }],
    diagnostics: ['HTA essentielle', 'Cardiopathie hypertensive', 'Insuffisance cardiaque', 'Cardiopathie ischémique (suspicion)', 'Fibrillation atriale', 'Valvulopathie', 'Péricardite', 'Palpitations sans cardiopathie décelée'],
    examens: [ex('ECG de repos', 'T-ECG'), ex('Échocardiographie transthoracique', 'T-ECHO'), ex('Holter ECG des 24 h'), ex('MAPA (mesure ambulatoire de la TA)'), ex('Écho-doppler vasculaire'), ex('Épreuve d’effort'), ex('Radiographie thoracique'), ex('Glycémie', 'B-GLY'), ex('Créatininémie', 'B-CREA')],
    comptes_rendus: [
      cr('ecg', 'Interprétation d’ECG', [texte('rythme', 'Rythme'), texte('frequence', 'Fréquence', 'bpm'), texte('axe', 'Axe'), zone('conduction', 'Conduction (PR, QRS, QT)'), zone('repolarisation', 'Repolarisation'), zone('conclusion', 'Conclusion')],
        { Normal: { rythme: 'Sinusal régulier', axe: 'Normal', conduction: 'PR, QRS et QT normaux', repolarisation: 'Pas de trouble de la repolarisation', conclusion: 'ECG normal ce jour.' } }),
      cr('echo_coeur', 'Échocardiographie transthoracique', [zone('vg', 'Ventricule gauche (dimensions, FEVG)'), zone('cavites_droites', 'Cavités droites'), zone('valves', 'Valves'), zone('pericarde', 'Péricarde'), zone('conclusion', 'Conclusion')],
        { Normal: { vg: 'VG non dilaté, non hypertrophié, fonction systolique conservée', cavites_droites: 'Cavités droites de taille normale', valves: 'Pas de valvulopathie significative', pericarde: 'Pas d’épanchement péricardique', conclusion: 'Échocardiographie normale.' } })
    ],
    medicaments: [['Amlodipine 5 mg', 'Comprimé', '1 comprimé par jour', 'Antihypertenseur'], ['Losartan 50 mg', 'Comprimé', '1 comprimé par jour', 'Antihypertenseur'], ['Hydrochlorothiazide 25 mg', 'Comprimé', '1 comprimé le matin', 'Diurétique'],
      ['Bisoprolol 5 mg', 'Comprimé', '1 comprimé par jour', 'Bêtabloquant'], ['Périndopril 5 mg', 'Comprimé', '1 comprimé par jour', 'Antihypertenseur'], ['Furosémide 40 mg', 'Comprimé', '1 comprimé le matin', 'Diurétique'],
      ['Acide acétylsalicylique 100 mg', 'Comprimé', '1 comprimé par jour au repas', 'Antiagrégant'], ['Atorvastatine 20 mg', 'Comprimé', '1 comprimé le soir', 'Hypolipémiant']]
  });

  /* ===== Rhumatologie ===== */
  ajouter({
    nom: 'Rhumatologie', constantes: ['taille', 'poids', 'imc', 'temperature', 'ta', 'pouls', 'eva'],
    motifs: ['Douleur articulaire', 'Lombalgie', 'Cervicalgie', 'Douleur du genou', 'Polyarthralgies', 'Gonflement articulaire', 'Douleurs diffuses', 'Crise de goutte', 'Suivi de rhumatisme inflammatoire'],
    sections: [{ titre: 'Examen rhumatologique', champs: [
      zone('localisation', 'Localisation de la douleur', ['Genou', 'Hanche', 'Rachis lombaire', 'Rachis cervical', 'Épaule', 'Mains et poignets', 'Chevilles et pieds', 'Polyarticulaire']),
      liste('horaire', 'Horaire de la douleur', ['Mécanique', 'Inflammatoire', 'Mixte']), texte('derouillage', 'Dérouillage matinal', 'minutes'),
      zone('articulations', 'Examen articulaire', ['Pas de synovite', 'Synovite', 'Épanchement articulaire', 'Déformation', 'Limitation des amplitudes', 'Craquements']),
      zone('rachis', 'Examen du rachis', ['Rachis souple', 'Raideur rachidienne', 'Contracture paravertébrale', 'Signe de Lasègue positif', 'Distance doigts-sol augmentée']),
      nombre('nad', 'Articulations douloureuses (nombre)'), nombre('nag', 'Articulations gonflées (nombre)')] }],
    diagnostics: ['Gonarthrose', 'Coxarthrose', 'Lombalgie commune', 'Lombosciatique', 'Polyarthrite rhumatoïde', 'Goutte', 'Spondyloarthrite', 'Tendinopathie', 'Ostéoporose', 'Arthrite septique (suspicion, urgence)'],
    examens: [ex('Radiographie standard'), ex('CRP', 'B-CRP'), ex('NFS', 'B-NFS'), ex('Uricémie'), ex('Facteur rhumatoïde et anti-CCP'), ex('Échographie articulaire', 'T-ECHO'), ex('IRM ou scanner'), ex('Ostéodensitométrie')],
    comptes_rendus: [cr('infiltration', 'Compte rendu d’infiltration', [texte('site', 'Articulation ou site'), texte('produit', 'Produit et dose'), zone('technique', 'Asepsie et technique'), zone('tolerance', 'Tolérance immédiate'), zone('consignes', 'Consignes au patient')],
      { 'Infiltration standard': { technique: 'Asepsie rigoureuse, repérage clinique, injection sans incident', tolerance: 'Bonne tolérance immédiate', consignes: 'Repos relatif de l’articulation 48 heures. Consulter en cas de fièvre, de rougeur ou de douleur croissante.' } })],
    medicaments: [['Paracétamol 1 g', 'Comprimé', '1 comprimé 3 fois par jour', 'Antalgique'], ['Diclofénac 50 mg', 'Comprimé', '1 comprimé 2 à 3 fois par jour au repas, durée courte', 'Anti-inflammatoire'],
      ['Tramadol 50 mg', 'Gélule', '1 gélule jusqu’à 3 fois par jour si douleur intense', 'Antalgique de palier 2'], ['Colchicine 1 mg', 'Comprimé', 'Selon le schéma de la crise, à préciser', 'Crise de goutte'],
      ['Allopurinol 100 mg', 'Comprimé', '1 comprimé par jour, à distance de la crise', 'Hypo-uricémiant'], ['Méthotrexate', 'Comprimé', 'Une prise par semaine, dose à préciser', 'Traitement de fond (surveillance biologique)'],
      ['Acide folique 5 mg', 'Comprimé', '1 comprimé par semaine, à distance du méthotrexate', 'Supplémentation'], ['Oméprazole 20 mg', 'Gélule', '1 gélule par jour pendant le traitement anti-inflammatoire', 'Protecteur gastrique']]
  });

  /* ===== Néphrologie ===== */
  ajouter({
    nom: 'Néphrologie', constantes: ['taille', 'poids', 'imc', 'temperature', 'ta', 'pouls', 'glycemie'],
    motifs: ['Insuffisance rénale découverte', 'Suivi d’insuffisance rénale', 'Protéinurie', 'Hématurie', 'Œdèmes', 'HTA avec atteinte rénale', 'Suivi de dialyse', 'Colique néphrétique', 'Infections urinaires récidivantes'],
    sections: [{ titre: 'Examen néphrologique', champs: [
      zone('oedemes', 'Œdèmes', ['Pas d’œdème', 'Œdèmes des membres inférieurs prenant le godet', 'Œdème palpébral', 'Anasarque']),
      zone('diurese', 'Diurèse', ['Diurèse conservée', 'Oligurie', 'Polyurie', 'Nycturie', 'Urines mousseuses']),
      zone('bandelette', 'Bandelette urinaire', ['Bandelette négative', 'Protéinurie', 'Hématurie', 'Leucocyturie', 'Nitrites positifs', 'Glycosurie']),
      texte('creatinine', 'Dernière créatininémie', 'mg/L'), nombre('dfg', 'DFG estimé', 'mL/min/1,73 m²', 'dfg'),
      liste('suppleance', 'Suppléance rénale', ['Aucune', 'Hémodialyse', 'Dialyse péritonéale', 'Greffe rénale'])] }],
    diagnostics: ['Maladie rénale chronique (stade à préciser)', 'Insuffisance rénale aiguë', 'Néphropathie diabétique', 'Néphropathie hypertensive', 'Syndrome néphrotique', 'Glomérulonéphrite (suspicion)', 'Lithiase urinaire', 'Pyélonéphrite aiguë'],
    examens: [ex('Créatininémie', 'B-CREA'), ex('Urée et ionogramme'), ex('Protéinurie des 24 heures'), ex('ECBU', 'B-ECBU'), ex('NFS', 'B-NFS'), ex('Glycémie', 'B-GLY'), ex('Échographie rénale', 'T-ECHO')],
    medicaments: [['Furosémide 40 mg', 'Comprimé', '1 comprimé le matin, à adapter', 'Diurétique'], ['Losartan 50 mg', 'Comprimé', '1 comprimé par jour', 'Antihypertenseur, néphroprotecteur'], ['Amlodipine 5 mg', 'Comprimé', '1 comprimé par jour', 'Antihypertenseur'],
      ['Carbonate de calcium', 'Comprimé', 'Au milieu des repas, dose à préciser', 'Chélateur du phosphore'], ['Bicarbonate de sodium', 'Gélule', 'Dose à préciser selon la réserve alcaline', 'Correction de l’acidose'],
      ['Sulfate ferreux', 'Comprimé', '1 comprimé par jour', 'Anémie ferriprive'], ['Acide folique 5 mg', 'Comprimé', '1 comprimé par jour', 'Supplémentation'], ['Érythropoïétine', 'Injection sous-cutanée', 'Dose et rythme à préciser', 'Anémie de l’insuffisance rénale']]
  });

  /* ===== Dermatologie ===== */
  ajouter({
    nom: 'Dermatologie', constantes: ['poids', 'temperature', 'ta'],
    motifs: ['Démangeaisons', 'Éruption cutanée', 'Tache pigmentée', 'Acné', 'Chute de cheveux', 'Mycose', 'Plaie qui ne cicatrise pas', 'Tache blanche', 'Lésion du cuir chevelu'],
    sections: [{ titre: 'Examen dermatologique', champs: [
      zone('lesion', 'Lésion élémentaire', ['Macule', 'Papule', 'Vésicule', 'Bulle', 'Pustule', 'Nodule', 'Plaque', 'Squames', 'Croûte', 'Ulcération', 'Lichénification']),
      zone('topographie', 'Topographie', ['Visage', 'Cuir chevelu', 'Tronc', 'Membres supérieurs', 'Membres inférieurs', 'Plis', 'Paumes et plantes', 'Organes génitaux', 'Généralisée']),
      zone('aspect', 'Aspect, couleur et disposition'), liste('prurit', 'Prurit', ['Absent', 'Modéré', 'Intense, insomniant']),
      zone('phaneres', 'Phanères et muqueuses', ['Ongles normaux', 'Onychomycose', 'Alopécie', 'Muqueuses normales', 'Atteinte buccale']), texte('surface', 'Surface atteinte', '%')] }],
    diagnostics: ['Dermatite atopique', 'Eczéma de contact', 'Dermatophytie', 'Pityriasis versicolor', 'Gale', 'Acné', 'Psoriasis', 'Urticaire', 'Impétigo', 'Vitiligo'],
    examens: [ex('Prélèvement mycologique'), ex('Biopsie cutanée'), ex('NFS', 'B-NFS'), ex('Glycémie', 'B-GLY')],
    comptes_rendus: [cr('geste', 'Compte rendu de geste dermatologique', [texte('site', 'Site'), texte('geste', 'Geste (biopsie, exérèse…)'), zone('anesthesie', 'Anesthésie'), zone('deroulement', 'Déroulement'), zone('consignes', 'Soins et consignes')])],
    medicaments: [['Émollient', 'Crème', '1 à 2 applications par jour sur peau sèche', 'Soin de la peau'], ['Bétaméthasone 0,05 %', 'Crème', '1 application par jour, durée courte à préciser', 'Dermocorticoïde'],
      ['Kétoconazole 2 %', 'Crème', '1 application par jour pendant 2 à 4 semaines', 'Antifongique'], ['Perméthrine 5 %', 'Crème', 'Application sur tout le corps, à renouveler selon le protocole, traiter l’entourage', 'Gale'],
      ['Cétirizine 10 mg', 'Comprimé', '1 comprimé le soir', 'Antihistaminique'], ['Doxycycline 100 mg', 'Comprimé', '1 comprimé par jour au repas', 'Acné inflammatoire'],
      ['Peroxyde de benzoyle 5 %', 'Gel', '1 application le soir', 'Acné'], ['Acide fusidique 2 %', 'Crème', '2 applications par jour pendant 7 jours', 'Antibiotique local']]
  });

  /* ===== Diabétologie ===== */
  ajouter({
    nom: 'Diabétologie', constantes: ['taille', 'poids', 'imc', 'ta', 'pouls', 'glycemie'],
    motifs: ['Découverte de diabète', 'Suivi de diabète', 'Déséquilibre glycémique', 'Hypoglycémies', 'Plaie du pied', 'Bilan annuel des complications', 'Diabète gestationnel'],
    sections: [{ titre: 'Suivi du diabète', champs: [
      liste('type_diabete', 'Type de diabète', ['Type 1', 'Type 2', 'Gestationnel', 'À préciser']), texte('anciennete', 'Ancienneté', 'ans'), nombre('hba1c', 'Dernière HbA1c', '%', 'hba1c'),
      zone('traitement_actuel', 'Traitement actuel et observance', ['Mesures hygiéno-diététiques seules', 'Metformine', 'Sulfamide hypoglycémiant', 'Insuline', 'Observance bonne', 'Observance irrégulière']),
      liste('hypoglycemies', 'Hypoglycémies', ['Aucune', 'Occasionnelles', 'Fréquentes', 'Sévères']),
      zone('pieds', 'Examen des pieds', ['Pieds sans lésion', 'Sensibilité au monofilament conservée', 'Perte de sensibilité au monofilament', 'Pouls pédieux perçus', 'Pouls pédieux abolis', 'Plaie du pied', 'Hyperkératose ou mycose interdigitale']),
      zone('complications', 'Complications', ['Aucune complication connue', 'Rétinopathie (fond d’œil à faire)', 'Néphropathie', 'Neuropathie périphérique', 'Artériopathie des membres inférieurs'])] }],
    diagnostics: ['Diabète de type 2 équilibré', 'Diabète de type 2 déséquilibré', 'Diabète de type 1', 'Pied diabétique', 'Néphropathie diabétique', 'Neuropathie diabétique', 'Diabète gestationnel', 'Prédiabète'],
    examens: [ex('Glycémie à jeun', 'B-GLY'), ex('HbA1c'), ex('Créatininémie', 'B-CREA'), ex('Microalbuminurie'), ex('Bilan lipidique'), ex('ECG', 'T-ECG'), ex('ECBU', 'B-ECBU')],
    rdv_motifs: ['Suivi trimestriel', 'Résultats d’HbA1c', 'Éducation thérapeutique', 'Soins de plaie du pied', ...MOTIFS_RDV],
    medicaments: [['Metformine 850 mg', 'Comprimé', '1 comprimé 2 fois par jour au repas', 'Antidiabétique'], ['Gliclazide 30 mg LM', 'Comprimé', '1 comprimé le matin', 'Antidiabétique (risque d’hypoglycémie)'],
      ['Glibenclamide 5 mg', 'Comprimé', '1 comprimé le matin', 'Antidiabétique (risque d’hypoglycémie)'], ['Insuline NPH', 'Stylo injectable', 'Unités et horaires à préciser', 'Insuline intermédiaire'],
      ['Insuline rapide', 'Stylo injectable', 'Unités à préciser avant les repas', 'Insuline rapide'], ['Atorvastatine 20 mg', 'Comprimé', '1 comprimé le soir', 'Hypolipémiant'],
      ['Losartan 50 mg', 'Comprimé', '1 comprimé par jour', 'Néphroprotecteur'], ['Bandelettes et lecteur de glycémie', 'Dispositif', 'Autosurveillance selon le schéma prescrit', 'Autosurveillance']]
  });

  /* ===== Infectiologie ===== */
  ajouter({
    nom: 'Infectiologie', constantes: ['poids', 'temperature', 'ta', 'pouls', 'fr', 'spo2'],
    motifs: ['Fièvre prolongée', 'Suivi VIH', 'Hépatite B', 'Fièvre typhoïde', 'Infections récidivantes', 'Toux chronique', 'Conseils avant un voyage', 'Accident d’exposition au sang'],
    sections: [{ titre: 'Examen infectiologique', champs: [
      zone('foyer', 'Foyer infectieux', ['Pas de foyer retrouvé', 'Foyer pulmonaire', 'Foyer urinaire', 'Foyer digestif', 'Foyer ORL', 'Foyer cutané', 'Foyer neuro-méningé']),
      zone('gravite', 'Signes de gravité', ['Aucun signe de gravité', 'Hypotension', 'Trouble de la conscience', 'Détresse respiratoire', 'Déshydratation sévère', 'Purpura']),
      zone('serologies', 'Statut sérologique connu', ['VIH négatif', 'VIH positif sous traitement', 'AgHBs positif', 'Hépatite C', 'Statut inconnu']),
      zone('traitement_arv', 'Traitement antirétroviral et observance'),
      zone('vaccins', 'Vaccinations', ['À jour', 'Hépatite B', 'Fièvre jaune', 'Méningite', 'Non à jour'])] }],
    diagnostics: ['Paludisme', 'Fièvre typhoïde', 'Infection à VIH', 'Hépatite B chronique', 'Tuberculose (suspicion, à confirmer)', 'Infection urinaire', 'Pneumopathie', 'Dengue (suspicion)', 'Infection sexuellement transmissible'],
    examens: [ex('TDR paludisme', 'S-TDR'), ex('Goutte épaisse', 'B-GE'), ex('NFS', 'B-NFS'), ex('CRP', 'B-CRP'), ex('Transaminases', 'B-TRA'), ex('ECBU', 'B-ECBU'), ex('Charge virale et CD4'), ex('Recherche de BK (GeneXpert)'), ex('Hémoculture'), ex('Radiographie pulmonaire')],
    medicaments: [['Artéméther-luméfantrine 80/480 mg', 'Comprimé', '1 comprimé 2 fois par jour pendant 3 jours (adulte)', 'Paludisme simple'], ['Ciprofloxacine 500 mg', 'Comprimé', '1 comprimé 2 fois par jour, durée à préciser', 'Antibiotique'],
      ['Ceftriaxone 1 g', 'Injectable', '1 g par jour, durée à préciser', 'Antibiotique'], ['Amoxicilline 1 g', 'Comprimé', '1 comprimé 2 à 3 fois par jour', 'Antibiotique'],
      ['Cotrimoxazole 960 mg', 'Comprimé', '1 comprimé par jour', 'Prophylaxie'], ['Ténofovir, lamivudine et dolutégravir', 'Comprimé', '1 comprimé par jour', 'Traitement antirétroviral'],
      ['Paracétamol 1 g', 'Comprimé', '1 comprimé 3 fois par jour', 'Antipyrétique']]
  });

  /* ===== Pédiatrie médicale (posologies toujours rapportées au poids) ===== */
  const SIGNES_DANGER = ['Aucun signe général de danger', 'Incapable de boire ou de téter', 'Vomit tout', 'Convulsions', 'Léthargie ou inconscience'];
  ajouter({
    nom: 'Pédiatrie médicale', constantes: ['poids', 'taille', 'pc', 'temperature', 'fr', 'pouls', 'spo2'],
    atcd: { familiaux: ATCD.familiaux, medicaux: ['Prématurité', 'Drépanocytose', 'Asthme', 'Convulsions fébriles', 'Malnutrition', 'Aucun antécédent notable'], chirurgicaux: ATCD.chirurgicaux, traitements: ['Aucun traitement en cours', 'Supplémentation en fer', 'Traitement de fond de l’asthme'] },
    motifs: ['Fièvre', 'Toux ou difficulté respiratoire', 'Diarrhée', 'Vomissements', 'Éruption cutanée', 'Refus de téter', 'Suivi de croissance', 'Vaccination', 'Convulsions'],
    sections: [{ titre: 'Examen pédiatrique', champs: [
      zone('danger', 'Signes généraux de danger', SIGNES_DANGER),
      zone('alimentation', 'Alimentation', ['Allaitement maternel exclusif', 'Allaitement mixte', 'Diversification en cours', 'Alimentation familiale', 'Appétit conservé', 'Refus alimentaire']),
      zone('vaccination', 'Statut vaccinal (PEV)', ['PEV à jour selon le carnet', 'PEV incomplet', 'Carnet non présenté', 'Rattrapage à prévoir']),
      zone('developpement', 'Développement psychomoteur', ['Développement normal pour l’âge', 'Retard de la marche', 'Retard de langage', 'À surveiller']),
      zone('nutrition', 'État nutritionnel', ['Bon état nutritionnel', 'Malnutrition aiguë modérée', 'Malnutrition aiguë sévère', 'Surpoids']),
      zone('examen', 'Examen clinique', ['Enfant éveillé et réactif', 'Fontanelle normotendue', 'Déshydratation', 'Pâleur', 'Râles à l’auscultation', 'Tympans normaux', 'Pas de raideur méningée'], 4)] }],
    diagnostics: ['Paludisme simple', 'Paludisme grave (hospitalisation)', 'Infection respiratoire aiguë', 'Pneumonie', 'Diarrhée aiguë', 'Otite moyenne aiguë', 'Bronchiolite', 'Malnutrition aiguë', 'Anémie', 'Crise drépanocytaire'],
    conduites: ['Traitement ambulatoire, contrôle dans 48 heures', 'Hospitalisation', 'SRO et zinc', 'Signes de danger expliqués aux parents', 'Mise à jour des vaccins', 'Orientation vers la chirurgie pédiatrique'],
    examens: [ex('TDR paludisme', 'S-TDR'), ex('Goutte épaisse', 'B-GE'), ex('NFS', 'B-NFS'), ex('CRP', 'B-CRP'), ex('Glycémie', 'B-GLY'), ex('ECBU', 'B-ECBU'), ex('Électrophorèse de l’hémoglobine'), ex('Radiographie pulmonaire')],
    rdv_motifs: ['Contrôle à 48 heures', 'Vaccination', 'Suivi de croissance', ...MOTIFS_RDV],
    medicaments: [['Paracétamol', 'Sirop ou suppositoire', '15 mg/kg toutes les 6 heures', 'Antipyrétique'], ['Ibuprofène', 'Sirop', '10 mg/kg toutes les 8 heures, après 3 mois', 'Antipyrétique'],
      ['Amoxicilline', 'Suspension buvable', '80 à 100 mg/kg/jour en 2 à 3 prises', 'Antibiotique'], ['Artéméther-luméfantrine', 'Comprimé dispersible', 'Selon le poids, 2 prises par jour pendant 3 jours', 'Paludisme simple'],
      ['Sels de réhydratation orale', 'Sachet', 'Après chaque selle liquide', 'Réhydratation'], ['Zinc', 'Comprimé dispersible', '10 mg/jour avant 6 mois, 20 mg/jour après, pendant 10 à 14 jours', 'Diarrhée'],
      ['Albendazole', 'Comprimé', '400 mg en prise unique après 2 ans, 200 mg entre 1 et 2 ans', 'Déparasitage']]
  });

  /* ===== Chirurgie pédiatrique ===== */
  const CRO_GENERIQUE = [texte('intervention', 'Intervention'), zone('indication', 'Indication'), zone('anesthesie', 'Anesthésie'), zone('technique', 'Technique', [], 3), zone('deroulement', 'Déroulement', [], 3), zone('suites', 'Suites immédiates'), zone('consignes', 'Consignes et prescription de sortie', [], 3)];
  ajouter({
    nom: 'Chirurgie pédiatrique', constantes: ['poids', 'taille', 'temperature', 'pouls', 'fr', 'spo2'],
    motifs: ['Hernie inguinale', 'Hernie ombilicale', 'Testicule non descendu', 'Douleur abdominale aiguë', 'Phimosis', 'Brûlure', 'Traumatisme', 'Masse abdominale', 'Malformation congénitale'],
    sections: [{ titre: 'Examen chirurgical', champs: [
      zone('examen_chir', 'Examen chirurgical', ['Abdomen souple', 'Défense abdominale', 'Masse palpable', 'Tuméfaction inguinale réductible', 'Tuméfaction inguinale non réductible', 'Bourses vides', 'Plaie', 'Déformation traumatique'], 4),
      liste('indication', 'Indication opératoire', ['Pas d’indication opératoire', 'Indication à programmer', 'Indication urgente']), texte('intervention_proposee', 'Intervention proposée'),
      zone('bilan_preop', 'Bilan préopératoire', ['NFS', 'Groupe sanguin et rhésus', 'TP et TCA', 'Consultation d’anesthésie']),
      liste('consentement', 'Information des parents', ['Non encore recueillie', 'Information donnée, consentement recueilli'])] }],
    diagnostics: ['Hernie inguinale', 'Hernie ombilicale', 'Hydrocèle', 'Cryptorchidie', 'Appendicite aiguë (suspicion)', 'Invagination intestinale (suspicion)', 'Phimosis', 'Sténose du pylore (suspicion)', 'Brûlure'],
    examens: [ex('NFS', 'B-NFS'), ex('Groupe sanguin et rhésus'), ex('TP et TCA'), ex('Échographie abdominale', 'T-ECHO'), ex('Radiographie')],
    comptes_rendus: [cr('cro', 'Compte rendu opératoire', CRO_GENERIQUE)],
    medicaments: [['Paracétamol', 'Sirop ou suppositoire', '15 mg/kg toutes les 6 heures', 'Antalgique'], ['Ibuprofène', 'Sirop', '10 mg/kg toutes les 8 heures, après 3 mois', 'Antalgique'],
      ['Amoxicilline et acide clavulanique', 'Suspension buvable', 'Selon le poids, dose à préciser', 'Antibiotique'], ['Antiseptique cutané', 'Solution', 'Soins de plaie 1 fois par jour', 'Soins locaux']]
  });

  /* ===== Gynécologie-obstétrique ===== */
  ajouter({
    nom: 'Gynécologie-obstétrique', constantes: ['poids', 'taille', 'imc', 'ta', 'pouls', 'temperature', 'glycemie'],
    motifs: ['Suivi de grossesse (CPN)', 'Retard de règles', 'Douleurs pelviennes', 'Pertes vaginales', 'Saignements', 'Infertilité', 'Contraception', 'Troubles du cycle', 'Consultation post-natale'],
    sections: [
      { titre: 'Situation gynécologique et obstétricale', champs: [
        { k: 'ddr', l: 'Date des dernières règles', t: 'date' }, texte('gestite', 'Gestité et parité', null, 'G3P2'),
        zone('contraception', 'Contraception', ['Aucune', 'Pilule', 'Injectable', 'Implant', 'Dispositif intra-utérin', 'Préservatif'])] },
      { titre: 'Examen', champs: [
        nombre('hu', 'Hauteur utérine', 'cm'), texte('bcf', 'Bruits du cœur fœtal', 'bpm'), liste('maf', 'Mouvements actifs fœtaux', ['Non concerné', 'Perçus', 'Diminués', 'Non perçus']),
        zone('examen_gyneco', 'Examen gynécologique', ['Seins normaux', 'Spéculum : col sain', 'Leucorrhées', 'Col long, fermé, postérieur', 'Utérus de taille normale', 'Masse annexielle', 'Saignement endocervical']),
        zone('alarme', 'Signes d’alarme', ['Aucun signe d’alarme', 'Saignements', 'Céphalées et troubles visuels (pré-éclampsie ?)', 'Contractions utérines', 'Perte de liquide', 'Œdèmes'])] }],
    diagnostics: ['Grossesse évolutive normale', 'Menace d’accouchement prématuré', 'Pré-éclampsie (suspicion)', 'Infection génitale basse', 'Infection urinaire gravidique', 'Fibrome utérin', 'Kyste ovarien', 'Infertilité du couple', 'Grossesse extra-utérine (suspicion, urgence)', 'Dysménorrhée'],
    examens: [ex('Échographie obstétricale ou pelvienne', 'T-ECHO'), ex('NFS', 'B-NFS'), ex('Groupe sanguin et rhésus'), ex('Glycémie', 'B-GLY'), ex('ECBU', 'B-ECBU'), ex('Frottis cervico-utérin'), ex('Dosage de β-hCG')],
    comptes_rendus: [
      cr('echo_obs', 'Échographie obstétricale', [texte('terme', 'Terme estimé'), texte('activite', 'Activité cardiaque'), zone('biometrie', 'Biométrie'), zone('placenta', 'Placenta et liquide amniotique'), texte('presentation', 'Présentation'), zone('conclusion', 'Conclusion')]),
      cr('cro', 'Compte rendu opératoire', CRO_GENERIQUE)],
    rdv_motifs: ['Consultation prénatale', 'Échographie', 'Consultation post-natale', ...MOTIFS_RDV],
    medicaments: [['Fer et acide folique', 'Comprimé', '1 comprimé par jour pendant la grossesse', 'Supplémentation'], ['Sulfadoxine-pyriméthamine', 'Comprimé', '3 comprimés en prise unique supervisée, selon le calendrier du traitement préventif', 'Prévention du paludisme pendant la grossesse'],
      ['Paracétamol 500 mg', 'Comprimé', '1 g jusqu’à 3 fois par jour', 'Antalgique'], ['Phloroglucinol 80 mg', 'Comprimé', '2 comprimés jusqu’à 3 fois par jour', 'Antispasmodique'],
      ['Méthyldopa 250 mg', 'Comprimé', 'Dose à préciser', 'Antihypertenseur de la grossesse'], ['Métronidazole 500 mg', 'Ovule', '1 ovule le soir pendant 7 jours', 'Infection vaginale'], ['Clotrimazole 500 mg', 'Ovule', '1 ovule en dose unique le soir', 'Mycose vaginale']]
  });

  /* ===== Santé mentale ===== */
  const PSY_SECTIONS = [
    zone('presentation', 'Présentation et contact', ['Contact bon', 'Contact difficile', 'Tenue soignée', 'Incurie', 'Agitation', 'Ralentissement psychomoteur']),
    zone('humeur', 'Humeur et affects', ['Humeur neutre', 'Humeur triste', 'Perte de plaisir', 'Humeur exaltée', 'Anxiété', 'Irritabilité']),
    liste('risque_suicidaire', 'Évaluation du risque suicidaire', RISQUE_SUICIDAIRE)];
  ajouter({
    nom: 'Psychiatrie', constantes: ['poids', 'ta', 'pouls'],
    motifs: ['Troubles du sommeil', 'Tristesse ou humeur dépressive', 'Anxiété', 'Troubles du comportement', 'Idées délirantes', 'Addiction', 'Suivi de traitement', 'Crise d’agitation'],
    sections: [{ titre: 'Examen psychiatrique', champs: [...PSY_SECTIONS,
      zone('pensee', 'Pensée et perceptions', ['Discours cohérent', 'Idées délirantes', 'Hallucinations auditives', 'Hallucinations visuelles', 'Pas d’élément délirant']),
      zone('sommeil', 'Sommeil et appétit', ['Sommeil conservé', 'Insomnie', 'Hypersomnie', 'Appétit conservé', 'Perte d’appétit']),
      zone('insight', 'Conscience du trouble et observance', ['Bonne conscience du trouble', 'Conscience partielle', 'Déni du trouble', 'Observance bonne', 'Observance irrégulière']),
      zone('substances', 'Consommation de substances', ['Aucune', 'Alcool', 'Tabac', 'Cannabis', 'Autres substances'])] }],
    diagnostics: ['Épisode dépressif', 'Trouble anxieux', 'Trouble bipolaire', 'Schizophrénie', 'Trouble psychotique bref', 'Trouble lié à l’usage de substances', 'Insomnie', 'État de stress post-traumatique'],
    examens: [ex('NFS', 'B-NFS'), ex('Glycémie', 'B-GLY'), ex('Créatininémie', 'B-CREA'), ex('Transaminases', 'B-TRA'), ex('ECG', 'T-ECG')],
    medicaments: [['Amitriptyline 25 mg', 'Comprimé', '1 comprimé le soir, à adapter', 'Antidépresseur'], ['Fluoxétine 20 mg', 'Gélule', '1 gélule le matin', 'Antidépresseur'],
      ['Rispéridone 2 mg', 'Comprimé', 'Dose à préciser', 'Antipsychotique'], ['Halopéridol 5 mg', 'Comprimé', 'Dose à préciser', 'Antipsychotique'],
      ['Diazépam 5 mg', 'Comprimé', 'Dose à préciser, durée courte', 'Anxiolytique (registre des psychotropes)'], ['Carbamazépine 200 mg', 'Comprimé', 'Dose à préciser', 'Thymorégulateur']]
  });
  ajouter({
    nom: 'Psychologie', constantes: [], bilan: false,
    atcd: { familiaux: ['Aucun antécédent familial notable', 'Antécédents psychiatriques familiaux'], medicaux: ['Suivi psychiatrique', 'Aucun antécédent notable'], chirurgicaux: [], traitements: ['Aucun traitement en cours', 'Traitement psychotrope'] },
    motifs: ['Anxiété', 'Stress', 'Difficultés familiales ou de couple', 'Deuil', 'Difficultés scolaires', 'Événement traumatique', 'Suivi psychothérapeutique'],
    sections: [{ titre: 'Entretien psychologique', champs: [zone('demande', 'Demande et contexte', [], 4), zone('histoire', 'Histoire de vie et entourage', [], 3), ...PSY_SECTIONS,
      zone('tests', 'Tests et échelles', ['PHQ-9', 'GAD-7', 'Inventaire de Beck', 'Entretien semi-structuré']), zone('objectifs', 'Objectifs de prise en charge', [], 3)] }],
    diagnostics: ['Anxiété réactionnelle', 'Symptômes dépressifs (avis psychiatrique à demander)', 'Deuil compliqué', 'Conflit familial', 'Difficultés d’apprentissage', 'Stress post-traumatique'],
    conduites: ['Suivi psychothérapeutique, séance dans 1 semaine', 'Orientation vers le psychiatre', 'Entretien familial proposé', 'Fin de suivi'],
    documents: ['compte_rendu', 'orientation', 'rdv'],
    comptes_rendus: [cr('bilan_psy', 'Compte rendu de bilan psychologique', [texte('outils', 'Outils utilisés'), zone('resultats', 'Résultats', [], 5), zone('synthese', 'Synthèse', [], 4), zone('recommandations', 'Recommandations', [], 3)])],
    rdv_motifs: ['Séance de suivi', 'Entretien familial', 'Restitution de bilan']
  });


  /* ===== Fiches conseils remises au patient (ophtalmologie : reprises d'OphtaSuite) ===== */
  const fiche = (code, titre, items) => ({ code, titre, items });
  const CONSEILS = {
    'Ophtalmologie': [{"code": "general", "titre": "Conseils généraux pour la santé de vos yeux", "items": ["Faites contrôler votre vue régulièrement, même sans symptôme — au moins une fois tous les 1 à 2 ans, ou selon les indications de votre médecin.", "Protégez vos yeux du soleil avec des lunettes de soleil filtrantes (catégorie 3), surtout en milieu de journée.", "Lavez-vous toujours les mains avant de toucher vos yeux ou de manipuler vos lunettes/lentilles.", "Adoptez une alimentation équilibrée, riche en légumes verts, en poisson et en fruits — bénéfique pour la santé de la rétine.", "Ne vous frottez pas les yeux avec insistance, surtout en cas de démangeaison — préférez un lavage à l'eau propre.", "Ne partagez jamais vos collyres, lunettes ou lentilles avec une autre personne."]}, {"code": "lunettes", "titre": "Bien porter ses lunettes", "items": ["Portez vos lunettes tel que prescrit — le temps de port indiqué par votre médecin doit être respecté, même si la vision semble correcte sans elles.", "Ne pas porter ses lunettes quand elles sont nécessaires peut entraîner maux de tête, fatigue oculaire et vision floue persistante.", "Chez l'enfant, le port régulier est essentiel : un refus prolongé peut freiner le bon développement de la vision (amblyopie, ou « œil paresseux »).", "Nettoyez vos verres avec de l'eau et un chiffon doux ou microfibre — évitez les vêtements et le papier essuie-tout qui rayent les verres.", "Faites vérifier l'ajustement de la monture régulièrement pour un confort optimal.", "En cas de gêne, de vision qui se dégrade ou de maux de tête persistants avec vos lunettes, consultez plutôt que d'arrêter de les porter."]}, {"code": "myopie", "titre": "La myopie", "items": ["La myopie fait voir net de près mais flou de loin : l'image se forme en avant de la rétine au lieu de se former dessus.", "Avec vos lunettes portées comme prescrit : vision nette de loin, meilleure sécurité au quotidien (route, panneaux, tableau à l'école), moins de plissement des yeux et moins de fatigue.", "Si vous refusez de les porter : vision floue de loin qui persiste, maux de tête et fatigue oculaire à force de plisser les yeux, risque accru d'accident (route, sport, activités du quotidien).", "Chez l'enfant et l'adolescent, une myopie non corrigée peut évoluer plus vite et gêner les apprentissages scolaires (lecture au tableau notamment).", "La myopie peut évoluer avec l'âge, surtout chez l'enfant — un contrôle régulier permet d'adapter la correction à temps."]}, {"code": "hypermetropie", "titre": "L'hypermétropie", "items": ["L'hypermétropie oblige l'œil à fournir un effort supplémentaire pour voir net, surtout de près : l'image se forme en arrière de la rétine.", "Avec vos lunettes portées comme prescrit : confort de lecture et de vision de près, moins d'effort pour l'œil, moins de maux de tête liés à la fatigue visuelle.", "Si vous refusez de les porter : fatigue oculaire fréquente, maux de tête surtout en fin de journée ou après une lecture prolongée, vision de près qui reste inconfortable.", "Chez l'enfant, une hypermétropie importante non corrigée peut favoriser l'apparition d'un strabisme (œil qui dévie) et d'une amblyopie (« œil paresseux ») — d'où l'importance du dépistage précoce."]}, {"code": "astigmatisme", "titre": "L'astigmatisme", "items": ["L'astigmatisme est lié à une cornée qui n'est pas parfaitement ronde, ce qui déforme légèrement les images, de loin comme de près.", "Avec vos lunettes portées comme prescrit : vision plus nette et plus précise à toutes les distances, moins de fatigue visuelle au quotidien.", "Si vous refusez de les porter : vision floue ou dédoublée persistante, fatigue oculaire, maux de tête, difficulté à se concentrer notamment en lecture prolongée ou sur écran.", "L'astigmatisme est souvent associé à une myopie ou une hypermétropie — la correction globale prescrite tient compte de l'ensemble."]}, {"code": "presbytie", "titre": "La presbytie", "items": ["La presbytie est liée à l'âge (en général à partir de 40-45 ans) : l'œil perd progressivement sa capacité à faire la mise au point de près.", "Avec vos lunettes portées comme prescrit : lecture et travaux de près confortables, sans effort ni fatigue excessive.", "Si vous refusez de les porter : tendance à éloigner les objets ou les écrits pour arriver à les lire, fatigue oculaire et maux de tête en fin de journée, gêne pour les activités demandant de la précision.", "La presbytie évolue progressivement avec l'âge — un contrôle régulier permet d'ajuster la correction au fil du temps."]}, {"code": "lentilles", "titre": "Port et entretien des lentilles de contact", "items": ["Lavez-vous soigneusement les mains avant toute manipulation de vos lentilles.", "Respectez strictement la durée de port quotidienne et la durée de vie de vos lentilles (journalières, mensuelles…).", "Ne dormez jamais avec vos lentilles sauf indication contraire explicite de votre ophtalmologiste.", "N'utilisez jamais d'eau du robinet pour rincer ou conserver vos lentilles — uniquement une solution d'entretien adaptée.", "Retirez immédiatement vos lentilles en cas de douleur, rougeur importante ou baisse de vision, et consultez rapidement.", "N'utilisez jamais de lentilles périmées ou une solution d'entretien ouverte depuis trop longtemps."]}, {"code": "ecrans", "titre": "Écrans et fatigue visuelle", "items": ["Appliquez la règle du 20/20/20 : toutes les 20 minutes, regardez à 20 pieds (environ 6 mètres) pendant 20 secondes.", "Clignez des yeux régulièrement devant un écran — on cligne naturellement moins souvent, ce qui assèche l'œil.", "Réglez la luminosité de votre écran pour qu'elle soit proche de celle de la pièce environnante.", "Maintenez une distance d'environ 50 à 60 cm entre vos yeux et l'écran.", "En cas de sécheresse oculaire liée aux écrans, des larmes artificielles peuvent soulager — demandez conseil à votre médecin.", "Limitez le temps d'écran chez l'enfant et privilégiez des pauses régulières en extérieur, à la lumière naturelle."]}, {"code": "diabete", "titre": "Diabète et santé des yeux", "items": ["Le diabète peut endommager la rétine silencieusement, sans aucun symptôme au début — c'est pourquoi le dépistage régulier est essentiel.", "Un examen du fond d'œil est recommandé au moins une fois par an chez toute personne diabétique, même sans trouble de la vision.", "Un bon contrôle de la glycémie, de la tension artérielle et du cholestérol ralentit fortement l'évolution de la rétinopathie diabétique.", "Toute baisse brutale de la vision, apparition de taches ou de « mouches volantes » doit amener à consulter rapidement.", "Ne négligez jamais un rendez-vous de contrôle ophtalmologique, même si vous vous sentez bien."]}, {"code": "enfant", "titre": "Dépistage visuel chez l'enfant", "items": ["Un premier examen des yeux est recommandé dès les premiers mois de vie, puis avant l'entrée à l'école.", "Un enfant ne se plaint presque jamais de mal voir — il ne sait pas que sa vision est différente de la normale. La vigilance des parents est essentielle.", "Observez : strabisme (œil qui louche), tête penchée, rapprochement excessif des objets, yeux plissés, gêne à la lumière.", "Une mauvaise vision non corrigée tôt peut entraîner une amblyopie (« œil paresseux ») durable, même après correction plus tard.", "Si des lunettes sont prescrites, leur port régulier — y compris à l'école — est indispensable à leur efficacité.", "Un contrôle annuel est recommandé pendant toute la croissance de l'enfant."]}, {"code": "postop", "titre": "Consignes après une chirurgie oculaire", "items": ["Suivez scrupuleusement le traitement (collyres) prescrit après l'opération, aux horaires indiqués, sans interruption prématurée.", "Ne frottez jamais l'œil opéré, même en cas de démangeaison.", "Évitez l'eau du robinet, le savon, le maquillage et la poussière au contact direct de l'œil opéré pendant la durée indiquée par votre chirurgien.", "Portez la coque ou les lunettes de protection fournies, notamment pendant le sommeil, selon les consignes reçues.", "Évitez les efforts physiques intenses, le port de charges lourdes et la piscine pendant la période de convalescence indiquée.", "Consultez en urgence en cas de douleur importante, de baisse brutale de la vision ou de rougeur qui s'aggrave.", "Ne manquez aucun rendez-vous de contrôle post-opératoire, même si tout semble aller bien."]}, {"code": "urgence", "titre": "Signes nécessitant une consultation en urgence", "items": ["Baisse brutale ou importante de la vision, d'un œil ou des deux.", "Douleur oculaire intense, surtout si elle s'accompagne de nausées ou de maux de tête.", "Traumatisme de l'œil (choc, projection de produit chimique ou corps étranger).", "Apparition soudaine de flashs lumineux, d'un voile noir ou d'une pluie de « mouches volantes ».", "Œil rouge très douloureux, surtout avec baisse de vision associée.", "Chez le nourrisson : œil qui pleure en permanence, sensibilité excessive à la lumière, pupille d'aspect blanchâtre.", "En cas de doute face à l'un de ces signes, ne pas attendre : consultez ou rendez-vous aux urgences ophtalmologiques les plus proches."]}],
    'Médecine générale': [
      fiche('paludisme', 'Se protéger du paludisme', ['Dormez chaque nuit sous une moustiquaire imprégnée, enfants et femmes enceintes en priorité.', 'Supprimez les eaux stagnantes autour de la maison : pots, pneus, récipients.', 'Consultez dès l’apparition d’une fièvre, sans vous traiter seul.', 'Prenez le traitement antipaludique jusqu’au bout, même si la fièvre disparaît.']),
      fiche('fievre', 'Fièvre : surveiller à la maison', ['Buvez souvent de l’eau, par petites quantités.', 'Prenez le paracétamol aux doses prescrites, sans jamais les dépasser.', 'Revenez immédiatement en cas de convulsions, de somnolence, de vomissements répétés ou de difficulté à respirer.', 'Revenez si la fièvre dure plus de 48 heures.']),
      fiche('hygiene', 'Hygiène au quotidien', ['Lavez-vous les mains au savon avant les repas et après être allé aux toilettes.', 'Buvez de l’eau potable, filtrée ou bouillie.', 'Lavez soigneusement fruits et légumes, et faites bien cuire la viande et le poisson.'])],
    'Cardiologie': [
      fiche('hta', 'Vivre avec une hypertension', ['Prenez votre traitement chaque jour, même lorsque vous vous sentez bien.', 'Réduisez le sel : sel ajouté, bouillons en cube, conserves et charcuteries.', 'Marchez au moins 30 minutes par jour.', 'Arrêtez le tabac et limitez l’alcool.', 'Venez en urgence en cas de mal de tête violent, de douleur dans la poitrine, de difficulté à parler ou de faiblesse d’un côté du corps.']),
      fiche('coeur', 'Insuffisance cardiaque : signes d’alerte', ['Pesez-vous deux fois par semaine, le matin, dans les mêmes conditions.', 'Consultez si vous prenez plus de 2 kg en 3 jours.', 'Limitez le sel et suivez les consignes de boisson de votre médecin.', 'Consultez rapidement si l’essoufflement augmente, surtout couché, ou si les jambes gonflent.'])],
    'Rhumatologie': [
      fiche('dos', 'Mal de dos', ['Restez actif : le repos strict au lit retarde la guérison.', 'Portez les charges près du corps en pliant les genoux, jamais le dos.', 'Prenez les antalgiques comme prescrit, pendant la durée indiquée.', 'Consultez en urgence en cas de faiblesse des jambes, de troubles pour uriner ou de fièvre.']),
      fiche('goutte', 'Goutte', ['Buvez au moins 1,5 litre d’eau par jour.', 'Limitez la bière, les abats, les fruits de mer et les sodas sucrés.', 'Poursuivez le traitement de fond même en l’absence de crise.']),
      fiche('arthrose', 'Arthrose', ['Perdez du poids en cas de surpoids : chaque kilo en moins soulage les genoux.', 'Pratiquez une activité douce et régulière : marche, vélo, natation.', 'Évitez le port de charges lourdes et les positions accroupies prolongées.'])],
    'Néphrologie': [
      fiche('reins', 'Protéger vos reins', ['Faites contrôler régulièrement votre tension et votre glycémie.', 'Ne prenez pas d’anti-inflammatoires sans avis médical.', 'Évitez les décoctions et traitements traditionnels sans avis de votre médecin.', 'Faites les bilans sanguins et urinaires demandés, aux dates prévues.']),
      fiche('alimentation', 'Maladie rénale : alimentation', ['Limitez le sel.', 'Suivez les consignes de votre médecin sur la quantité d’eau à boire.', 'Certains aliments riches en potassium peuvent être à limiter : demandez la liste à votre médecin.'])],
    'Dermatologie': [
      fiche('gale', 'Gale : traiter toute la maison', ['Traitez toutes les personnes du foyer le même jour, même sans démangeaisons.', 'Lavez draps, serviettes et vêtements à 60 °C, ou enfermez-les 3 jours dans un sac fermé.', 'Renouvelez le traitement comme prescrit.', 'Les démangeaisons peuvent durer encore deux semaines après un traitement réussi.']),
      fiche('peau', 'Prendre soin de sa peau', ['Utilisez un savon doux et séchez bien les plis.', 'N’utilisez jamais de produits éclaircissants : ils abîment durablement la peau.', 'Appliquez régulièrement la crème hydratante prescrite.', 'Protégez-vous du soleil aux heures chaudes.']),
      fiche('mycose', 'Mycoses de la peau', ['Séchez soigneusement les plis et entre les orteils après la toilette.', 'Portez des vêtements en coton, amples, changés chaque jour.', 'Appliquez le traitement jusqu’au bout, même si les plaques ont disparu.'])],
    'Diabétologie': [
      fiche('pieds', 'Soins des pieds', ['Regardez vos pieds chaque jour, entre les orteils compris.', 'Lavez-les à l’eau tiède et séchez-les bien.', 'Ne marchez jamais pieds nus et portez des chaussures adaptées.', 'Ne coupez pas vous-même cors et durillons.', 'Consultez rapidement pour toute plaie, même petite.']),
      fiche('hypo', 'Hypoglycémie : réagir vite', ['Signes : sueurs, tremblements, faim brutale, malaise.', 'Prenez aussitôt trois morceaux de sucre ou un verre de jus sucré.', 'Contrôlez la glycémie 15 minutes plus tard et resucrez si besoin.', 'Ne sautez jamais un repas après l’insuline ou un comprimé qui fait baisser le sucre.']),
      fiche('alimentation', 'Alimentation et diabète', ['Prenez des repas réguliers, sans en sauter.', 'Limitez sodas, jus sucrés et pâtisseries.', 'Privilégiez légumes, légumineuses et céréales complètes.', 'Marchez au moins 30 minutes par jour.'])],
    'Infectiologie': [
      fiche('arv', 'Votre traitement antirétroviral', ['Prenez le traitement chaque jour, à la même heure.', 'Ne l’arrêtez jamais sans avis médical, même si vous vous sentez bien.', 'Venez à chaque rendez-vous de suivi et de bilan.', 'Utilisez le préservatif pour protéger vos partenaires.']),
      fiche('hygiene', 'Fièvre typhoïde et hygiène', ['Buvez de l’eau potable, filtrée ou bouillie.', 'Lavez-vous les mains au savon avant de manger et après les toilettes.', 'Mangez des aliments bien cuits et servis chauds.', 'Prenez l’antibiotique jusqu’au bout.'])],
    'Pédiatrie médicale': [
      fiche('danger', 'Signes de danger : revenez immédiatement', ['Votre enfant ne peut plus boire ou téter.', 'Il vomit tout ce qu’il prend.', 'Il a des convulsions.', 'Il est très endormi ou difficile à réveiller.', 'Il respire vite ou avec difficulté.']),
      fiche('diarrhee', 'Diarrhée : SRO et zinc', ['Donnez la solution de réhydratation après chaque selle liquide.', 'Donnez le zinc chaque jour pendant toute la durée prescrite.', 'Continuez l’allaitement et l’alimentation habituelle.', 'Revenez si l’enfant ne boit pas, a du sang dans les selles ou semble déshydraté.']),
      fiche('vaccins', 'Vaccination', ['Respectez le calendrier de vaccination du PEV.', 'Apportez le carnet de santé à chaque consultation.'])],
    'Chirurgie pédiatrique': [
      fiche('avant', 'Avant l’intervention', ['Respectez le jeûne indiqué : ni manger ni boire à partir de l’heure fixée.', 'Apportez les examens demandés et le carnet de santé.', 'Signalez toute fièvre ou toux dans les jours précédents.']),
      fiche('apres', 'Après l’intervention', ['Gardez le pansement propre et sec.', 'Donnez les antalgiques comme prescrit.', 'Revenez en cas de fièvre, de rougeur, d’écoulement de la plaie, de douleur croissante ou de vomissements.'])],
    'Gynécologie-obstétrique': [
      fiche('alerte', 'Grossesse : signes d’alerte', ['Saignements ou perte de liquide.', 'Maux de tête intenses, vision trouble ou gonflement brutal du visage et des mains.', 'Fièvre.', 'Diminution des mouvements du bébé.', 'Contractions avant le terme. Dans tous ces cas, venez immédiatement.']),
      fiche('suivi', 'Bien suivre sa grossesse', ['Venez à toutes les consultations prénatales prévues.', 'Prenez chaque jour le fer et l’acide folique prescrits.', 'Dormez sous une moustiquaire imprégnée.', 'Prenez le traitement préventif du paludisme aux dates indiquées.']),
      fiche('postnatal', 'Après l’accouchement', ['Revenez pour la consultation post-natale prévue.', 'Consultez en cas de fièvre, de saignements abondants ou de douleur du ventre.', 'Parlez de contraception avec votre médecin.'])],
    'Psychiatrie': [
      fiche('traitement', 'Votre traitement', ['Prenez le traitement tous les jours, même quand vous allez mieux.', 'Ne l’arrêtez jamais brutalement sans avis médical.', 'Évitez l’alcool et les drogues.', 'Signalez tout effet gênant à votre médecin.']),
      fiche('crise', 'En cas de difficulté', ['Si l’angoisse ou la tristesse deviennent trop fortes, parlez-en à un proche.', 'Si des idées de vous faire du mal apparaissent, venez immédiatement à la clinique ou aux urgences.'])],
    'Psychologie': [
      fiche('sommeil', 'Mieux dormir', ['Couchez-vous et levez-vous à heures régulières.', 'Évitez les écrans dans l’heure qui précède le coucher.', 'Évitez café, thé et sodas après 16 heures.', 'Pratiquez une activité physique dans la journée.']),
      fiche('stress', 'Faire face au stress', ['Prenez quelques minutes par jour pour respirer lentement et profondément.', 'Gardez des moments de détente et de contact avec vos proches.', 'Parlez de ce qui vous pèse plutôt que de le garder pour vous.'])]
  };
  for (const [nom, s] of Object.entries(SPECIALITES)) {
    s.conseils = CONSEILS[nom] || [];
    if (s.conseils.length && !s.documents.includes('conseils')) s.documents.push('conseils');
  }

  /* ===== Alertes et calculs ===== */
  const nb = v => { const n = parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : null; };
  function alerte(type, valeur, contexte) {
    if (valeur == null || valeur === '') return null;
    const n = nb(valeur);
    switch (type) {
      case 'ta': {
        const m = String(valeur).match(/(\d{2,3})\s*[/-]\s*(\d{1,3})/);
        if (!m) return null;
        let s = Number(m[1]), d = Number(m[2]);
        if (s < 30) { s *= 10; d *= 10; }
        if (s >= 180 || d >= 110) return { niveau: 'bad', texte: 'HTA sévère : prise en charge immédiate' };
        if (s >= 140 || d >= 90) return { niveau: 'warn', texte: 'Tension élevée' };
        if (s < 90) return { niveau: 'warn', texte: 'Hypotension' };
        return null;
      }
      case 'glycemie': return n == null ? null : n >= 2 ? { niveau: 'bad', texte: 'Hyperglycémie' } : n >= 1.26 ? { niveau: 'warn', texte: 'Glycémie élevée' } : n < 0.7 ? { niveau: 'bad', texte: 'Hypoglycémie' } : null;
      case 'temperature': return n == null ? null : n >= 39 ? { niveau: 'bad', texte: 'Fièvre élevée' } : n >= 38 ? { niveau: 'warn', texte: 'Fièvre' } : n < 35.5 ? { niveau: 'warn', texte: 'Hypothermie' } : null;
      case 'spo2': return n == null ? null : n < 90 ? { niveau: 'bad', texte: 'Hypoxie sévère' } : n < 94 ? { niveau: 'warn', texte: 'Désaturation' } : null;
      case 'pouls': return contexte === 'enfant' || n == null ? null : n > 120 ? { niveau: 'bad', texte: 'Tachycardie importante' } : n > 100 ? { niveau: 'warn', texte: 'Tachycardie' } : n < 50 ? { niveau: 'warn', texte: 'Bradycardie' } : null;
      case 'fr': return contexte === 'enfant' || n == null ? null : n > 24 ? { niveau: 'warn', texte: 'Polypnée' } : null;
      case 'imc': return n == null ? null : n >= 30 ? { niveau: 'warn', texte: 'Obésité' } : n < 18.5 ? { niveau: 'warn', texte: 'Maigreur' } : null;
      case 'pio': return n == null ? null : n >= 30 ? { niveau: 'bad', texte: 'Hypertonie oculaire majeure' } : n > 21 ? { niveau: 'warn', texte: 'PIO élevée (> 21 mmHg)' } : null;
      case 'eva': return n != null && n >= 7 ? { niveau: 'warn', texte: 'Douleur intense' } : null;
      case 'hba1c': return n == null ? null : n >= 10 ? { niveau: 'bad', texte: 'Diabète très déséquilibré' } : n > 7 ? { niveau: 'warn', texte: 'Diabète déséquilibré (HbA1c > 7 %)' } : null;
      case 'dfg': return n == null ? null : n < 15 ? { niveau: 'bad', texte: 'Insuffisance rénale terminale' } : n < 30 ? { niveau: 'bad', texte: 'Insuffisance rénale sévère' } : n < 60 ? { niveau: 'warn', texte: 'DFG abaissé' } : null;
      default: return null;
    }
  }
  function imc(taille, poids) { const t = nb(taille), p = nb(poids); return t && p ? Math.round(p / Math.pow(t / 100, 2) * 10) / 10 : null; }
  function terme(ddr, aujourdhui) {
    if (!ddr) return null;
    const j = Math.floor((new Date((aujourdhui || new Date().toISOString().slice(0, 10)) + 'T00:00:00') - new Date(ddr + 'T00:00:00')) / 864e5);
    if (!(j >= 0 && j < 310)) return null;
    const dpa = new Date(new Date(ddr + 'T00:00:00').getTime() + 280 * 864e5);
    return { sa: Math.floor(j / 7), jours: j % 7, dpa: dpa.toISOString().slice(0, 10) };
  }

  /* v1.6 : spécialiste suggéré d'après les constantes anormales relevées à l'infirmerie. */
  function specialiteSuggeree(alertes, age) {
    const ks = (alertes || []).map(a => a.k);
    if (!ks.length) return null;
    if (age != null && age < 15) return 'Pédiatrie médicale';
    if (ks.includes('spo2') || ks.includes('fr')) return 'Médecine générale';
    if (ks.includes('ta') || ks.includes('pouls')) return 'Cardiologie';
    if (ks.includes('glycemie') || ks.includes('imc')) return 'Diabétologie';
    if (ks.includes('temperature')) return 'Infectiologie';
    return 'Médecine générale';
  }

  const API = { SPECIALITES, CONSTANTES, BILAN, LABO, CERTIF_OBJETS, alerte, imc, terme, specialiteSuggeree, noms: () => Object.keys(SPECIALITES) };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else racine.MSI_SPECIALITES = API;
})(this);
