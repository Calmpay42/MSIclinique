@echo off
setlocal
title MSI Gestion - serveur de la clinique
cd /d "%~dp0"
echo ============================================================
echo    MSI Gestion - serveur de la clinique, reseau local
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 goto pasdenode
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node"') do set NODEMAJ=%%v
if "%NODEMAJ%"=="22" goto nodeok
if "%NODEMAJ%"=="20" goto nodeok
echo Node.js version %NODEMAJ% detectee : MSI Gestion demande Node.js 22.
echo Desinstallez cette version, puis installez Node.js 22 : la page va s'ouvrir.
echo Choisissez le fichier node-v22...-x64.msi, installez-le, puis relancez ce fichier.
start "" "https://nodejs.org/dist/latest-v22.x/"
pause
exit /b 1

:pasdenode
echo Node.js n'est pas installe sur cet ordinateur.
echo La page de telechargement de Node.js 22 va s'ouvrir.
echo Choisissez le fichier node-v22...-x64.msi, installez-le, puis relancez ce fichier.
start "" "https://nodejs.org/dist/latest-v22.x/"
pause
exit /b 1

:nodeok
if exist "node_modules\better-sqlite3\build\Release\better_sqlite3.node" goto composantsok
echo Premiere installation : telechargement des composants.
echo Une connexion Internet est necessaire, cela prend quelques minutes...
call npm ci --omit=dev --no-audit --no-fund
if errorlevel 1 goto echecnpm

:composantsok
if exist "donnees\msi.db" goto demarrer
echo.
echo Creation de la base reelle de la clinique...
call node scripts\initialiser.js
if errorlevel 1 goto echecinit
echo.
echo IMPORTANT : notez le mot de passe de l'administrateur affiche ci-dessus,
echo il ne sera plus affiche. Copiez aussi le fichier donnees\cle-sauvegarde.key
echo sur une cle USB rangee au coffre : sans lui, les sauvegardes sont illisibles.
echo.
pause

:demarrer
echo.
echo Demarrage du serveur. Gardez cette fenetre ouverte, vous pouvez la reduire.
echo Les autres appareils se connectent avec l'adresse "Depuis les autres postes" ci-dessous.
echo Si Windows demande l'autorisation du pare-feu, cochez Reseaux prives puis Autoriser.
echo.
start "" cmd /c "timeout /t 5 /nobreak >nul & start http://localhost:8080"
node serveur\index.js
echo.
echo Le serveur s'est arrete. Fermez cette fenetre ou relancez ce fichier.
pause
exit /b 0

:echecnpm
echo.
echo L'installation des composants a echoue. Verifiez la connexion Internet, puis relancez.
pause
exit /b 1

:echecinit
echo.
echo La creation de la base a echoue. Notez le message ci-dessus et contactez l'assistance.
pause
exit /b 1
